import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CardPage } from './card';
import { AddCardPage } from './add-card/add-card';
import { PipesModule } from '../../pipes/pipes.module';

// import { CustomBackComponent } from '../../app/common/components/custom-back/custom-back';
import { CustomBackModule } from '../../app/common/components/custom-back/custom-back.module';


// import { UserModule } from '../user/user.module';

@NgModule({
  declarations: [
    CardPage,
    AddCardPage,
    // CustomBackComponent
  ],
  imports: [
    IonicPageModule.forChild(CardPage),
    IonicPageModule.forChild(AddCardPage),
    PipesModule,
    CustomBackModule
  ],
})
export class CardPageModule {}
