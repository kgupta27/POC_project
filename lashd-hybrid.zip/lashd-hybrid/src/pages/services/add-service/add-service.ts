import { Component, ViewChild } from '@angular/core';
import { NavController, NavParams, ViewController, Content } from 'ionic-angular';


// Import main component
// import { MyApp } from '../../../app/app.component';

// Import error messages
import { ERROR_MESSAGES } from '../../../app/common/config/error';

// Import constants
import { TEXT, NUMBER_REGES, SPACE_REGES, DIGIT_FLOAT_REGES } from '../../../app/common/config/constants';
import { FormGroup } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
// import { ViewController } from 'ionic-angular/navigation/view-controller';

//Import Providers
import { HttpService } from '../../../app/common/providers/http-service';
import { KeyboardService } from '../../../app/common/providers/keyboard-service';

@Component({
  selector: 'page-add-service',
  templateUrl: 'add-service.html',
})
export class AddServicePage {

  @ViewChild(Content) content: Content;

  addServiceForm:FormGroup
  category : any = {};
  subCategory : any = {};

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private formBuilder:FormBuilder,
    private viewCtrl:ViewController,
    private httpService : HttpService,
    private keyboardService : KeyboardService
    ) {
    this.addServiceForm = this.formBuilder.group({
      "name" : ["",[Validators.required,Validators.pattern(TEXT), Validators.maxLength(50)]],
      "description" : ["",[Validators.maxLength(255)]],
      "duration" : ["",[Validators.required,Validators.pattern(NUMBER_REGES), Validators.maxLength(3)]],
      "price" : ["",[Validators.required,Validators.pattern(DIGIT_FLOAT_REGES), Validators.maxLength(7)]],
      "isOther" : [0]
    });

    this.addServiceForm.controls['name'].valueChanges.subscribe(value => {
      if(value && value.toString().length > 50){
        this.addServiceForm.controls['name'].setValue(value.toString().substr(0,50));
      }
    });

    this.addServiceForm.controls['description'].valueChanges.subscribe(value => {
      if(value && value.toString().length > 255){
        this.addServiceForm.controls['description'].setValue(value.toString().substr(0,255));
      }
    });

    this.addServiceForm.controls['duration'].valueChanges.subscribe(value => {
      if(value && value.toString().length > 3){
        this.addServiceForm.controls['duration'].setValue(value.toString().substr(0,3));
      }
    });

    this.addServiceForm.controls['price'].valueChanges.subscribe(value => {
      if(value && value.toString().length > 7){
        this.addServiceForm.controls['price'].setValue(value.toString().substr(0,7));
      }
    });
    
    this.subCategory = this.navParams.get('subCategory');
    this.category = this.navParams.get('category');

    console.log("subCategory : ", this.subCategory)
    console.log("category : ", this.category)

    if(this.subCategory.services.length){
      this.addServiceForm.controls['description'].setValue(this.subCategory.services[0].description);
      this.addServiceForm.controls['duration'].setValue(this.subCategory.services[0].duration);
      this.addServiceForm.controls['price'].setValue(this.subCategory.services[0].price);
      if(this.subCategory.isOther){
        this.addServiceForm.controls['name'].setValue(this.subCategory.services[0].name);
      }
    }

  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddServicePage');
    // this.keyboardService.autoKeyboardScrollCall(this.content);

    let content : any = document.getElementById('addServiceForm')
    console.log('content : ', content);
    // console.log('content.children() : ', content.childNodes());

    
    console.log("content.children()[0].clientHeight : ", content.clientHeight)
    content.style.height = (content.clientHeight*2)+'px';
    // content.style.paddingBottom = content.clientHeight+'px';

    
    // let addServiceScroll : any = document.getElementById('addServiceScroll');
    // addServiceScroll.style.maxHeight = (content.clientHeight*2)+'px';
    // content.style.marginTop = (content.clientHeight/2)+'px';
  }

  addService(form){

    console.log("this.subCategory : ", this.subCategory)

    if(this.subCategory.isOther){
      // this.addServiceForm.controls['name'].setValue(form.value.name);
      // form.value.name = this.parent.trimSpace(form.value.name);
      // this.addServiceForm.controls['name'].setValue(this.parent.trimSpace(form.value.name)) 

      // form.value.addNewService = true

      /** Name */
      if(!form.value.name){
        this.httpService.presentToast(ERROR_MESSAGES.blankField('service name'));
        return false;
      }

      if(SPACE_REGES.test(form.value.name[0])){
        this.httpService.presentToast(ERROR_MESSAGES.firstCharacterSpace('service name'));
        return false;
      }

      if(form.value.name.length > 50){
        this.httpService.presentToast(ERROR_MESSAGES.maxLength('service name' , 50));
        return false;
      }

      if(!TEXT.test(form.value.name)){
        this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('service name' , TEXT));
        return false;
      }
    }else{
      delete form.value.name;
    }

    form.value.subCategoryId = this.subCategory.id;
    // form.value.serviceId = this.subCategory.id;
    form.value.isOther = this.subCategory.isOther;

    if(this.subCategory.services.length){
      form.value.serviceId = this.subCategory.services[0].id;
    }
    

    //Duration
    if(!form.value.duration){
      this.httpService.presentToast(ERROR_MESSAGES.blankField('duration'));
      return false;
    }

    if(parseInt(form.value.duration) <= 0){
      this.httpService.presentToast("Please add a valid duration");
      return false;
    }

    else if(!NUMBER_REGES.test(form.value.duration)){
      this.httpService.presentToast(ERROR_MESSAGES.allowedNumbers('duration',NUMBER_REGES));
      return false;
    }

     //Price
    if(!form.value.price){
      this.httpService.presentToast(ERROR_MESSAGES.blankField('price'));
      return false;
    }

    if(parseFloat(form.value.price) <= 0){
      this.httpService.presentToast("Please add a valid price");
      return false;
    }

    if(!DIGIT_FLOAT_REGES.test(form.value.price)){
      this.httpService.presentToast(ERROR_MESSAGES.priceError('price'));
      return false;
    }
    // if(!NUMBER_REGES.test(form.value.price)){
    //   this.httpService.presentToast(ERROR_MESSAGES.allowedNumbers('price',DIGIT_FLOAT_REGES));
    //   return false;
    // }

     //Description
     if(!form.value.description){
      this.httpService.presentToast(ERROR_MESSAGES.blankField('description'));
      return false;
    }
    if(form.value.description.length > 255){
      this.httpService.presentToast(ERROR_MESSAGES.maxLength('description' , 255));
      return false;
    }
    // if(!TEXT.test(form.value.description)){
    //   this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('description',TEXT));
    //   return false;
    // }
   
    

    // this.viewCtrl.dismiss(form.value);

    
    console.log("submit subcategory API",form.value);
    this.httpService.httpRequest("POST",(this.subCategory.services.length ? "editService" : "addService"),form.value,true)
    .then((response : any)=>{
      console.log(response);
      // if((typeof this.navParams.get('editIndex') != 'string') && (this.navParams.get('editIndex') >= 0)){
      //   response.result.editIndex = this.navParams.get('editIndex');
      // }
      // form.value.id = response.result.id;
      this.viewCtrl.dismiss("added");
      
      // this.viewCtrl.dismiss(response.result);
    })
    .catch((error)=>{
      console.log("Error in catching response",error);
    })
  }



}
