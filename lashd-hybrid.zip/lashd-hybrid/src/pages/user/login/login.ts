// Ionic Default Modules
import { Component, Inject, forwardRef } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

// Import Pages
import { SignUpOptionsPage } from '../sign-up-options/sign-up-options';
import { SignUpPage } from '../sign-up/sign-up';
import { ForgotPasswordPage } from '../forgot-password/forgot-password';

// Import main component
import { MyApp } from '../../../app/app.component';

// Import error messages
import { ERROR_MESSAGES } from '../../../app/common/config/error';

// Import constants
import { EMAIL_REGES, PASSWORD_REGES, SPACE_REGES } from '../../../app/common/config/constants';

// Import providers
import { HttpService } from '../../../app/common/providers/http-service';

@Component({
  selector: 'page-login',
  templateUrl: 'login.html',
})
export class LoginPage {

  loginForm: FormGroup;
  forgotPasswordPage = ForgotPasswordPage;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    public fb: FormBuilder,
    private httpService : HttpService,
    @Inject(forwardRef(() => MyApp)) private parent: MyApp
    ) {
      this.loginForm = fb.group({
        email: ['',[Validators.required, Validators.pattern(EMAIL_REGES), Validators.maxLength(50)]],
        password: ['', [Validators.required, Validators.pattern(PASSWORD_REGES), Validators.minLength(6), Validators.maxLength(14)]]
      })
  }

  ionViewDidEnter(){
   this.parent.userLogout();
  }

  loginUser(form){
    if(!form.valid){
      /** Email Validation */
      if(!form.value.email){
        this.httpService.presentToast(ERROR_MESSAGES.blankField('the Email Id'));
        // this.httpService.presentToast(ERROR_MESSAGES.credentialsNotMatch);
        return false;
      }

      if(!EMAIL_REGES.test(form.value.email)){
        // this.httpService.presentToast(ERROR_MESSAGES.invalidEmail);
        this.httpService.presentToast(ERROR_MESSAGES.credentialsNotMatch);
        return false;
      }

      /** Password Validation */
      if(!form.value.password){
        this.httpService.presentToast(ERROR_MESSAGES.blankField('the password'));
        // this.httpService.presentToast(ERROR_MESSAGES.credentialsNotMatch);
        return false;
      }
      if(SPACE_REGES.test(form.value.password)){
        this.httpService.presentToast(ERROR_MESSAGES.spaceInPassword);
        return false;
      }
      if(!((form.value.password.length >= 6) && (form.value.password.length <= 14))){
        // this.httpService.presentToast(ERROR_MESSAGES.passwordLength);
        this.httpService.presentToast(ERROR_MESSAGES.credentialsNotMatch);
        return false;
      }

      if(PASSWORD_REGES.test(form.value.password)){
        // this.httpService.presentToast(ERROR_MESSAGES.validCharactersInPassword);
        // this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('password' , PASSWORD_REGES));
        this.httpService.presentToast(ERROR_MESSAGES.credentialsNotMatch);
        return false;
      }
    }

    form.value.userType = this.parent.userType;
    this.httpService.httpRequest('POST', 'signIn', form.value)
    .then((response : any) => {
      this.httpService.presentToast(response.message);
      if(response.result){
        this.httpService.storeAllUserDetails(response.result);
      }
      // console.log('this.parent.getPage()', this.parent.getPage());
      let page = this.parent.getPage();
      this.navCtrl[page.type](page.page);
    }).catch((response : any) => {
      console.log('Error response : ', response)
    })
  }

  goToSignUp(){
    this.navCtrl.setPages([{page : SignUpOptionsPage}, {page : SignUpPage}]);
  }

}
