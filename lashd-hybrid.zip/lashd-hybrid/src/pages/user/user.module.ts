import { NgModule, ErrorHandler } from '@angular/core';
import { LoginPage } from './login/login';
import { SignUpOptionsPage } from './sign-up-options/sign-up-options';
import { SignUpPage } from './sign-up/sign-up';
import { EnterEmailPage } from './enter-email/enter-email';
import { CreateProfilePage } from './create-profile/create-profile';
import { CreateAccountPage } from './create-account/create-account';

import { PrivacyPolicyPage } from './privacy-policy/privacy-policy';
import { TermsAndConditionsPage } from './terms-and-conditions/terms-and-conditions';

import { MapLocationPage } from './map-location/map-location';
import { EnableLocationPage } from './enable-location/enable-location';
import { AppNotAvailablePage } from './app-not-available/app-not-available';

import { CountryCodePage } from './country-code/country-code';

import { BrowserModule } from '@angular/platform-browser';
import { IonicModule, IonicErrorHandler } from 'ionic-angular';

import { BgImageWithLoader } from '../../app/common/components/bg-image-with-loader/bg-image-with-loader';
// import { CustomBackComponent } from '../../app/common/components/custom-back/custom-back';
import { CustomBackModule } from '../../app/common/components/custom-back/custom-back.module';

// import { MultiPickerModule } from 'ion-multi-picker';


import { AddImagesPage } from './add-images/add-images';
import { AddBankPage } from './add-bank/add-bank';
import { CompleteAccountPage } from './complete-account/complete-account';

import { AddLinkPage } from './add-link/add-link';
// import { SettingsPage } from './settings/settings';

import { ForgotPasswordPage } from './forgot-password/forgot-password';

@NgModule({
  declarations : [
    BgImageWithLoader,
    SignUpOptionsPage,
    SignUpPage, 
    LoginPage,
    EnterEmailPage,
    CreateProfilePage,
    CreateAccountPage,
    PrivacyPolicyPage,
    TermsAndConditionsPage,
    MapLocationPage,
    EnableLocationPage,
    AppNotAvailablePage,
    CountryCodePage,
    // SettingsPage,
    AddImagesPage,
    AddBankPage,
    CompleteAccountPage,
    AddLinkPage,
    ForgotPasswordPage
  ],
  imports: [
    BrowserModule,
    IonicModule,
    CustomBackModule
    // MultiPickerModule
  ],
  entryComponents : [
    SignUpOptionsPage,
    SignUpPage, 
    LoginPage,
    EnterEmailPage,
    CreateProfilePage,
    CreateAccountPage,
    PrivacyPolicyPage,
    TermsAndConditionsPage,
    MapLocationPage,
    EnableLocationPage,
    AppNotAvailablePage,
    CountryCodePage,
    AddImagesPage,
    AddBankPage,
    CompleteAccountPage,
    // SettingsPage,
    AddLinkPage,
    ForgotPasswordPage
  ],
  exports : [BgImageWithLoader],
  providers: [
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class UserModule {}
