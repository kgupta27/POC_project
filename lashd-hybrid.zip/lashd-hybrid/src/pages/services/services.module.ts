import { NgModule } from '@angular/core';
import { IonicModule } from 'ionic-angular';
import { ServicesPage } from './services';
import {AddServicePage} from "./add-service/add-service";
import { BrowserModule } from '@angular/platform-browser';
import {ViewServicePage} from "./view-service/view-service"
import { EditServicePage } from './edit-service/edit-service';

// import { CustomBackComponent } from '../../app/common/components/custom-back/custom-back';

@NgModule({
  declarations: [
    ServicesPage,
    AddServicePage,
    ViewServicePage,
    EditServicePage,
    // CustomBackComponent
  ],
  imports: [
    BrowserModule,
    IonicModule,
  ],
  entryComponents:[
    ServicesPage,
    AddServicePage,
    ViewServicePage,
    EditServicePage
  ]
})
export class ServicesPageModule {}
