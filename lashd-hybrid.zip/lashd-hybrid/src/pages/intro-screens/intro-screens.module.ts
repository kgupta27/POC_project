import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { IntroScreensPage } from './intro-screens';

@NgModule({
  declarations: [
    IntroScreensPage,
  ],
  imports: [
    IonicPageModule.forChild(IntroScreensPage),
  ],
  entryComponents:[
    IntroScreensPage
  ]
})
export class IntroScreensPageModule {}
