import { Component, forwardRef, Inject } from '@angular/core';
import { NavController, NavParams, Platform, AlertController, App } from 'ionic-angular';
import { Diagnostic } from '@ionic-native/diagnostic';
import { Geolocation } from '@ionic-native/geolocation';
import { GooglePlacesProvider } from '../../app/common/providers/google-maps';

import { IntroScreensPage } from '../intro-screens/intro-screens';
//import { AppNotAvailablePage } from '../app-not-available/app-not-available';
import { EnableLocationPage } from '../user/enable-location/enable-location';
import { MapLocationPage } from '../user/map-location/map-location';
import { AppNotAvailablePage } from '../user/app-not-available/app-not-available';

import { HttpService } from '../../app/common/providers/http-service';

import { LocationAccuracy } from '@ionic-native/location-accuracy';

import { ERROR_MESSAGES } from '../../app/common/config/error';

// Import main component
import { MyApp } from '../../app/app.component';

declare const $: any;
@Component({
  selector: 'page-intro-screens-customer',
  templateUrl: 'intro-screens-customer.html',
  providers: [GooglePlacesProvider, Geolocation, LocationAccuracy]
})
export class IntroScreensCustomerPage {
  locationEnable: boolean;
  currentCity: any;
  allowedCities: any = [];
  loader;

  canGoBack : boolean = false;

  canClick : boolean = true;
  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    private platform: Platform,
    private diagnostic: Diagnostic,
    private geolocation: Geolocation,
    private httpService: HttpService,
    private locationAccuracy: LocationAccuracy,
    private googlePlacesProvider: GooglePlacesProvider,
    private alertCtrl: AlertController,
    private app : App,
    @Inject(forwardRef(() => MyApp)) private parent: MyApp
  ) {

    this.canGoBack = this.navCtrl.canGoBack();

    console.log("this.canGoBack : ", this.canGoBack)
    
  }

  ionViewDidLoad(){
    // setTimeout(()=>{
    //     this.canGoBack = this.navCtrl.canGoBack() && this.httpService.isLoggedin;
    //   }, 100);
      setTimeout(()=>{
        this.canGoBack = this.navCtrl.canGoBack() && this.httpService.isLoggedin;
      }, 300);
      setTimeout(()=>{
        this.canGoBack = this.navCtrl.canGoBack() && this.httpService.isLoggedin;
      }, 500);
  }
  
  getStarted(needToGoSettings : boolean = false) {

    this.canClick = false;
    setTimeout(()=>{
      this.canClick = true;
    }, 1000)

    /*
   if(this.platform.is('android')){
    this.getLocation(needToGoSettings);
    return;
   }*/
    this.diagnostic.getLocationAuthorizationStatus()
    .then((isAuthorized) => {
      console.log("getLocationAuthorizationStatus isAuthorized success : ", isAuthorized)
      switch(isAuthorized){
        case 'not_determined' : {//iOS
          this.locationNotRequestedYet(needToGoSettings);
          break;
        }
        case 'NOT_REQUESTED' : {//Android
          this.locationNotRequestedYet(needToGoSettings);
          break;
        }
        case 'denied' : {
          console.log('denied showAppLocationDisablePopup')
          this.showAppLocationDisablePopup();
          break;
        }
        default : {
          this.getLocation(needToGoSettings);
          break;
        }
        
      }
    }).catch((err)=>{
      console.log("getLocationAuthorizationStatus error : ", err)
    })
  }

  locationNotRequestedYet(needToGoSettings){
    console.log('No yet Jassu')
    this.diagnostic.requestLocationAuthorization()
    .then((isRequestLocationAuthorization) => {
      if(isRequestLocationAuthorization){
        this.getLocation(needToGoSettings);
      }else{
        this.showAppLocationDisablePopup();
      }
      console.log("requestLocationAuthorization isRequestLocationAuthorization success : ", isRequestLocationAuthorization)
    }).catch((err)=>{
      console.log("requestLocationAuthorization error : ", err)
    })
  }

  getStarted2(needToGoSettings : boolean = false) {
    this.canClick = false;
    setTimeout(()=>{
      this.canClick = true;
    }, 1000)
    this.geolocation.getCurrentPosition(this.platform.is('android') ? {timeout: 100} : {}).then((resp) => {
        this.getLocation(needToGoSettings);
      }).catch((error) => {
        console.log(error);
        this.getLocation(needToGoSettings);
      });
  }

  getLocation(needToGoSettings : boolean = false){
    this.platform.ready().then(() => {
      this.diagnostic.isLocationEnabled()
        .then((isEnabled) => {
          console.log("isEnabled success : ", isEnabled, JSON.stringify(isEnabled));
          if (isEnabled) {
            this.diagnostic.isLocationAuthorized()
              .then((isAuthorized) => {
                console.log("isAuthorized success : ", isAuthorized, JSON.stringify(isAuthorized));
                if (isAuthorized) {
                  this.locationEnable = true;
                  this.geolocation.getCurrentPosition(this.platform.is('android') ? {timeout: 5000} : {}).then((resp) => {
                    var latlong = resp.coords.latitude + ',' + resp.coords.longitude;
                    this.getCity(latlong);
                  }).catch((error) => {
                    console.log('error : '+JSON.stringify(error));
                  });
                } else {
                  this.showAppLocationDisablePopup();
                }
                /*
                this.diagnostic.getLocationAuthorizationStatus()
                .then((requestAuthorization) => {
                  // this.diagnostic.requestLocationAuthorization()
                  console.log("requestAuthorization success : ", requestAuthorization, JSON.stringify(requestAuthorization));

                })
                .catch((error) => {
                  console.log("requestAuthorization error : ", error, JSON.stringify(error));
                  
                })*/

              })
              .catch((error) => {
                console.log("isAuthorized error : ", error, JSON.stringify(error));

              })
          }else{
            if(needToGoSettings){
              this.diagnostic.switchToLocationSettings();
            }else{
              this.navCtrl.push(EnableLocationPage, {introPage : this});
            }
          }
        });
    });
  }

  showAppLocationDisablePopup() {
    let alert = this.alertCtrl.create({
      title: 'Location Access Disabled',
      subTitle: "In order to be get your location, please open this app’s settings and set location access to ‘Always'.",
      cssClass: 'one-button',
      enableBackdropDismiss: false,
      buttons: [
        {
          text: 'Ok',
          handler: data => {
            this.parent.blurryBG();
          }
        }
      ]
    });
    alert.present();
  }

  ionViewCanEnter() {
    this.parent.userType = 3;
  }

  getCity(latlong) {
    let city = '';
    this.googlePlacesProvider.getAddress(latlong).subscribe(data => {

      let addressArr = data.results[0].address_components;
      for (var ac = 0; ac < addressArr.length; ac++) {
        var component = addressArr[ac];
        switch (component.types[0]) {
          case 'locality'://city
            this.currentCity = component.long_name;
            break;
          default:
            break;
        }
      }
      this.httpService.httpRequest('GET', 'allowedCities', {})
        .then((response: any) => {
          console.log(response);
          let responseData: any = response;
          this.allowedCities = responseData.result.cities;

          if (this.allowedCities && this.allowedCities.length) {
            for (let i = 0; i < this.allowedCities.length; i++) {
              console.log("this.allowedCities[i].cityName == this.currentCity : ", this.allowedCities[i].cityName, this.currentCity, JSON.stringify(this.allowedCities[i]))
              if (this.allowedCities[i].cityName == this.currentCity) {
                window.localStorage.setItem("customerFlow", "1");
                let activeNavInstance : any = this.app.getActiveNav().getActive().instance;
                if(!(activeNavInstance instanceof MapLocationPage)){
                  this.navCtrl.push(MapLocationPage, { pickCustomerLocation: true });
                }
                return false;
              }
            }
            this.navCtrl.push(AppNotAvailablePage, {city : this.currentCity});
          } else {
            this.navCtrl.push(AppNotAvailablePage, {city : this.currentCity});
          }
        }).catch((response: any) => {
          console.log('Error response : ', response)
        })

    });
  }

  gotoIntro() {
    this.parent.userType = 2;
    this.navCtrl.setPages([{ page: IntroScreensPage }]);
  }
}