// Ionic Default Modules
import { Component, Inject, forwardRef, ViewChild } from '@angular/core';
import { NavController, NavParams, ActionSheetController, AlertController, ModalController, Content, Platform } from 'ionic-angular';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

import { KeyboardService } from '../../../app/common/providers/keyboard-service';


// Import main component
import { MyApp } from '../../../app/app.component';

// Import error messages
import { ERROR_MESSAGES } from '../../../app/common/config/error';

// Import constants
import { TEXT, SPACE_REGES } from '../../../app/common/config/constants';

// Import providers
import { HttpService } from '../../../app/common/providers/http-service';
import { Image } from '../../../app/common/providers/get-image';

// Import global functions
import { getUserData } from '../../../app/common/config/global-functions';

// Import plugin modules
import { Camera, CameraOptions } from '@ionic-native/camera';

import { AddLinkPage } from '../add-link/add-link';

@Component({
  selector: 'page-create-profile',
  templateUrl: 'create-profile.html',
  providers : [Camera]
})
export class CreateProfilePage {
  createProfileForm : FormGroup;
  profilePhoto : any = '';
  fbProfileImageUrl : any = '';
  userDetails;
  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams, 
    private httpService : HttpService,
    public fb: FormBuilder,
    public camera:Camera,
    public actionSheetCtrl: ActionSheetController,
    private image : Image,
    private alertCtrl : AlertController,
    private modalCtrl : ModalController,
    private keyboardService : KeyboardService,
    private platform : Platform,
    @Inject(forwardRef(() => MyApp)) private parent: MyApp
    ) {
      this.userDetails = this.httpService.getUserProperty('userDetails');
    this.createProfileForm = fb.group({
      name: ['',[Validators.required, Validators.pattern(TEXT), Validators.maxLength(50)]],
      // bio: ['',[Validators.pattern(TEXT),Validators.maxLength(255)]],
      bio: ['',[Validators.maxLength(255)]],
    })

    /*
    this.createProfileForm.controls['name'].valueChanges.subscribe(value => {
      if(value && (SPACE_REGES.test(value[0]))){
        let v = value.substring(0,1);
        this.createProfileForm.controls['name'].setValue(v);
      }
    })

    this.createProfileForm.controls['bio'].valueChanges.subscribe(value => {
      if(value && (SPACE_REGES.test(value[0]))){
        let v = value.substring(0,1);
        this.createProfileForm.controls['bio'].setValue(v);
      }
    })*/
    
    if(this.navParams.get('fbUserData')){
      let  userData = this.navParams.get('fbUserData');
      if(userData['picture_large']['data']['url']){//Setup FB image
        this.fbProfileImageUrl = userData['picture_large']['data']['url'];
      }
      if(userData['name']){//Setup FB Name
        this.createProfileForm.controls.name.setValue(userData['name']);
      }
    }
  }

  createProfile(form) {

    this.createProfileForm.controls['name'].setValue(form.value.name);
    this.createProfileForm.controls['bio'].setValue(form.value.bio);

    // form.value.name = form.value.name.replace(/ /g, '');
    // form.value.bio = form.value.bio.replace(/ /g, '');

    // this.createProfileForm.controls['name'].setValue(form.value.name.replace(/ /g, '')) 
    // this.createProfileForm.controls['bio'].setValue(form.value.bio.replace(/ /g, '')) 

    form.value.name = this.parent.trimSpace(form.value.name);
    form.value.bio = this.parent.trimSpace(form.value.bio);

    this.createProfileForm.controls['name'].setValue(this.parent.trimSpace(form.value.name)) 
    this.createProfileForm.controls['bio'].setValue(this.parent.trimSpace(form.value.bio)) 

    // if(!form.valid){

      /** Name */
      if(!form.value.name){
        this.httpService.presentToast(ERROR_MESSAGES.blankField('your name'));
        return false;
      }

      if(SPACE_REGES.test(form.value.name[0])){
        this.httpService.presentToast(ERROR_MESSAGES.firstCharacterSpace('name'));
        return false;
      }

       if(form.value.name.length > 50){
          this.httpService.presentToast(ERROR_MESSAGES.maxLength('name' , 50));
          return false;
        }

        if(!TEXT.test(form.value.name)){
          this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('name' , TEXT));
          return false;
        }
        
        if(form.value.bio && (form.value.bio.length > 255)){
          this.httpService.presentToast(ERROR_MESSAGES.maxLength('bio' , 255));
          return false;
        }

        // if(form.value.bio && !TEXT.test(form.value.bio)){
        //   this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('bio' , TEXT));
        //   return false;
        // }
    // }

    form.value.userType = this.parent.userType;
    form.value.userId = getUserData('id');
    if(this.profilePhoto){
      form.value.profileImage = this.profilePhoto;
    }else if(this.fbProfileImageUrl){
      form.value.profileImageUrl = this.fbProfileImageUrl;
    }
    this.httpService.httpRequest('POST', 'updateUserProfile', form.value)
    .then((response : any) => {
      this.httpService.presentToast(response.message);
      let page = this.parent.getPage();
      this.navCtrl[page.type](page.page);
    }).catch((response : any) => {
      console.log('Error response : ', response)
    })
  }

  @ViewChild(Content) content: Content;
  ionViewDidLoad(){
   this.keyboardService.autoKeyboardScrollCall(this.content);
  }

  takePicture(){
    this.parent.image.get().then((img) => {
      this.profilePhoto = img;
    });
  }

  unlinkFb() {
    //this.parent.blurryBG(true);
    let alert = this.alertCtrl.create({
      title: 'UnLink Facebook',
      subTitle: 'Are you sure you want to unlink facebook from your profile ?',
      cssClass: 'two-button',
      enableBackdropDismiss: false,
      buttons: [
        {
          text: 'No',
          handler: () => {

          }
        },
        {
          text: 'Confirm',
          handler: data => {
            //this.parent.blurryBG();
            this.httpService.httpRequest('POST', 'updateUserProfile', { facebookLink: null })
              .then((response: any) => {
                this.httpService.presentToast(response.message);
                this.httpService.storeAllUserDetails(response.result);
                this.userDetails = this.httpService.getUserProperty('userDetails');
              }).catch((response: any) => {
                console.log('Error response : ', response)
              });

          }
        }
      ]
    });
    alert.present();
  }
  linkFb() {
    this.parent.blurryBG(true);
    let modal = this.modalCtrl.create(AddLinkPage, { type: 'facebook' });
    modal.onDidDismiss(data => {
      this.parent.blurryBG();
      if (data) {
        if (data.link) {
          this.httpService.httpRequest('POST', 'updateUserProfile', { facebookLink: data.link })
            .then((response: any) => {
              this.httpService.presentToast(response.message);
              this.httpService.storeAllUserDetails(response.result);
              this.userDetails = this.httpService.getUserProperty('userDetails');
            }).catch((response: any) => {
              console.log('Error response : ', response)
            });
        }
      }
    });
    modal.present();
  }

  /*
  options: CameraOptions = {
    quality:100,
    destinationType:this.camera.DestinationType.DATA_URL,
    sourceType: this.camera.PictureSourceType.CAMERA,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
    targetWidth:255,
    targetHeight:255,
    allowEdit:true,
    saveToPhotoAlbum:false
  }
  optionsGallery: CameraOptions ={
    quality:80,
    destinationType:this.camera.DestinationType.DATA_URL,
    sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
    targetWidth:200,
    targetHeight:200,
    allowEdit:true,
    saveToPhotoAlbum:false
  }

  takePicture(){
      let actionSheet = this.actionSheetCtrl.create({
      title: '',
      buttons: [
        {
          text: 'Take a Photo',
          handler: () => {
            this.camera.getPicture(this.options).then((ImageData) => {
                this.profilePhoto = "data:image/jpeg;base64," + ImageData;
            })
            .catch(data => {
                
            });
          }
        },
        {
          text: 'Choose From Gallery',
          handler: () => {
            this.camera.getPicture(this.optionsGallery).then((ImageData) => {
                this.profilePhoto = "data:image/jpeg;base64," + ImageData;
            })
            .catch(data => {
                
            });
          }
        },
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });

    actionSheet.present();
  }*/

}
