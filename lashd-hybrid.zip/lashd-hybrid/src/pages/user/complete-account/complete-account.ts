import { Component, forwardRef, Inject } from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

import { ERROR_MESSAGES } from '../../../app/common/config/error';


// import { AddImagesPage } from '../add-images/add-images';

import { HttpService } from '../../../app/common/providers/http-service';

import { MyApp } from '../../../app/app.component';

// Import constants
import { TEXT, SPACE_REGES } from '../../../app/common/config/constants';

import { ProfilePage } from '../../profile/profile';
import { ViewProfilePage } from '../../profile/view-profile/view-profile';


@Component({
  selector: 'page-complete-account',
  templateUrl: 'complete-account.html',
})
export class CompleteAccountPage {

  data : any = {
    "operationalHours" : 540,
    "startTime" : '08:00',
    "endTime" : '17:00',
    "distanceCriteria" : 80,
    "certificateTitle" : "",
    "certificateImage" : ""
  }
  days : any = [
    {name : "Mon", active : true},
    {name : "Tue", active : true},
    {name : "Wed", active : true},
    {name : "Thu", active : true},
    {name : "Fri", active : true},
    {name : "Sat", active : false},
    {name : "Sun", active : false}
  ]

  titleForm: FormGroup;

  isEdit : boolean = false;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private httpService : HttpService,
    public fb: FormBuilder,
    private alertCtrl : AlertController,
    @Inject(forwardRef(() => MyApp)) private parent: MyApp
    ) {
      this.titleForm = fb.group({
        title: ['',[Validators.required, Validators.pattern(TEXT), Validators.maxLength(50)]],
      })

      if(this.navParams.get('isEdit')){
        this.isEdit = this.navParams.get('isEdit')
        this.data = this.httpService.getUserProperty('creative');
        console.log("this.data : ", this.data)
        this.days[0].active = this.data.isAvailMon;
        this.days[1].active = this.data.isAvailTue;
        this.days[2].active = this.data.isAvailWed;
        this.days[3].active = this.data.isAvailThu;
        this.days[4].active = this.data.isAvailFri;
        this.days[5].active = this.data.isAvailSat;
        this.days[6].active = this.data.isAvailSun;

        let startTime = this.data.startTime.split(':');
        // delete startTime[startTime.length-1];
        startTime.splice(startTime.length-1, 1);
        this.data.startTime = startTime.join(':');
        console.log("this.data.startTime : ", this.data.startTime)
        
        let endTime = this.data.endTime.split(':');
        // delete endTime[startTime.length-1];
        endTime.splice(endTime.length-1, 1);
        this.data.endTime = endTime.join(':');

        if(this.data.certificateTitle){
          this.titleForm.controls['title'].setValue(this.data.certificateTitle);
        }
      }
  }

  // checkTime(){
  //   this.data.endTime = this.displayTime(endMins+15);
  // }

  removeCertificate(){
    console.log("removeCertificate : ")
    this.parent.blurryBG(true);
    let alert = this.alertCtrl.create({
      title: 'Delete Certificate',
      subTitle: 'Are you sure you want to delete the certificate.',
      cssClass:'two-button',
      enableBackdropDismiss : false,
      buttons: [
        {
          text : 'No',
          handler: data => {
            this.parent.blurryBG();
          }
        },
        {
          text: 'Confirm',
          handler: data => {
            this.parent.blurryBG();
            console.log("removeCertificate : Yes ")
          }
        }
      ]
    });
    alert.present();
  }

  removeUploadedImage(){
    console.log("removeUploadedImage : ")
    this.parent.blurryBG(true);
    let alert = this.alertCtrl.create({
      title: 'Delete Certificate',
      subTitle: 'Are you sure you want to delete the certificate.',
      cssClass:'two-button',
      enableBackdropDismiss : false,
      buttons: [
        {
          text : 'No',
          handler: data => {
            this.parent.blurryBG();
          }
        },
        {
          text: 'Confirm',
          handler: data => {
            console.log("removeCertificate : Yes ");
            this.parent.blurryBG();
            delete this.data.certificateImage;
          }
        }
      ]
    });
    alert.present();
  }

  changeOperationalHours(){
    setTimeout(()=>{
      let startTimeCheck = this.data.startTime.split(':');
      let startMins = (parseInt(startTimeCheck[0])*60)+parseInt(startTimeCheck[1]);

      // let endTimeCheck = this.data.endTime.split(':');
      // let endMins = (parseInt(endTimeCheck[0])*60)+parseInt(endTimeCheck[1]);
    
      let endTime = startMins + this.data.operationalHours;
      console.log("endTime : ", endTime)

      if(endTime <= 1425){
        this.data.endTime = this.displayTime(endTime);
      }else{
        this.data.endTime = this.displayTime("23:45");
        let startTime = 1425 - parseInt(this.data.operationalHours);
        console.log("startTime : ", startTime)
        this.data.startTime = this.displayTime(startTime);
      }
    }, 100)
  }

  changeTime(){
    setTimeout(()=>{
      let startTimeCheck = this.data.startTime.split(':');
      let endTimeCheck = this.data.endTime.split(':');

      if(startTimeCheck[0] == endTimeCheck[0]){
        if(parseInt(startTimeCheck[1]) >= parseInt(endTimeCheck[1])){
          this.httpService.presentToast(ERROR_MESSAGES.timeError);
          return false;
        }
      }else if(parseInt(startTimeCheck[0]) > parseInt(endTimeCheck[0])){
        this.httpService.presentToast(ERROR_MESSAGES.timeError);
        return false;
      }

      let hours : any = endTimeCheck[0] - startTimeCheck[0];
      hours = parseInt(hours);

      let mins : any = endTimeCheck[1] - startTimeCheck[1];
      mins = parseInt(mins);
      
      this.data.operationalHours = (hours*60)+mins;
    }, 100)
  }


  saveAccount(form) {

    this.titleForm.controls['title'].setValue(form.value.title);
    form.value.title = this.parent.trimSpace(form.value.title);
    this.titleForm.controls['title'].setValue(this.parent.trimSpace(form.value.title)) 

    if(!this.data.operationalHours){
      this.httpService.presentToast('Please select operational hours');
      return;
    }

    if(!this.data.startTime){
      this.httpService.presentToast('Please select start time');
      return;
    }

    if(!this.data.endTime){
      this.httpService.presentToast('Please select end time');
      return;
    }

    
    let startTimeCheck = this.data.startTime.split(':');
    let endTimeCheck = this.data.endTime.split(':');
    

    if(startTimeCheck[0] == endTimeCheck[0]){
      if(parseInt(startTimeCheck[1]) >= parseInt(endTimeCheck[1])){
        this.httpService.presentToast(ERROR_MESSAGES.timeError, 'icon-warning');
        return false;
      }
    }else if(parseInt(startTimeCheck[0]) > parseInt(endTimeCheck[0])){
      this.httpService.presentToast(ERROR_MESSAGES.timeError, 'icon-warning');
      return false;
    }
    
    console.log('startTimeCheck : ', startTimeCheck);
    console.log('endTimeCheck : ', endTimeCheck);

    /** Check mins time difference */
    /*
    let startTimeInt = (parseInt(startTimeCheck[0])*60*60)+parseInt(startTimeCheck[1])*60;
    let endTimeInt = (parseInt(endTimeCheck[0])*60*60)+parseInt(endTimeCheck[1])*60;

    console.log('startTimeInt : ', startTimeInt);
    console.log('endTimeInt : ', endTimeInt);

    let timeDifference = endTimeInt - startTimeInt;
    timeDifference = timeDifference/3600;
    console.log('timeDifference : ', timeDifference);

    if(timeDifference != this.data.operationalHours){
      this.httpService.presentToast(ERROR_MESSAGES.timeDiff(this.data.operationalHours));
      return false;
    }*/
    

    let isDaySelected = false;
    for(let i = 0;i < this.days.length;i++){
      if(this.days[i].active){
        isDaySelected = true;
      }
    }

    if(!isDaySelected){
      this.httpService.presentToast('Please select a day');
      return;
    }

    if(!this.data.distanceCriteria){
      this.httpService.presentToast('Please select operating area');
      return;
    }

    if((this.data.certificateImage || this.data.certificate) && !form.value.title){
      this.httpService.presentToast(ERROR_MESSAGES.blankField('title of the certificate'));
      return false;
    }

    if(form.value.title){
      if(SPACE_REGES.test(form.value.title[0])){
        this.httpService.presentToast(ERROR_MESSAGES.firstCharacterSpace('document title'));
        return false;
      }

      if(!this.data.certificateImage && !this.data.certificate){
        this.httpService.presentToast(ERROR_MESSAGES.titleButNotCertificate);
        return false;
      }

      if(form.value.title.length > 50){
        this.httpService.presentToast(ERROR_MESSAGES.maxLength('title of the certificate' , 50));
        return false;
      }

      if(!TEXT.test(form.value.title)){
        this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('document title' , TEXT));
        return false;
      }

      this.data.certificateTitle = form.value.title;
    }

    this.data.isAvailMon = this.days[0].active ? 1 : 0;
    this.data.isAvailTue = this.days[1].active ? 1 : 0;
    this.data.isAvailWed = this.days[2].active ? 1 : 0;
    this.data.isAvailThu = this.days[3].active ? 1 : 0;
    this.data.isAvailFri = this.days[4].active ? 1 : 0;
    this.data.isAvailSat = this.days[5].active ? 1 : 0;
    this.data.isAvailSun = this.days[6].active ? 1 : 0;

    if(!this.data.certificateImage){
      delete this.data.certificateImage;
    }

    this.httpService.httpRequest('POST', 'updateCreative', this.data)
    .then((response : any) => {
      this.httpService.storeAllUserDetails(response.result);
      this.httpService.presentToast(response.message);
      if(this.isEdit){
        // this.navCtrl.pop();
        this.navCtrl.setPages([{page : ProfilePage}, {page : ViewProfilePage, params : {selectedView : 'professional'}}])
        return false;
      }
      let page = this.parent.getPage();
      this.navCtrl[page.type](page.page);
    }).catch((response : any) => {
      console.log('Error response : ', response)
    })
  }

  uploadImage() {
    this.parent.image.get(false).then((img) => {
      this.data.certificateImage = img;
    })
  }

  displayTime(a){
    var hours = Math.trunc(a/60);
    var minutes = a % 60;
    // console.log(hours +":"+ minutes);
    return ((hours.toString().length == 1) ? '0'+hours.toString() : hours) +":"+ ((minutes.toString().length == 1) ? '0'+minutes.toString() : minutes);
  }

}
