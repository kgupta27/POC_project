import { Component } from '@angular/core';
import { Platform } from 'ionic-angular';
import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Keyboard } from '@ionic-native/keyboard';
import { Device } from '@ionic-native/device';


// import { TabsPage } from '../pages/tabs/tabs';
// import { HomePage } from '../pages/tabs/home/home';
import { IntroScreensPage } from '../pages/intro-screens/intro-screens';

// import { UserModule } from '../pages/user/user.module';

import { HttpService } from './common/providers/http-service';
import { Image } from './common/providers/get-image';
import { LocalDataArray } from './common/providers/local-data-array';
// import { addStyle, getUserData } from './common/config/global-functions';
import { getUserData } from './common/config/global-functions';
// import { SERVER_NAME_MAIN } from './common/config/config';

import { CreateAccountPage } from '../pages/user/create-account/create-account';
import { CreateProfilePage } from '../pages/user/create-profile/create-profile';


// import { EnterEmailPage } from '../pages/user/enter-email/enter-email';
import { LoginPage } from '../pages/user/login/login';
import { SignUpPage } from '../pages/user/sign-up/sign-up';
import { SignUpOptionsPage } from '../pages/user/sign-up-options/sign-up-options';

// import { CountryCodePage } from '../pages/user/country-code/country-code';

import { SPACE_REGES } from './common/config/constants';


import { AddBankPage } from '../pages/user/add-bank/add-bank';

import { CompleteAccountPage } from '../pages/user/complete-account/complete-account';
// import { AddLinkPage } from '../pages/user/add-link/add-link';
import { AddImagesPage } from '../pages/user/add-images/add-images';

import { ServicesPage } from '../pages/services/services';
import { TabsPage } from '../pages/tabs/tabs';
// import { SettingsPage } from '../pages/user/settings/settings';
import { ViewProfilePage } from '../pages/profile/view-profile/view-profile';
import { ProfilePage } from '../pages/profile/profile';
import { EditPersonalDetailsPage } from '../pages/profile/edit-personal-details/edit-personal-details';
import { CardPage } from '../pages/card/card';
import { AddCardPage } from '../pages/card/add-card/add-card';

import { HomeCustomerPage } from '../pages/tabs/home-customer/home-customer';

import { AppNotAvailablePage } from '../pages/user/app-not-available/app-not-available';

import { EnableLocationPage } from '../pages/user/enable-location/enable-location';

@Component({
  templateUrl: 'app.html'
})
export class MyApp {
  // rootPage:any = CreateAccountPage;
  rootPage: any;
  userType: number = 2;

  constructor(
    private platform: Platform,
    private statusBar: StatusBar,
    private splashScreen: SplashScreen,
    private keyboard: Keyboard,
    private device: Device,

    public httpService: HttpService,
    public image: Image,
    private localDataArray: LocalDataArray
  ) {
    console.log("platform.ready() Before")
    platform.ready().then(() => {
      console.log("platform.ready()")
      // this.statusBar.styleDefault();

      this.statusBar.backgroundColorByHexString('#e9ab60');
      if (platform.is('ios')) {
        this.splashScreen.hide();
        
        this.keyboard.onKeyboardShow().subscribe((e)=>{
          console.log('onKeyboardShow');
          let ionApp : any = document.getElementsByTagName('ion-app')[0];
          ionApp.style.maxHeight = (window.innerHeight-e.keyboardHeight)+'px';
          // ionApp.style.marginTop = '-50px';
          console.log("window.innerHeight : ", window.innerHeight)
          console.log("e.keyboardHeight : ", e.keyboardHeight)

          let scrollContent : any = document.getElementsByClassName('scroll-content');
          if(scrollContent.length){
            scrollContent[scrollContent.length-1].style.marginTop = '0px';
          }
          
        })
        this.keyboard.onKeyboardHide().subscribe(()=>{
          console.log('onKeyboardHide');
          let ionApp : any = document.getElementsByTagName('ion-app')[0];
          ionApp.style.maxHeight = 'none';
          
          let scrollContent : any = document.getElementsByClassName('scroll-content');
          if(scrollContent.length){
            scrollContent[scrollContent.length-1].style.marginTop = '70px';
          }

        })

      } else {
        setTimeout(() => {
          this.splashScreen.hide();
        }, 1000)
      }

      // addStyle(SERVER_NAME_MAIN+'/css/hybrid.css');
      this.keyboard.disableScroll(true);
      this.keyboard.hideKeyboardAccessoryBar(false);

      this.statusBar.overlaysWebView(false);
      this.statusBar.backgroundColorByHexString('#e9ab60');
      this.statusBar.styleLightContent();

      if (this.platform.is('ios')) {
        this.localDataArray.deviceType = 1;
      } else {
        this.localDataArray.deviceType = 2;
      }
      this.localDataArray.deviceId = this.device.uuid ? this.device.uuid : '123456';
      this.rootPage = this.getPage()['page'];//setup first page
      // this.rootPage = CardPage;
    });
  }

  getPage() {
    // Set start page
    if (this.httpService && this.httpService.isLoggedin) {//Logged In
      // this.rootPage = HomePage;
      let userdata: any = getUserData('userData', true);
      console.log("userdata : ", JSON.stringify(userdata));
      if (userdata && userdata.userType) {
        this.userType = userdata.userType;
        console.log("userdata.userType :", userdata.userType)
      }
      let allUserDetails: any = window.localStorage.getItem('allUserDetails');
      if (allUserDetails) {
        try {
          allUserDetails = JSON.parse(allUserDetails)
        } catch (e) {
          allUserDetails = false;
        }
      }

      if (userdata) {
        if (userdata.name) {
          console.log('userdata.userDetails : ', userdata.userDetails)
          console.log('userdata.userDetails.country : ', userdata.userDetails.country)
          if (userdata.userDetails[0].country) {

            if (userdata.userType == 2) {//Creative Flow
              if (!allUserDetails || !allUserDetails.creative || (allUserDetails && allUserDetails.creative && !allUserDetails.creative.operationalHours)) {
                return { page: CompleteAccountPage, type: 'push' };
              } else {
                if (userdata.userDetails[0].isImageSkipped || (allUserDetails.userImages && allUserDetails.userImages.length)) {
                  if (userdata.userDetails[0].isBankSkip || (allUserDetails.userDetails && allUserDetails.userDetails[0] && allUserDetails.userDetails[0].stripeAccountId)) {
                    if (userdata.userDetails[0].isServiceSave) {//isServiceSave
                      return { page: TabsPage, type: 'setRoot' };
                    } else {
                      return { page: ServicesPage, type: 'push' };
                    }

                  } else {
                    return { page: AddBankPage, type: 'push' };
                  }

                } else {
                  return { page: AddImagesPage, type: 'push' };
                }
              }
            } else if (userdata.userType == 3) {//Customer Flow

              if (userdata.userDetails[0].isCardSkip || (allUserDetails && allUserDetails.userDetails && allUserDetails.userDetails[0] && allUserDetails.userDetails[0].stripeConnectToken)) {
                return { page: TabsPage, type: 'setRoot' };
              } else {
                let p : any = {isSkipable : true};
                // return { page: <any>AddCardPage, p , type: 'push' };
                return { page: AddCardPage, type: 'push' };
              }

            } else {// There is no UserType;
              console.log("No User Type", userdata);
              return { page: SignUpOptionsPage, type: 'setRoot' };
            }

          } else {
            return { page: CreateAccountPage, type: 'push' };
          }
        } else {
          return { page: CreateProfilePage, type: 'push' };
        }
      } else {//Not Logged In
        return { page: IntroScreensPage, type: 'setRoot' };
        /*
        if (window.localStorage.getItem('introViewed')) {
          return { page: SignUpOptionsPage, type: 'setRoot' };
        } else {
          return { page: IntroScreensPage, type: 'setRoot' };
        }*/
      }
    } else {//Not Logged In
      return { page: IntroScreensPage, type: 'setRoot' };
      /*
      if (window.localStorage.getItem('introViewed')) {
        return { page: SignUpOptionsPage, type: 'setRoot' };
      } else {
        return { page: IntroScreensPage, type: 'setRoot' };
      }*/
    }
  }

  blurryBG(isSet: boolean = false) {
    if (isSet) {
      document.getElementsByTagName('body')[0].classList.add('app-blur');
    } else {
      document.getElementsByTagName('body')[0].classList.remove('app-blur');
    }
  }

  userLogout(redirectTo: any = false, introViewed: any = false) {
    this.blurryBG()
    if (!introViewed) {
      introViewed = window.localStorage.getItem('introViewed')
    }
    window.localStorage.clear();
    if (introViewed) {
      window.localStorage.setItem('introViewed', introViewed);
    }
    switch (redirectTo) {
      case 'login': {
        this.rootPage = LoginPage;
      }
      case 'signUp': {
        this.rootPage = SignUpPage;
      }
      case 'signUpOptions': {
        this.rootPage = SignUpOptionsPage;
      }
      default: {
        console.log('userLogout default : ', redirectTo)
      }
    }
  }

  trimSpace(value) {
    if (value && (SPACE_REGES.test(value[0]))) {
      let v = value.substring(1);
      if (v && (SPACE_REGES.test(v[0]))) {
        // console.log('v : ', v)
        // console.log('this.trimSpace(v) : ', this.trimSpace(v))
        return this.trimSpace(v)
      } else {
        // console.log('v : ', v)
        return v;
      }
    } else {
      // console.log('value : ', value)
      return value;
    }
  }
}