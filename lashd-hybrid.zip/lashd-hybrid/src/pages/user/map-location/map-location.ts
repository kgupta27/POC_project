import { Component, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
import { NavController, NavParams, Platform, ViewController } from 'ionic-angular';

// import { GooglePlacesProvider } from '../../../app/common/providers/google-maps';
import { Geolocation } from '@ionic-native/geolocation';
import { LocationAccuracy } from '@ionic-native/location-accuracy';

import { MAP_STYLE } from '../../../app/common/config/map-ui';
import { ERROR_MESSAGES } from '../../../app/common/config/error';
// import { HomeCustomerPage } from '../../tabs/home-customer/home-customer';
import { TabsPage } from '../../tabs/tabs';

import { HttpService } from '../../../app/common/providers/http-service';

import { AppNotAvailablePage } from '../../user/app-not-available/app-not-available';


declare var google;
@Component({
  selector: 'page-map-location',
  templateUrl: 'map-location.html',
  // providers: [GooglePlacesProvider, Geolocation, LocationAccuracy]
  providers: [Geolocation, LocationAccuracy]
})
export class MapLocationPage {
  @ViewChild('map') mapElement: ElementRef; // Added
  map: any; // Added

  addressData: any = {};
  isCustomerFlow: any = 0;
  service = new google.maps.places.AutocompleteService();

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private platform: Platform,
    // private googlePlacesProvider: GooglePlacesProvider,
    private geolocation: Geolocation,
    private locationAccuracy: LocationAccuracy,
    private viewCtrl: ViewController,
    private cd: ChangeDetectorRef,
    private httpService : HttpService
  ) {
    this.platform.ready().then(() => {
      if(this.navParams.get('updateLocation')){
        let userDetails = this.httpService.getUserProperty('userDetails')[0]
        this.addressData.finalAddress = {
          "address": userDetails.address,
          "latitude": userDetails.latitude,
          "longitude": userDetails.longitude,
          "city": userDetails.city,
          "suburb": userDetails.suburb,
          "state": userDetails.state,
          "country": userDetails.country,
          "zipcode": userDetails.zipcode
        };
        // this.map.setOptions({ center: new google.maps.LatLng(userDetails.latitude, userDetails.longitude) });
        if(userDetails.latitude && userDetails.longitude){
          this.loadMap(userDetails.latitude, userDetails.longitude);
          this.geoCodeLatLng(userDetails.latitude, userDetails.longitude).then((results: any) => {
            this.setLocation(results[0], userDetails.latitude, userDetails.longitude);
          });
        }else{
          // this.loadMap();
          this.loadMap();
          setTimeout(()=>{
            this.getMyLocation();
          }, 1000)
        }
        
      }else{
        this.getMyLocation();
        this.loadMap();
      }
    });
  }

  ionViewCanEnter(){
   setTimeout(()=>{
      try{
        google.maps.event.trigger(this.map, 'resize');
      }catch(e){console.log('map resize : ', e)}
    }, 500)
  }

  setUpBlackAddress() {
    this.addressData = {
      address: '',
      showAddress: false,
      selectedAddress: {},
      finalAddress: {}
    };
    console.log('setUpBlackAddress this.addressData : ', this.addressData)
  }

  ionViewDidLoad() {
    // this.loadMap();
  }

  fetchLocation() {
    console.log('fetchLocation');
    console.log("this.platform.is('android') : ", this.platform.is('android'))
    this.geolocation.getCurrentPosition(this.platform.is('android') ? {timeout : 7000} : {}).then((position) => {
      this.loadMap(position.coords.latitude, position.coords.longitude);
      // var latlong = position.coords.latitude + ',' + position.coords.longitude;
      this.geoCodeLatLng(position.coords.latitude, position.coords.longitude).then((results: any) => {
        this.setLocation(results[0], position.coords.latitude, position.coords.longitude);
      });
    }).catch((err) => {
      console.log('fetchLocation Catch :', err);
    });
  }


  getMyLocation() {
    console.log('getMyLocation')
    if (!window['cordova']) {
      console.log('getMyLocation in Web')
      this.fetchLocation();
    } else {
      console.log('getMyLocation in Device')
      this.locationAccuracy.canRequest().then((canRequest: boolean) => {
        console.log(canRequest);
        this.locationAccuracy.request(this.locationAccuracy.REQUEST_PRIORITY_HIGH_ACCURACY).then(
          (data) => {
            console.log('Error rlocationAccuracy Then', data)
            this.fetchLocation();
          },
          error => {
            console.log('Error requesting location permissions', error)
          }
        ).catch((err) => {
          console.log('Error rlocationAccuracy Catch', err)
        });
      });
    }
  }


  dragendTimeout: any;
  loadMap(latitude: any = -33.868820, longitude: any = 151.209296) {

    let latLng = new google.maps.LatLng(latitude, longitude);
    let mapOptions = {
      center: latLng,
      zoom: 15,
      zoomControl: false,
      streetViewControl: false,
      overviewMapControl: false,
      mapTypeControl: false,
      mapTypeId: google.maps.MapTypeId.ROADMAP,
      styles: MAP_STYLE
    }
    this.map = new google.maps.Map(this.mapElement.nativeElement, mapOptions);
    google.maps.event.addListener(this.map, 'dragend', (event) => {
      this.addressData.showAddress = false;
      console.log("dragging");
      if (this.dragendTimeout) { //if there is already a timeout in process cancel it
        window.clearTimeout(this.dragendTimeout);
      }
      this.dragendTimeout = window.setTimeout(() => {
        this.dragendTimeout = null;
        console.log("user stopped dragging map");
        this.geoCodeLatLng(this.map.getCenter().lat(), this.map.getCenter().lng()).then((results: any) => {
          this.setLocation(results[0], this.map.getCenter().lat(), this.map.getCenter().lng());
        });
      }, 1000);
    });
    google.maps.event.trigger(this.map, 'resize');
    setTimeout(()=>{
      google.maps.event.trigger(this.map, 'resize');
    }, 500)
  }

  _timeout: any;
  fetchAddress(inputText) {
    console.log("typing");
    if (this._timeout) { //if there is already a timeout in process cancel it
      window.clearTimeout(this._timeout);
    }
    this._timeout = window.setTimeout(() => {
      this._timeout = null;
      console.log("user stopped typing");
      if (inputText) {
        this.updateSearch(inputText);
      } else {
        this.addressData.placeApiData = [];
      }
    }, 200);
  }
  selectAddress(index) {
    this.addressData.selectedAddress = this.addressData.placeApiData[index];
    var placeID: any = this.addressData.selectedAddress.place_id;
    this.addressData.showAddress = false;
    this.addressData.address = this.addressData.selectedAddress.description
    // this.addressData.showAddress = false
    this.cd.detectChanges();
    new google.maps.places.PlacesService(this.map).getDetails({
      placeId: placeID
    }, (place, status) => {
      if (status == "OK") {
        console.log('place : ', place)
        this.map.setOptions({ center: place.geometry.location });
        this.setLocation(place, place.geometry.location.lat(), place.geometry.location.lng());
      }
    });
  }

  setLocation(addressMain, latitude: any = '', longitude: any = '') {
    console.log("addressMain : ", addressMain)

    let addressArr = addressMain.address_components;
    this.addressData.address = addressMain.formatted_address;;

    let address: any = {
      address: ''
    }

    if (latitude) {
      address.latitude = latitude;
    }
    if (longitude) {
      address.longitude = longitude;
    }

    for (var ac = 0; ac < addressArr.length; ac++) {
      var component = addressArr[ac];
      switch (component.types[0]) {
        case 'administrative_area_level_1'://State
          address.state = component.long_name;
          break;
        case 'locality'://city
          address.city = component.long_name;
          address.suburb = component.long_name;
          break;
        case 'country'://Country
          address.country = component.long_name;
          break;
        case 'zipcode'://zipcode
          address.zipcode = component.long_name;
          break;
        case 'postal_code'://zipcode
          address.zipcode = component.long_name;
          break;
        case 'administrative_area_level_2':
          // no need to add
          break
        default:
          console.log("component : ", component)
          if ((ac > 0) && addressArr[ac - 1] && addressArr[ac - 1].types[0] == 'street_number') {
            address.address += address.address ? ' ' + component.long_name : component.long_name;
          } else {
            address.address += address.address ? ', ' + component.long_name : component.long_name;
          }
          break;
      }
    }

    if (!address.address) {
      address.address = addressMain.formatted_address;
    }

    if (!address.city) {
      address.city = address.state;
    }

    if (!address.country) {
      address.city = address.country;
    }

    this.addressData.finalAddress = address;
    console.log('this.addressData.finalAddress : ', this.addressData.finalAddress);

    google.maps.event.trigger(this.map, 'resize');
    this.cd.detectChanges(); //last comment
  }

  confirmLocation() {
    console.log("confirmLocation : ")
    this.isCustomerFlow = window.localStorage.getItem("customerFlow");
    //alert(this.isCustomerFlow);
    // if (this.addressData.finalAddress && this.addressData.finalAddress.address) {
    //   this.viewCtrl.dismiss(this.addressData.finalAddress)
    // }
    //alert(this.isCustomerFlow);

    if(this.navParams.get('updateLocation')){
      // console.log("this.httpService.getUserProperty('userDetails'):", )
      console.log("this.addressData.finalAddress :", this.addressData.finalAddress)
      this.httpService.httpRequest('POST', 'updateUserProfile', this.addressData.finalAddress)
      .then((response: any) => {
        this.httpService.presentToast(response.message);
        this.navCtrl.pop();
      }).catch((response: any) => {
        console.log('Error response : ', response)
      })
      return false;
    }

    if(!this.navParams.get('pickCustomerLocation')){
      this.viewCtrl.dismiss(this.addressData.finalAddress);
      return;
    }

    if (this.isCustomerFlow == 1) {
      this.httpService.httpRequest('GET', 'allowedCities', {})
      .then((response: any) => {
        console.log(response);
        let responseData: any = response;
        let allowedCities = responseData.result.cities;

        if (allowedCities && allowedCities.length) {
          for (let i = 0; i < allowedCities.length; i++) {
            if (allowedCities[i].cityName == this.addressData.finalAddress.city) {
              this.navCtrl.setRoot(TabsPage);
              return false;
            }
          }
          this.navCtrl.push(AppNotAvailablePage, {city : this.addressData.finalAddress.city});
        } else {
          this.navCtrl.push(AppNotAvailablePage, {city : this.addressData.finalAddress.city});
        }
      }).catch((response: any) => {
        console.log('Error response : ', response)
      })
    }else{
      if(this.navParams.get('pickCustomerLocation') && !window['cordova']){
        this.navCtrl.setRoot(TabsPage);
      }
    }

  }

  updateSearch(inputText) {
    if (inputText == '') {
      this.addressData.placeApiData = [];
      return;
    }
    // let me = this;
    this.service.getPlacePredictions({ input: inputText, location: new google.maps.LatLng(this.map.getCenter().lat(), this.map.getCenter().lng()), radius: 50 }, (predictions, status) => {
      this.addressData.placeApiData = [];
      if (status) {
        switch (status) {
          case "OK": {
            this.addressData.placeApiData = predictions;
            this.cd.detectChanges();
            break;
          }
          case "ZERO_RESULTS": {
            this.addressData.placeApiData = [{ description: ERROR_MESSAGES.noMapAddress }];
            this.cd.detectChanges();
            break;
          }
        }
      }
      if (this.addressData.placeApiData.length > 0) {
        this.addressData.showAddress = true;
      } else {
        this.addressData.showAddress = false;
      }
    });
  }

  geoCodeAddress(address: any) {
    let geocoder = new google.maps.Geocoder();
    return new Promise((resolve, reject) => {
      geocoder.geocode({ 'address': address }, (results, status) => {
        if ((status == "OK") && results.length) {
          resolve(results)
        } else {
          reject();
        }
      }, error => {
        reject();
      });
    })
  }

  geoCodeLatLng(lat, lng) {
    let geocoder = new google.maps.Geocoder();
    let latlng = new google.maps.LatLng(lat, lng)
    return new Promise((resolve, reject) => {
      geocoder.geocode({ 'location': latlng }, (results, status) => {
        if ((status == "OK") && results.length) {
          resolve(results)
        } else {
          reject();
        }
      }, error => {
        reject();
      });
    })
  }
}