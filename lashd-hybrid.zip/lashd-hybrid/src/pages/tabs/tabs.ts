import { Component, Inject, forwardRef } from '@angular/core';

import { HomePage } from './home/home';
import { ProfilePage } from '../profile/profile';

import { App } from 'ionic-angular';


import { TabAppointmentsPage } from './tab-appointments/tab-appointments';
import { TabChatPage } from './tab-chat/tab-chat';
import { TabNotificationsPage } from './tab-notifications/tab-notifications';
import { TabProfilePage } from './tab-profile/tab-profile';

import { HomeCustomerPage } from './home-customer/home-customer';

// Import main component
import { MyApp } from '../../app/app.component';

@Component({
  selector:'page-tab',
  templateUrl: 'tabs.html'
})
export class TabsPage {

  tabAppointmentsPage = TabAppointmentsPage
  tabChatPage = TabChatPage;
  tabNotificationsPage = TabNotificationsPage;
  // tabProfilePage = TabProfilePage;
  tabProfilePage = ProfilePage;
  tabServicesPage = (this.parent.userType == 2) ? HomePage : HomeCustomerPage;

  // tab1Root = HomePage;
  // tab2Root = HomePage;
  // tab3Root = HomePage;
  // tab4Root = ProfilePage; HomeCustomerPage
  constructor(@Inject(forwardRef(() => MyApp)) private parent: MyApp, private app : App) {

  }
  
  ionViewCanEnter(){
   if(!this.parent.httpService.isLoggedin && (this.parent.userType == 3)){
    this.app.getRootNav().setRoot(HomeCustomerPage);
   }
  }

}
