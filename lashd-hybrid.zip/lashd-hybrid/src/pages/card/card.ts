import { Component, Inject, forwardRef } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController } from 'ionic-angular';
import { HttpService } from '../../app/common/providers/http-service';
import { AddCardPage } from './add-card/add-card';

import { MyApp } from '../../app/app.component';

@IonicPage()
@Component({
  selector: 'page-card',
  templateUrl: 'card.html',
})
export class CardPage {
  cardsAvailable = true;
  cardData : any;
  cards = {
    '': 'url(assets/cardsIcon/icMasterCard@3x.png)',
    'visa': 'url(assets/cardsIcon/icVisa@3x.png)',
    'masterCard': 'url(assets/cardsIcon/icMasterCard@3x.png)',
    'amex': 'url(assets/cardsIcon/icAmex@3x.png)'
  }
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private httpService: HttpService,
    private alertCtrl : AlertController,
    @Inject(forwardRef(() => MyApp)) private parent: MyApp
    ) {

  }
  ionViewWillEnter() {
    this.httpService.httpRequest("GET", "cards", null, true)
      .then((response: any) => {
        console.log(response);
        this.cardData = response.result.data;
      })
      .catch(error => {
        console.log(error);
      });
  }
  removeCard(cardId, index){
    this.parent.blurryBG(true);
    let alert = this.alertCtrl.create({
      title: 'Remove Card',
      subTitle: 'Are you sure you want to remove this card.',
      cssClass:'two-button',
      enableBackdropDismiss : false,
      buttons: [
        {
          text : 'No',
          handler:()=>{this.parent.blurryBG();}
        },
        {
          text: 'Confirm',
          handler: data => {
            this.parent.blurryBG();
            this.httpService.httpRequest("POST", "removeCard", {cardId : cardId})
            .then((response: any) => {
              console.log(response);
              this.cardData.splice(index,1);
            })
            .catch(error => {
              console.log(error);
            });
          }
        }
      ]
    });
    alert.present();
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad CardPage');

  }
  addCard() {
    this.navCtrl.push(AddCardPage, { addCardFromSettings: true });
  }

}
