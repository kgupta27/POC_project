/**
 * 
 * Define Array of errors for use all over the app
 * 
 */

export let ERROR_MESSAGES = {
    "noConnection" : "Unable to connect to server, please check your network connection and try again.",
    "serverNotReturnJSONObject" : "There is some issue with the server, please try again.",
    "noData" : "There is no data to show",
    "unableToFatchLocation" : "We are unable to fetch your location",

    "locationServicesDisabled" : "Location services are disabled. Please go to Settings to enable your location services.",
    "locationServicesTimeout" : "Sorry! Unable to find your location right now, please enter your location.",


    invalidEmail : "Please enter a valid Email ID",
    
    spaceInPassword : "Please do not enter spaces in password",
    passwordLength : "Please enter a password between 6 to 14 characters",

    // firstCharacterSpace : "First character should not be a space in "++".",

    phoneNumberLength : "Please enter a valid mobile number",
    // onlyNumberfield : "Please enter only number",

    phoneNumberLengthCheck : "Please enter a mobile number between 6 to 12 digits",

    credentialsNotMatch :  "Credentials do not match",

    noImage : "Please select an image for product",
    maxImage : "You can upload maximum 20 photos",
    stillUploading : "Image still uploading on server",


    "timeError" : "End time should be greater than start time",
    
    timeDiff(time){
        // return "Start time and end time difference must be "+time+" hour(s)";
        return "Difference between start time and end time should be equal to number of operational hours";
    },
    
    priceError(fieldName){
        return "Please add valid "+fieldName+" (Required Format : 9999.99)"
    },

    blankField(fieldName){
        return "Please enter "+fieldName;
    },

    maxLength(fieldName , maxLength){
        // return "In "+fieldName+" max "+maxLength+" characters allowed"
        return "Maximum "+maxLength+" characters are allowed in "+fieldName;
    },

    allowedCharacters(fieldName, characters){
        // return "In "+fieldName+" only "+characters+" characters allowed"
        return "Emojis and special characters are not allowed in "+fieldName;
    },
    allowedNumbers(fieldName, characters){
        // return "In "+fieldName+" only "+characters+" characters allowed"
        // return "Alphabets, emojis and special characters are not allowed in "+fieldName;
        return "Emojis and special characters are not allowed in "+fieldName;
    },
    
    firstCharacterSpace(fieldName){
        return "First character should not be a space in "+fieldName;
    },

    "noMapAddress" : "Address not found",

    "workingPage" : "Page is still under progress",

    "titleButNotCertificate" : "Please upload a certificate or remove the title of certificate"
    
}



    