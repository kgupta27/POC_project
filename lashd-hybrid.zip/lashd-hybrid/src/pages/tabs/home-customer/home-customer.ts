import { Component, Inject, forwardRef } from '@angular/core';
// import { Component } from '@angular/core';
import { NavController, AlertController, ModalController, App } from 'ionic-angular';
import { SignUpOptionsPage } from '../../user/sign-up-options/sign-up-options';

import { MyApp } from '../../../app/app.component';
import { HttpService } from '../../../app/common/providers/http-service';

import { ViewServicePage } from '../../services/view-service/view-service';
import { AddServicePage } from '../../services/add-service/add-service';

import { ServicesPage } from '../../services/services';

import { getUserData } from '../../../app/common/config/global-functions';

@Component({
  selector: 'page-home-customer',
  templateUrl: 'home-customer.html'
})
export class HomeCustomerPage {
  categories;
  massageImageUrl = 'url(../assets/imgs/imgService2.jpg)';
  makeUpImageUrl = 'url(../assets/imgs/imgService3.jpg)';
  selectedCategory;
  servicesPage = ServicesPage;

  userName = getUserData('name');

  constructor(
    public navCtrl: NavController,
    private httpService:HttpService,
    private alertCtrl : AlertController,
    private app : App,
    private modalCtrl : ModalController,
    @Inject(forwardRef(() => MyApp)) private parent: MyApp
    ) {
      this.userName = getUserData('name');
  }

  ionViewDidLoad(){
   this.getAllCategoies();
  }

  getAllCategoies(){
    this.httpService.httpRequest("GET","unauthCategories",{}).then((response)=>{
      console.log("API categories",response['result']);
      if(response['result']){
        this.categories = response['result']['data']['data'];
      }
    })
    .catch((error)=>{
      console.log("error in fetching categories",error);
    });
  }

  selectCategory(id){
    /*
    if(this.selectedCategory == id){
      this.selectedCategory = '';
      return;
    }
    this.selectedCategory = id;
    */
  }

  viewService(category, subCategory) {
    category = JSON.parse(JSON.stringify(category));
    delete category.subCategories;
    let modal = this.modalCtrl.create(ViewServicePage, {
      category: category,
      subCategory: subCategory,
      parent : this.parent
    });
    modal.onDidDismiss(data => {
      this.parent.blurryBG();
      if (data) {
        if (data.action == 'delete') {
          this.getAllCategoies();
        }else{
          this.addService(data.category, data.subCategory)
        }
      }
    })
    modal.present();
  }

  addService(category, subCategory) {
    category = JSON.parse(JSON.stringify(category));
    delete category.subCategories;
    this.parent.blurryBG(true);
    console.log({category: category,
      subCategory: subCategory})
    let modal = this.modalCtrl.create(AddServicePage, {
      category: category,
      subCategory: subCategory
    });
    modal.onDidDismiss(data => {
      this.parent.blurryBG();
      if (data) {
        console.log("data added");
        this.getAllCategoies();
      }
    })
    modal.present();
  }

  goToSignUp(){
    this.parent.userType = 3;
    // this.navCtrl.push(SignUpOptionsPage);
    this.app.getRootNav().setRoot(SignUpOptionsPage);
  }


  logout(){
    this.parent.blurryBG(true);
    let alert = this.alertCtrl.create({
      title: 'Logout',
      subTitle: 'Are you sure you want to Logout from the app.',
      cssClass:'two-button',
      enableBackdropDismiss : false,
      buttons: [
        {
          text : 'No',
          handler: data => {
            this.parent.blurryBG();
          }
        },
        {
          text: 'Confirm',
          handler: data => {
            this.parent.userLogout();
            this.app.getRootNav().setRoot(SignUpOptionsPage);
          }
        }
      ]
    });
    alert.present();
  }
}
