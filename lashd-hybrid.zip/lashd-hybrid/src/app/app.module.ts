import { NgModule, ErrorHandler } from '@angular/core';
import { HttpModule } from '@angular/http';

import { BrowserModule } from '@angular/platform-browser';
import { IonicApp, IonicModule, IonicErrorHandler } from 'ionic-angular';
import { MyApp } from './app.component';

import { StatusBar } from '@ionic-native/status-bar';
import { SplashScreen } from '@ionic-native/splash-screen';
import { Device } from '@ionic-native/device';
import { Keyboard } from '@ionic-native/keyboard';
import { Facebook } from '@ionic-native/facebook';
import { Camera } from '@ionic-native/camera';
import { Diagnostic } from '@ionic-native/diagnostic';
import { OpenNativeSettings } from '@ionic-native/open-native-settings';
import { Clipboard } from '@ionic-native/clipboard';

//Custom Providers
import { HttpService } from '../app/common/providers/http-service';
import { KeyboardService } from '../app/common/providers/keyboard-service';
import { Image } from '../app/common/providers/get-image';
import { LocalDataArray } from '../app/common/providers/local-data-array';

//Custom Pipes
import { ErrorMessagesPipe } from '../app/common/pipes/error-messages';

//Custom modules
import { IntroScreensPageModule } from '../pages/intro-screens/intro-screens.module';
import { IntroScreensCustomerPageModule } from '../pages/intro-screens-customer/intro-screens-customer.module';
import { UserModule } from '../pages/user/user.module';
import { TabsModule } from '../pages/tabs/tabs.module';
import { ServicesPageModule } from "../pages/services/services.module";
import { ProfilePageModule } from '../pages/profile/profile.module';
import { CardPageModule } from '../pages/card/card.module';

@NgModule({
  declarations: [
    MyApp,
    ErrorMessagesPipe
  ],
  imports: [
    BrowserModule,
    HttpModule,
    IntroScreensPageModule,
    IntroScreensCustomerPageModule,
    UserModule,
    TabsModule,
    CardPageModule,
    ServicesPageModule,
    ProfilePageModule,
    IonicModule.forRoot(MyApp,{
      tabsHideOnSubPages: true,
      platforms: {
        ios : {
              swipeBackEnabled : false,
              // scrollPadding: true
              // scrollAssist: false, 
              // autoFocusAssist: false
        }
        // ios: {
        //   scrollPadding: false,
        //   scrollAssist: true,
        //   autoFocusAssist: false,
        // }
        /*, 
        android: {
          scrollPadding: false,
          scrollAssist: false,
          autoFocusAssist: false,
        }, */
      }
    }
    
    )
  ],
  bootstrap: [IonicApp],
  entryComponents: [
    MyApp
  ],
  exports : [],
  
  providers : [
    HttpService,
    KeyboardService,
    Image,
    LocalDataArray,
    StatusBar,
    SplashScreen, Device, Keyboard, Keyboard, Facebook,Camera,Diagnostic,OpenNativeSettings,Clipboard,
    {provide: ErrorHandler, useClass: IonicErrorHandler}

  ]
})
export class AppModule {}
