import { NgModule } from '@angular/core';
import { IonicPageModule, IonicModule } from 'ionic-angular';
import { ProfilePage } from './profile';
import { BrowserModule } from '@angular/platform-browser';
import { UserModule } from '../user/user.module';
import {ViewProfilePage} from "./view-profile/view-profile"
import {ChangePasswordPage} from "./change-password/change-password";
import {EditPersonalDetailsPage} from "./edit-personal-details/edit-personal-details"
@NgModule({
  declarations: [
    ProfilePage,
    ViewProfilePage,
    ChangePasswordPage,
    EditPersonalDetailsPage
  ],
  imports: [
      BrowserModule,
      IonicModule,
      UserModule
  ],
  entryComponents:[
    ProfilePage,
    ViewProfilePage,
    ChangePasswordPage,
    EditPersonalDetailsPage
  ]
})
export class ProfilePageModule {}
