import { Pipe, PipeTransform } from '@angular/core';
import { ERROR_MESSAGES } from '../config/error';


@Pipe({
  name: 'errorMsg',
})
export class ErrorMessagesPipe implements PipeTransform {
  transform(data : any, type : string) {
    return ERROR_MESSAGES[type];
  }
}
