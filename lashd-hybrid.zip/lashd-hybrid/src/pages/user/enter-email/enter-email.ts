// Ionic Default Modules
import { Component, Inject, forwardRef } from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

// Import main component
import { MyApp } from '../../../app/app.component';

// Import error messages
import { ERROR_MESSAGES } from '../../../app/common/config/error';

// Import constants
import { EMAIL_REGES } from '../../../app/common/config/constants';

// Import providers
import { HttpService } from '../../../app/common/providers/http-service';


@Component({
  selector: 'page-enter-email',
  templateUrl: 'enter-email.html',
})
export class EnterEmailPage {

  emailForm: FormGroup;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public fb: FormBuilder,
    private httpService: HttpService,
    private alertCtrl: AlertController,

    @Inject(forwardRef(() => MyApp)) private parent: MyApp
  ) {
    this.emailForm = fb.group({
      email: ['', [Validators.required, Validators.pattern(EMAIL_REGES), Validators.maxLength(50)]]
    })
  }

  ionViewWillEnter(){
    this.emailForm.reset();
  }

  createAccount(form) {

    if(!form.valid){
      /** Email Validation */
      if(!form.value.email){
        this.httpService.presentToast(ERROR_MESSAGES.blankField('Email'));
        return false;
      }

      if(!EMAIL_REGES.test(form.value.email)){
        this.httpService.presentToast(ERROR_MESSAGES.invalidEmail);
        return false;
      }
    }

    let postData = this.navParams.get('postData')
    postData.email = form.value.email;
    postData.customEmail = 1;

    let fbUserData = this.navParams.get('fbUserData')
    fbUserData.email = form.value.email;
    

    this.httpService.httpRequest('POST', 'fbSignUp', postData)
      .then((response: any) => {
        this.httpService.presentToast(response.message);
        this.showPopup(fbUserData);
      }).catch((response: any) => {
        console.log('Error response : ', response)
      })
  }

  showPopup(fbUserData) {
    this.parent.blurryBG(true);
    let alert = this.alertCtrl.create({
      title: 'Email verification',
      subTitle: 'A verification email has been sent to your email.',
      cssClass: 'one-button',
      enableBackdropDismiss: false,
      buttons: [
        {
          text: 'Ok',
          handler: data => {
            this.parent.blurryBG();
            let page = this.parent.getPage();
            this.navCtrl[page.type](page.page);
          }
        }
      ]
    });
    alert.present();
  }
}
