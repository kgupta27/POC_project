import { Component } from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';
import { EMAIL_REGES, PASSWORD_REGES, SPACE_REGES } from '../../../app/common/config/constants';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { HttpService } from '../../../app/common/providers/http-service';
import { ERROR_MESSAGES } from '../../../app/common/config/error';


/**
 * Generated class for the ChangePasswordPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-change-password',
  templateUrl: 'change-password.html',
})
export class ChangePasswordPage {
  changePasswordForm: FormGroup;
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private fb: FormBuilder,
    private httpService: HttpService,
    private alertCtrl: AlertController) {
    this.changePasswordForm = fb.group({
      oldPassword: ['', [Validators.required, Validators.pattern(PASSWORD_REGES), Validators.minLength(6), Validators.maxLength(14)]],
      password: ['', [Validators.required, Validators.pattern(PASSWORD_REGES), Validators.minLength(6), Validators.maxLength(14)]],
      confirmPassword: ['', [Validators.required, Validators.pattern(PASSWORD_REGES), Validators.minLength(6), Validators.maxLength(14)]]


    })
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ChangePasswordPage');
  }
  save(form) {

    /** Password Validation */
    if (!form.value.oldPassword) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('current password'));
      return false;
    }
    if (SPACE_REGES.test(form.value.oldPassword)) {
      this.httpService.presentToast(ERROR_MESSAGES.spaceInPassword);
      return false;
    }
    if (!((form.value.oldPassword.length >= 6) && (form.value.oldPassword.length <= 14))) {
      this.httpService.presentToast(ERROR_MESSAGES.passwordLength);
      return false;
    }

    if (!PASSWORD_REGES.test(form.value.oldPassword)) {
      // this.httpService.presentToast(ERROR_MESSAGES.validCharactersInPassword);
      this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('password', PASSWORD_REGES));
      return false;
    }
    if (!form.value.password) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('new password'));
      return false;
    }
    if (!((form.value.password.length >= 6) && (form.value.password.length <= 14))) {
      this.httpService.presentToast("Length of new password must be between 6 and 14 characters");
      return false;
    }
    if (!PASSWORD_REGES.test(form.value.password)) {
      // this.httpService.presentToast(ERROR_MESSAGES.validCharactersInPassword);
      this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('new password', PASSWORD_REGES));
      return false;
    }
    if (!form.value.confirmPassword) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('confirm password'));
      return false;
    }

    if (!(form.value.password === form.value.confirmPassword)) {
      this.httpService.presentToast("New password and confirm password must match.")
      return false;
    }
    form.value.userType = 2;
    form.value.newPassword = form.value.password;
    this.httpService.httpRequest("POST", "changePassword", form.value, true, true)
      .then((response) => {
        console.log("changePasswordResponse", response);
        let alert = this.alertCtrl.create({
          title: 'Password change',
          subTitle: response['message'],
          cssClass: 'one-button',
          enableBackdropDismiss: false,
          buttons: [
            {
              text: 'Ok',
              handler: data => {
                this.navCtrl.pop();
              }
            }
          ]
        });
        alert.present();
      })
      .catch((error) => {
        console.log("Error change Password", error);
      })
  }

}
