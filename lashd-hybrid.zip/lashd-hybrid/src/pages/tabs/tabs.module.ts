import { NgModule, ErrorHandler } from '@angular/core';

import { TabsPage } from './tabs';
import { HomePage } from './home/home';
import { HomeCustomerPage } from './home-customer/home-customer';

import { BrowserModule } from '@angular/platform-browser';
import { IonicModule, IonicErrorHandler } from 'ionic-angular';

import { TabAppointmentsPage } from './tab-appointments/tab-appointments';
import { TabChatPage } from './tab-chat/tab-chat';
import { TabNotificationsPage } from './tab-notifications/tab-notifications';
import { TabProfilePage } from './tab-profile/tab-profile';


@NgModule({
  declarations : [
    TabsPage,
    HomePage,
    HomeCustomerPage,
    TabAppointmentsPage,
    TabChatPage,
    TabNotificationsPage,
    TabProfilePage
  ],
  imports: [
    BrowserModule,
    IonicModule,
    // MultiPickerModule
  ],
  entryComponents : [
    TabsPage,
    HomePage,
    HomeCustomerPage,
    TabAppointmentsPage,
    TabChatPage,
    TabNotificationsPage,
    TabProfilePage
  ],
  providers: [
    {provide: ErrorHandler, useClass: IonicErrorHandler}
  ]
})
export class TabsModule {}
