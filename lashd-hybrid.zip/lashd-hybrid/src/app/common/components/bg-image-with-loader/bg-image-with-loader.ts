import { Component, Input } from '@angular/core';

@Component({
  selector: 'bg-image-with-loader',
  templateUrl: 'bg-image-with-loader.html',
})
export class BgImageWithLoader {

  @Input() image : string = '';
  @Input() type : string = '';
  @Input() dummyImage : string = 'assets/imgs/dummy-img.jpg';
  @Input() loaderImage : string = 'assets/imgs/image-loader.svg';
  isLoaderTimeExpired : boolean = false;

  ngAfterViewInit() {
    setTimeout(() => {
      if(!this.image){
        this.setImage();
      }
    }, 500)
    setTimeout(() => {
      this.setImage();
    }, 10000);
  }

  setImage(){
    if(this.type == 'user'){
      this.loaderImage = 'assets/imgs/user-img-laceholder.png'
    }else{
      this.loaderImage = this.dummyImage;
    }
    this.isLoaderTimeExpired  = true;
  }
}
