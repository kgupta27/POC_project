import { Component, Inject, forwardRef } from '@angular/core';
import { NavController, NavParams, ModalController } from 'ionic-angular';
import { HomePage } from '../../tabs/home/home';
import { HttpService } from '../../../app/common/providers/http-service';
import { convertAMPM } from '../../../app/common/config/global-functions';
import { CompleteAccountPage } from '../../user/complete-account/complete-account';
import { AddImagesPage } from '../../user/add-images/add-images';
import { EditPersonalDetailsPage } from '../edit-personal-details/edit-personal-details';
import { MyApp } from '../../../app/app.component';
import { AddLinkPage } from '../../user/add-link/add-link';

@Component({
  selector: 'page-view-profile',
  templateUrl: 'view-profile.html',
})
export class ViewProfilePage {
  userType=this.parent.userType;
  userProfile = {
    name: "",
    email: "",
    phoneNumber: ""
  }
  // userDetails = {};
  // creativeDetails = {};
  // userImages = [];

  userDetails : any;
  creativeDetails : any;
  userImages : any;

  selectedView = "personal";
  days: any = [
    { name: "Mon", active: true },
    { name: "Tue", active: true },
    { name: "Wed", active: true },
    { name: "Thu", active: true },
    { name: "Fri", active: true },
    { name: "Sat", active: false },
    { name: "Sun", active: false }
  ]
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private httpService: HttpService,
    private modalCtrl : ModalController,
    @Inject(forwardRef(() => MyApp)) private parent: MyApp
    ) {
      if(this.navParams.get('selectedView')){
        this.selectedView = this.navParams.get('selectedView');
      }
      // this.setupUserData();
  }

  ionViewDidLoad(){
    this.getUserData();
  }

  setupUserData(){
    this.userProfile.name = this.httpService.getUserProperty('name');
    this.userProfile.email = this.httpService.getUserProperty('email');
    this.userProfile.phoneNumber = this.httpService.getUserProperty('phoneNumber');
    this.userDetails = this.httpService.getUserProperty('userDetails');
    if (this.userDetails) {
      this.userDetails = this.userDetails[0];
    }

    console.log("this.userDetails : ", this.userDetails)

    this.creativeDetails = this.httpService.getUserProperty('creative');
    if (this.creativeDetails) {
      this.creativeDetails['startTime'] = convertAMPM(this.creativeDetails['startTime']);
      this.creativeDetails['endTime'] = convertAMPM(this.creativeDetails['endTime']);
      for (let day of this.days) {
        day.active = this.creativeDetails[`isAvail${day.name}`];
      }

    }
    this.userImages = this.httpService.getUserProperty('userImages');
  }

  getUserData(isLoading : boolean = true) {
    this.httpService.httpRequest("GET", "userProfile", {}, isLoading).then((response : any) => {
      this.httpService.storeAllUserDetails(response.result);
      this.setupUserData();

    })
      .catch((error) => {
        console.log("error in fetching User Data", error);
      })
    
  }

  goBack() {
    this.navCtrl.pop();
  }
  gotoEditPage() {
    // if(this.userType==3){
    //   this.navCtrl.push(EditPersonalDetailsPage,{userProfile:this.userProfile,userDetails:this.userDetails});      
    //   return;
    // }
    switch (this.selectedView) {
      
      case 'professional':
        //todo navigate to edit professional page
        this.navCtrl.push(CompleteAccountPage, {isEdit : true})
        break;
      case 'portfolio':
        //todo navigate to edit portfolio page
        this.navCtrl.push(AddImagesPage, {isEdit : true})
        break;
      default:
        this.navCtrl.push(EditPersonalDetailsPage,{userProfile:this.userProfile,userDetails:this.userDetails} );
        break;
    }
  }
  linkFb() {
    this.parent.blurryBG(true);
    let modal = this.modalCtrl.create(AddLinkPage, { type: 'facebook' });
    modal.onDidDismiss(data => {
      this.parent.blurryBG();
      if (data) {
        if (data.link) {
          this.httpService.httpRequest('POST', 'updateUserProfile', { facebookLink: data.link })
            .then((response: any) => {
              this.httpService.presentToast(response.message);
              this.setupUserData();
            }).catch((response: any) => {
              console.log('Error response : ', response)
            });
        }
      }
    });
    modal.present();
  }

  displayTime(a){
    var hours = Math.trunc(a/60);
    var minutes = a % 60;
    // console.log(hours +":"+ minutes);
    return ((hours.toString().length == 1) ? '0'+hours.toString() : hours) +":"+ ((minutes.toString().length == 1) ? '0'+minutes.toString() : minutes);
  }
}


