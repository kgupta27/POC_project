import { Injectable } from '@angular/core';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { ActionSheetController, AlertController } from 'ionic-angular';

@Injectable()
export class Image {
    constructor(
        public camera: Camera,
        private actionSheetCtrl: ActionSheetController,
        private alertCtrl: AlertController
    ) {

    }
    options: CameraOptions = {
        quality: 100,
        destinationType: this.camera.DestinationType.DATA_URL,
        sourceType: this.camera.PictureSourceType.CAMERA,
        encodingType: this.camera.EncodingType.JPEG,
        mediaType: this.camera.MediaType.PICTURE,
        targetWidth: 500,
        targetHeight: 500,
        allowEdit: true,
        saveToPhotoAlbum: false
    }
    optionsGallery: CameraOptions = {
        quality: 100,
        destinationType: this.camera.DestinationType.DATA_URL,
        sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
        encodingType: this.camera.EncodingType.JPEG,
        mediaType: this.camera.MediaType.PICTURE,
        targetWidth: 800,
        targetHeight: 800,
        allowEdit: true,
        saveToPhotoAlbum: false
    }

    get(allowEdit: boolean = true) {
        this.options.allowEdit = allowEdit;
        this.optionsGallery.allowEdit = allowEdit;
        return new Promise((resolve, reject) => {
            document.getElementsByTagName('body')[0].classList.add('app-blur');
            let alert = this.alertCtrl.create({
                title: 'Select from',
                cssClass: 'img-upload-options',
                buttons: [
                    {
                        text: 'Camara',
                        cssClass: 'camara-btn',
                        handler: data => {
                            this.camera.getPicture(this.options).then((ImageData) => {
                                resolve("data:image/jpeg;base64," + ImageData);
                            }).catch(data => console.log(data));
                        }
                    },
                    {
                        text: 'Gallery',
                        cssClass: 'gallery-btn',
                        handler: data => {
                            this.camera.getPicture(this.optionsGallery).then((ImageData) => {
                                resolve("data:image/jpeg;base64," + ImageData);
                            }).catch(data => console.log(data));
                        }
                    }
                ]
            });
            alert.present();

            alert.onDidDismiss(() => {
                document.getElementsByTagName('body')[0].classList.remove('app-blur');
            })

            /*
            let actionSheet = this.actionSheetCtrl.create({
                title: '',
                buttons: [
                    {
                        text: 'Take a Photo',
                        handler: () => {
                            this.camera.getPicture(this.options).then((ImageData) => {
                                resolve("data:image/jpeg;base64," + ImageData);
                            })
                                .catch(data => {

                                });
                        }
                    },
                    {
                        text: 'Choose From Gallery',
                        handler: () => {
                            this.camera.getPicture(this.optionsGallery).then((ImageData) => {
                                resolve("data:image/jpeg;base64," + ImageData);
                            })
                                .catch(data => {

                                });
                        }
                    },
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        handler: () => {
                            console.log('Cancel clicked');
                            reject();
                        }
                    }
                ]
            });
            actionSheet.present();*/
        })
    }
}



/*
import { Injectable } from '@angular/core';
import { Camera, CameraOptions } from '@ionic-native/camera';
import { Diagnostic } from '@ionic-native/diagnostic';


import { ActionSheetController, Platform } from 'ionic-angular';

@Injectable()
export class Image {

    cameraOpts: CameraOptions = {
        quality: 100,
        destinationType: this.camera.DestinationType.DATA_URL,
        encodingType: this.camera.EncodingType.JPEG,
        mediaType: this.camera.MediaType.PICTURE,
        correctOrientation: true,
        saveToPhotoAlbum: false
    };
    gallerOpts: any = {
        quality: 100,
        destinationType: this.camera.DestinationType.DATA_URL,
        encodingType: this.camera.EncodingType.JPEG,
        mediaType: this.camera.MediaType.PICTURE,
        correctOrientation: true,
        sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
        allowEdit: true
    };
    constructor(
        private diagnostic: Diagnostic,
        public plt: Platform,
        public actionSheetCtrl: ActionSheetController,
        private camera: Camera) {

    }

    get(allowEdit : boolean = true) {
        this.cameraOpts.allowEdit = allowEdit;
        this.gallerOpts.allowEdit = allowEdit;
        return new Promise((resolve, reject) => {
            let actionSheet = this.actionSheetCtrl.create({
                cssClass: "image-picker-sheet",
                buttons: [
                    {
                        text: 'Take Photo ',

                        handler: () => {
                            // this.checkCameraAccessAndTakePhoto(resolve, reject)
                            return this.checkCameraAccessAndTakePhoto(resolve, reject);
                            // resolve(this.checkCameraAccessAndTakePhoto(resolve, reject));
                        }
                    }, {
                        text: 'Choose From Gallery',
                        handler: () => {
                            this.checkGalleryAccessAndSelectPhoto(resolve, reject)
                            // return this.checkGalleryAccessAndSelectPhoto(resolve, reject);
                            // resolve(this.checkGalleryAccessAndSelectPhoto(resolve, reject));
                        }
                    }, {
                        text: 'Cancel',
                        role: 'cancel',
                        cssClass: 'cancel-button',
                        handler: () => {
                            reject('Pressed on cancel button');
                        }
                    }
                ]
            });
            actionSheet.present();
            return actionSheet;
        });
    }
    checkCameraAccessAndTakePhoto(resolve, reject) {
        if (this.plt.is('ios')) {
            return this.diagnostic.isCameraAuthorized()
                .then((authorized) => {
                    if (authorized) {
                        return this.getImgFromDevice(resolve, reject);
                    } else {
                        return this.diagnostic.getCameraAuthorizationStatus().then((status) => {
                            if (status == this.diagnostic.permissionStatus.NOT_REQUESTED) {
                                return this.diagnostic.requestCameraAuthorization()
                                    .then((status) => {
                                        if (status == this.diagnostic.permissionStatus.GRANTED) {
                                            return this.getImgFromDevice(resolve, reject);
                                        }
                                    }).catch(e => {
                                        console.error(e)
                                        reject(e);
                                    });
                            } else {
                                reject('go to settings');
                                this.diagnostic.switchToSettings();
                            }
                        }).catch(e => {
                            console.error(e)
                            reject(e);
                        });

                    }

                }).catch(e => {
                    console.error(e)
                    reject(e);
                })
        } else {
            return this.getImgFromDevice(resolve, reject);
        }
    }
    checkGalleryAccessAndSelectPhoto(resolve, reject) {
        if (this.plt.is('ios')) {
            return this.diagnostic.isCameraRollAuthorized()
                .then((authorized) => {
                    if (authorized) {
                        return this.getImgFromDevice(resolve, reject, true);
                    } else {
                        return this.diagnostic.getCameraRollAuthorizationStatus().then((status) => {
                            if (status == this.diagnostic.permissionStatus.NOT_REQUESTED) {
                                return this.diagnostic.requestCameraRollAuthorization()
                                    .then((status) => {
                                        if (status == this.diagnostic.permissionStatus.GRANTED) {
                                            return this.getImgFromDevice(resolve, reject, true);
                                        }
                                    }).catch(e => {
                                        console.error(e)
                                        reject(e);
                                    });
                            } else {
                                reject('go to settings');
                                this.diagnostic.switchToSettings();
                            }
                        }).catch(e => {
                            console.error(e)
                            reject(e);
                        });

                    }

                }).catch(e => {
                    console.error(e)
                    reject(e);
                })
        } else {
            return this.getImgFromDevice(resolve, reject, true);
        }

    }


    getImgFromDevice(resolve, reject, isGallery: boolean = false) {
        let opts = isGallery ? this.gallerOpts : this.cameraOpts;
        return this.camera.getPicture(opts).then(imageData => {
            resolve('data:image/jpeg;base64,' + imageData);
        })
        .catch(error => {
            reject(error);
        });
    }*/