import { NgModule } from '@angular/core';
import { CardPipe } from './card/card';
@NgModule({
	declarations: [CardPipe],
	imports: [],
	exports: [CardPipe]
})
export class PipesModule {}
