/**
 * 
 * Define Constants for use all over the app
 * 
 */

// export const EMAIL_REGES : RegExp = /^[\W]*([\w+\-.%]+@[\w\-.]+\.[A-Za-z]{2,4}[\W]*,{1}[\W]*)*([\w+\-.%]+@[\w\-.]+\.[A-Za-z]{2,10})[\W]*$/;

export const EMAIL_REGES : RegExp = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
export const URL_REGES : RegExp = /^(http:\/\/www\.|https:\/\/www\.|http:\/\/|https:\/\/)?[a-z0-9]+([\-\.]{1}[a-z0-9]+)*\.[a-z]{2,5}(:[0-9]{1,5})?(\/.*)?$/;

export const TEXT_REGES : RegExp = /^[A-Za-z ']*$/;
export const NUMBER_REGES : RegExp = /^[0-9]*$/;
export const NUMBER_FLOAT_REGES : RegExp = /^[+-]?\d+(\.\d+)?$/;
export const EMAIL_TEXT_REGES : RegExp = /^[A-Za-z_@.0-9]*$/;
export const PASSWORD_REGES : RegExp = /^[A-Za-z0-9\n.'?~`!@#$%^&*<>,-_]+$/;
export const TEXT : RegExp = /^[A-Za-z0-9\n.'?~`!@#$%^&*<> ,-_]+$/;
export const WITHOUT_FIRST_REGES : RegExp = /^[^-\s][a-zA-Z0-9_\s-]+$/;
export const DIGIT_FLOAT_REGES : RegExp = /^\d{0,4}(\.\d{1,2})?$/;

export const WITHOUT_FIRST_REGES_SPECIAL : RegExp = /^[^-\s][A-Za-z0-9\n.'?~`!@#$%^&*<>,-_\s-]+$/;

export const SPACE_REGES : RegExp = /^[\s]*$/;


export const CARD_TYPE = {
    visaRegexp : /^4[0-9]{6,}$/,
    ptMasterCard : /^5[1-5][0-9]{5,}$/,
    ptAmeExp : /^3[47][0-9]{5,}$/,
    ptDinClb : /^3(?:0[0-5]|[68][0-9])[0-9]{4,}$/,
    ptDiscover : /^6(?:011|5[0-9]{2})[0-9]{3,}$/,
    ptJcb : /^(?:2131|1800|35[0-9]{3})[0-9]{3,}$/
}

export const ROMOVE_SPACE : RegExp = /\s+/g;

export const LOADING_IMG : string = "assets/imgs/image-loader.svg";
export const USER_DEFAULT_IMG : string = "assets/imgs/user-img-default.png";
export const RETUEN_ICON : string = "return-left";

export const ACTIVE_DAYS : number = 90;
export const USE_UTC_DATES : boolean = true;