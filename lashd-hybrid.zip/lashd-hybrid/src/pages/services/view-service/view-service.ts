import { Component } from '@angular/core';
import { NavParams, ViewController, AlertController } from 'ionic-angular';
// import { NavController, NavParams, ViewController } from 'ionic-angular';


import { HttpService } from '../../../app/common/providers/http-service';

@Component({
  selector: 'page-view-service',
  templateUrl: 'view-service.html',
})
export class ViewServicePage {
  serviceName = "Hair Coloring";
  serviceType = "Hairstyle";
  serviceDuration = "20";
  servicePrice = "$ 40.00";
  serviceDescription = "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.";

  category : any = {};
  subCategory : any = {};
  parent : any;
  

  // constructor(public navCtrl: NavController, public navParams: NavParams, private viewCtrl : ViewController) {
  constructor(public navParams: NavParams, private viewCtrl : ViewController, private alertCtrl : AlertController, private httpService : HttpService) {
    this.category = this.navParams.get('category');
    this.subCategory = this.navParams.get('subCategory');
    this.parent = this.navParams.get('parent');

    console.log("subCategory : ", this.subCategory)
    console.log("category : ", this.category)
    

    this.serviceName = this.category.name;
    this.serviceType = this.subCategory.name;
    this.serviceDuration = this.subCategory.services[0].duration;
    this.servicePrice = this.subCategory.services[0].price;
    this.serviceDescription = this.subCategory.services[0].description;
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ViewServicePage');
  }

  deleteService(){
    this.parent.blurryBG(true);
    let alert = this.alertCtrl.create({
      title: 'Delete Service',
      subTitle: 'Are you sure you want to delete this service.',
      cssClass: 'two-button',
      enableBackdropDismiss: false,
      buttons: [
        {
          text: 'No',
          handler: popUpData => {
          }
        },
        {
          text: 'Confirm',
          handler: popUpData => {
            this.parent.blurryBG();
            this.httpService.httpRequest("POST", "deleteService", { serviceId: this.subCategory.services[0].id })
              .then((response: any) => {
                console.log(response);
                this.httpService.presentToast(response.message)
                this.viewCtrl.dismiss({action: 'delete', category : this.category, subCategory : this.subCategory})
                //viewCtrl.dismiss({action: 'delete', category : category, subCategory : subCategory})
              })
              .catch((error) => {
                console.log("Error in catching response", error);
              })
          }
        }
      ]
    });
    alert.present();
  }

}
