import { Component, forwardRef, Inject, ViewChild } from '@angular/core';
import { NavController, NavParams, Content, Platform } from 'ionic-angular';

import { FormBuilder, Validators, FormGroup } from '@angular/forms';

// Import main component
import { MyApp } from '../../../app/app.component';

// Import error messages
import { ERROR_MESSAGES } from '../../../app/common/config/error';

// Import constants
import { TEXT, NUMBER_REGES, SPACE_REGES } from '../../../app/common/config/constants';

// Import providers
import { HttpService } from '../../../app/common/providers/http-service';

// Import plugin modules
import { Keyboard } from '@ionic-native/keyboard';

import { getUserData } from '../../../app/common/config/global-functions'

@Component({
  selector: 'page-add-bank',
  templateUrl: 'add-bank.html',
})
export class AddBankPage {

  dobMax = (new Date().getFullYear()-13)+"-"+(((new Date().getMonth()+1).toString().length == 1) ? ('0'+(new Date().getMonth()+1).toString()) : new Date().getMonth()+1)+"-"+((new Date().getDate().toString().length == 1) ? '0'+new Date().getDate().toString() : new Date().getDate().toString());

  addBankForm: FormGroup;
  documentImage: any = '';

  isEdit: boolean = false;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public fb: FormBuilder,
    private httpService: HttpService,
    private keyboard: Keyboard,
    private platform: Platform,
    @Inject(forwardRef(() => MyApp)) private parent: MyApp
  ) {
    console.log("dobMax : ", this.dobMax);
    this.addBankForm = fb.group({
      name: ['', [Validators.required, Validators.pattern(TEXT), Validators.maxLength(50)]],
      dob: ['', [Validators.required, Validators.pattern(TEXT), Validators.maxLength(100)]],
      accountNumber: ['', [Validators.required, Validators.pattern(TEXT), Validators.maxLength(50)]],
      confirmAccountNumber: ['', [Validators.required, Validators.pattern(TEXT), Validators.maxLength(50)]],

      bsb: ['', [Validators.required, Validators.pattern(NUMBER_REGES), Validators.minLength(6), Validators.maxLength(6)]],
      // address: ['', [Validators.required, Validators.pattern(TEXT), Validators.maxLength(100)]],
      // city: ['', [Validators.required, Validators.pattern(TEXT), Validators.maxLength(50)]],
      // state: ['', [Validators.required, Validators.pattern(TEXT), Validators.maxLength(50)]],

      address: ['', [Validators.required, Validators.maxLength(100)]],
      city: ['', [Validators.required, Validators.maxLength(50)]],
      state: ['', [Validators.required, Validators.maxLength(50)]],

      postalCode: ['', [Validators.required, Validators.pattern(NUMBER_REGES), Validators.minLength(10), Validators.maxLength(10)]]
    })

    this.addBankForm.controls['bsb'].valueChanges.subscribe(value => {
      if (value && value.toString().length > 6) {
        this.addBankForm.controls['bsb'].setValue(value.toString().substr(0, 6));
      }
    });

    this.addBankForm.controls['postalCode'].valueChanges.subscribe(value => {
      if (value && value.toString().length > 4) {
        this.addBankForm.controls['postalCode'].setValue(value.toString().substr(0, 4));
      }
    });

    if (this.navParams.get('isEdit')) {
      this.isEdit = this.navParams.get('isEdit');
      this.httpService.httpRequest('GET', 'getUserBank', {}, true, false)
        .then((response: any) => {
          let bank: any = response.result.data;
          this.addBankForm.controls['name'].setValue(bank.firstName + ' ' + bank.lastName);
          this.addBankForm.controls['dob'].setValue(bank.dob);
          this.addBankForm.controls['accountNumber'].setValue(bank.accountNumber);
          this.addBankForm.controls['confirmAccountNumber'].setValue(bank.accountNumber);
          this.addBankForm.controls['bsb'].setValue(bank.bsb);

          this.addBankForm.controls['address'].setValue(bank.address);
          this.addBankForm.controls['city'].setValue(bank.city);
          this.addBankForm.controls['state'].setValue(bank.state);
          this.addBankForm.controls['address'].setValue(bank.address);
          this.addBankForm.controls['postalCode'].setValue(bank.postalCode);

        }).catch((response: any) => {
          console.log('Error response : ', response)
          this.fillDetails();
        })
    } else {
      this.fillDetails();
    }
  }

  fillDetails(){
      let userData: any = getUserData('userData', true);
      console.log("userData : ", userData)
      if (userData && userData.userDetails.length && userData.userDetails[0]) {
        if (userData.userDetails[0].address) {
          this.addBankForm.controls['address'].setValue(userData.userDetails[0].address);
        }
        if (userData.userDetails[0].city) {
          this.addBankForm.controls['city'].setValue(userData.userDetails[0].city);
        }
        if (userData.userDetails[0].state) {
          this.addBankForm.controls['state'].setValue(userData.userDetails[0].state);
        }
        if (userData.userDetails[0].zipcode) {
          this.addBankForm.controls['postalCode'].setValue(userData.userDetails[0].zipcode);
        }

        if (userData.name) {
          this.addBankForm.controls['name'].setValue(userData.name);
        }
      }
  }

  @ViewChild(Content) content: Content;
  onPageScroll(event) {
    console.log(event.target.scrollTop);
    this.keyboard.close();
  }

  // ngAfterViewInit() {
  //   this.platform.ready().then(() => {
  //     if (window['cordova'] && this.platform.is('ios')) {
  //       this.content.ionScrollEnd.subscribe((data) => {
  //         this.keyboard.close()
  //       })
  //     }
  //   })
  // }

  addBank(form) {

    this.addBankForm.controls['name'].setValue(form.value.name);
    this.addBankForm.controls['address'].setValue(form.value.address);
    this.addBankForm.controls['city'].setValue(form.value.city);
    this.addBankForm.controls['state'].setValue(form.value.state);


    form.value.name = this.parent.trimSpace(form.value.name);
    form.value.address = this.parent.trimSpace(form.value.address);
    form.value.city = this.parent.trimSpace(form.value.city);
    form.value.state = this.parent.trimSpace(form.value.state);

    this.addBankForm.controls['name'].setValue(this.parent.trimSpace(form.value.name));
    this.addBankForm.controls['address'].setValue(this.parent.trimSpace(form.value.address));
    this.addBankForm.controls['city'].setValue(this.parent.trimSpace(form.value.city));
    this.addBankForm.controls['state'].setValue(this.parent.trimSpace(form.value.state));

    // if(!form.valid){

    /** Name */
    if (!form.value.name) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('your name'));
      return false;
    }
    if (SPACE_REGES.test(form.value.name[0])) {
      this.httpService.presentToast(ERROR_MESSAGES.firstCharacterSpace('name'));
      return false;
    }
    if (form.value.name.length > 50) {
      this.httpService.presentToast(ERROR_MESSAGES.maxLength('name', 50));
      return false;
    }
    if (!TEXT.test(form.value.name)) {
      this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('name', TEXT));
      return false;
    }


    /** DOB */
    if (!form.value.dob) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('date of birth'));
      return false;
    }

    /** Account Number */
    if (!form.value.accountNumber) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('account number'));
      return false;
    }
    if (!((form.value.accountNumber.toString().length >= 8) && (form.value.accountNumber.toString().length <= 16))) {
      this.httpService.presentToast('Account number must be  8 to 16 digit');
      return false;
    }

    if (!NUMBER_REGES.test(form.value.accountNumber)) {
      this.httpService.presentToast(ERROR_MESSAGES.allowedNumbers('account number', NUMBER_REGES));
      return false;
    }

    /** Confirm Account Number */
    if (!form.value.confirmAccountNumber) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('confirm account number'));
      return false;
    }

    if (form.value.accountNumber != form.value.confirmAccountNumber) {
      this.httpService.presentToast("Account number and confirm account number are not same");
      return false;
    }

    /** Postal code */
    if (!form.value.bsb) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('BSB'));
      return false;
    }
    if (form.value.bsb.toString().length != 6) {
      this.httpService.presentToast("BSB must be 6 digit");
      return false;
    }
    if (!NUMBER_REGES.test(form.value.bsb)) {
      this.httpService.presentToast(ERROR_MESSAGES.allowedNumbers('BSB', NUMBER_REGES));
      return false;
    }

    /** Address */
    if (!form.value.address) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('address'));
      return false;
    }
    if (SPACE_REGES.test(form.value.address[0])) {
      this.httpService.presentToast(ERROR_MESSAGES.firstCharacterSpace('address'));
      return false;
    }
    if (form.value.address.length > 100) {
      this.httpService.presentToast(ERROR_MESSAGES.maxLength('address', 100));
      return false;
    }
    // if (!TEXT.test(form.value.address)) {
    //   this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('address', TEXT));
    //   return false;
    // }

    /** City */
    if (!form.value.city) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('city'));
      return false;
    }
    if (SPACE_REGES.test(form.value.city[0])) {
      this.httpService.presentToast(ERROR_MESSAGES.firstCharacterSpace('city'));
      return false;
    }
    if (form.value.city.length > 100) {
      this.httpService.presentToast(ERROR_MESSAGES.maxLength('city', 100));
      return false;
    }
    // if (!TEXT.test(form.value.city)) {
    //   this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('city', TEXT));
    //   return false;
    // }

    /** Address */
    if (!form.value.state) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('state'));
      return false;
    }
    if (SPACE_REGES.test(form.value.state[0])) {
      this.httpService.presentToast(ERROR_MESSAGES.firstCharacterSpace('state'));
      return false;
    }
    if (form.value.state.length > 100) {
      this.httpService.presentToast(ERROR_MESSAGES.maxLength('state', 100));
      return false;
    }
    // if (!TEXT.test(form.value.state)) {
    //   this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('state', TEXT));
    //   return false;
    // }

    /** Postal code */
    if (!form.value.postalCode) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('postal code'));
      return false;
    }
    if (form.value.postalCode.toString().length != 4) {
      this.httpService.presentToast("postal code must be 4 digit");
      return false;
    }
    if (!NUMBER_REGES.test(form.value.postalCode)) {
      this.httpService.presentToast(ERROR_MESSAGES.allowedNumbers('postal code', NUMBER_REGES));
      return false;
    }

    if (!this.documentImage) {
      this.httpService.presentToast('Please upload a document to verify your account');
      return false;
    }

    form.value.documentImage = this.documentImage;

    let data = form.value.name.split(' ');

    if (data.length == 1) {
      form.value.firstName = data[0];
    } else if (data.length > 1) {
      form.value.lastName = data[data.length - 1];
      data.splice(data.length - 1, 1);
      form.value.firstName = data.join(' ');
    }

    if (!form.value.lastName) {
      form.value.lastName = form.value.firstName;
    }

    this.httpService.httpRequest('POST', 'updateBankAccount', form.value)
      .then((response: any) => {
        this.httpService.storeAllUserDetails(response.result);
        if (this.isEdit) {
          this.navCtrl.pop();
        } else {
          let page = this.parent.getPage();
          this.navCtrl[page.type](page.page);
        }
      }).catch((response: any) => {
        console.log('Error response : ', response)
      })
  }

  uploadImage() {
    this.parent.image.get(false).then((img) => {
      this.documentImage = img;
    })
  }

  skipBank() {
    this.httpService.httpRequest('POST', 'updateUserProfile', { isBankSkip: true })
      .then((response: any) => {
        this.httpService.storeAllUserDetails(response.result)
        let page = this.parent.getPage();
        this.navCtrl[page.type](page.page);
      }).catch((response: any) => {
        console.log('Error response : ', response)
      })
  }

}
