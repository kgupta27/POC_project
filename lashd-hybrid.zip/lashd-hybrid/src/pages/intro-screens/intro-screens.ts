import { Component, Inject, forwardRef } from '@angular/core';
import { NavController } from 'ionic-angular';
import { SignUpOptionsPage } from '../user/sign-up-options/sign-up-options';
import { IntroScreensCustomerPage } from '../intro-screens-customer/intro-screens-customer';

import { HttpService } from '../../app/common/providers/http-service';


// Import main component
import { MyApp } from '../../app/app.component';


@Component({
  selector: 'page-intro-screens',
  templateUrl: 'intro-screens.html',
})
export class IntroScreensPage {

  canGoBack : boolean = false;

  constructor(
    public navCtrl: NavController,
    @Inject(forwardRef(() => MyApp)) private parent: MyApp,
    private httpService : HttpService,
    ) {
      this.canGoBack = this.navCtrl.canGoBack() && this.httpService.isLoggedin;

  }

  ionViewDidLoad(){
    // this.canGoBack = this.navCtrl.canGoBack() && this.httpService.isLoggedin;
    // setTimeout(()=>{
    //   this.canGoBack = this.navCtrl.canGoBack() && this.httpService.isLoggedin;
    // }, 100);
    setTimeout(()=>{
      this.canGoBack = this.navCtrl.canGoBack() && this.httpService.isLoggedin;
    }, 300);
    setTimeout(()=>{
      this.canGoBack = this.navCtrl.canGoBack() && this.httpService.isLoggedin;
    }, 500);
    console.log("this.canGoBack load : ", this.canGoBack)
  }

  ionViewCanEnter(){
   this.parent.userType = 2;
  }

  goToLogin(){
    this.navCtrl.setRoot(SignUpOptionsPage);
  }

  gotoCustomerIntro(){
    this.parent.userType = 3;
    this.navCtrl.setPages([{page : IntroScreensCustomerPage}]);
  }
}
