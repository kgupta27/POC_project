import { Injectable } from '@angular/core';
import { Http, Headers } from '@angular/http';
import { APIS, SERVER_NAME } from '../config/config';
import { ERROR_MESSAGES } from '../config/error';
import { LoadingController, ToastController, App } from 'ionic-angular';

// import * as moment from "moment-timezone";

import { LocalDataArray } from './local-data-array';
// import { convertRelativeTime, convertDate } from '../config/global-functions';
// import { convertRelativeTime } from '../config/global-functions';
// import { USE_UTC_DATES } from '../config/constants';

// pages
import { SignUpOptionsPage } from '../../../pages/user/sign-up-options/sign-up-options';

/**
 * 
 * Provider for handle HTTP Requests all over the app
 * 
 */

@Injectable()
export class HttpService {

    isLoggedin: boolean;
    AuthToken = '';
    UserID; name; phone;
    loader;
    skipCreditCard: 0;
    creditCardAdded = 0;
    IsNetworkConnection = false;
    toast: any;
    needToGoLogin = false;

    constructor(
        public http: Http,
        public loadingCtrl: LoadingController,
        public toastCtrl: ToastController,
        private localDataArray: LocalDataArray,
        private app: App
    ) {

        this.http = http;
        this.isLoggedin = false;
        this.AuthToken = null;
        this.name = '';
        this.phone = '';
        this.loadUserCredentials();
    }
    // presentLoading(content : string = 'Loading', duration : any = false)
    presentLoading(className: string = 'custom-loader', duration: any = false) {
        // console.log("presentLoading this.loader : ", this.loader);
        // if(this.loader && (this.loader._state != 4)){
        //     console.log("this.loader.dismiss() : ", this.loader._state);
        //     this.loader.dismiss();
        // }

        let loaderData: any = {
            content: "<div class='custom-loader-main'><img src='assets/imgs/loader.svg'/></div>",
            duration: duration ? duration : 8000,
            cssClass: className,
            spinner: 'hide',
            dismissOnPageChange : true
        }

        this.loader = this.loadingCtrl.create(loaderData);
        this.loader.present();
    }


    presentToast(msg, img: string = '') {

        // console.log(this.toast);
        // console.log("presentToast this.toast : ", this.toast);

        // if(this.toast && (this.toast._state != 4)){
        //     console.log("this.toast.dismiss(); ", this.toast._state);
        //     this.toast.dismiss();
        // }

        let toastArr = {
            message: msg,
            position: 'top',
            cssClass: img ? 'toast-icon ' + img : '',
            // dismissOnPageChange : true,
            duration: 3000
        };
        if (msg) {
            this.toast = this.toastCtrl.create(toastArr);
            this.toast.present();
        }

    }

    storeAllUserDetails(allUserDetails) {
        if (allUserDetails) {
            if (allUserDetails.user) {
                window.localStorage.setItem('allUserDetails', JSON.stringify(allUserDetails.user));
            } else if (allUserDetails.data) {
                window.localStorage.setItem('allUserDetails', JSON.stringify(allUserDetails.data));
            } else {
                window.localStorage.setItem('allUserDetails', JSON.stringify(allUserDetails));
            }
        }

    }

    storeUserCredentials(token, userId, userdata) {
        console.log('storeUserCredentials : ', arguments)
        window.localStorage.setItem('access_token', token);
        window.localStorage.setItem('user_id', userId);
        window.localStorage.setItem('userData', userdata);
        window.localStorage.setItem('introViewed', "true");
        this.useCredentials(token, userId, userdata);
        this.getCreditCard(userdata);
    }

    getCreditCard(userData) {
        try {
            userData = JSON.parse(userData);
        } catch (e) {
            this.skipCreditCard = 0;
            this.creditCardAdded = 0;
        }
        this.skipCreditCard = (userData && userData.skipCreditCard) ? userData.skipCreditCard : 0;
        this.creditCardAdded = (userData && userData.creditCardAdded) ? userData.creditCardAdded : 0;
    }

    useCredentials(token, userId, userdata) {
        // this.presentLoading();
        // console.log('token : '+token+"-------"+'userId : '+userId+"==="+'userdata : ',userdata)
        this.isLoggedin = false;
        this.AuthToken = token;
        this.UserID = userId;
        this.getCreditCard(userdata);
        if ((this.AuthToken && (this.AuthToken != undefined) && (this.AuthToken != 'undefined')) && this.UserID) {
            this.isLoggedin = true;
        }
    }

    loadUserCredentials() {
        let token = window.localStorage.getItem('access_token');
        let userId = window.localStorage.getItem('user_id');
        let userdata = window.localStorage.getItem('userData');
        this.useCredentials(token, userId, userdata);
    }

    getUserProperty(propertyName) {
        let userdata = JSON.parse(window.localStorage.getItem('userData'));
        if (userdata) {
            return userdata[propertyName];
        }
        else
            return null;
    }

    destroyUserCredentials() {
        this.isLoggedin = false;
        this.AuthToken = null;
        this.UserID = null;
        window.localStorage.clear();
        window.localStorage.setItem('introViewed', "true");
        this.needToGoLogin = true;
    }

    getApiUrl(apiName) {
        let url: string = SERVER_NAME + APIS[apiName];
        return url;
    }

    getHeader() {
        this.loadUserCredentials();
        var headers = new Headers();
        if (this.AuthToken) {
            headers.append('accessToken', this.AuthToken);
        }

        //   headers.append('userTimezoneOffset', new Date().getTimezoneOffset().toString());
        //   headers.append('userTimezoneName', moment.tz.guess());

        return headers;
    }

    /**
     * Main Request Function
     * 
     * @param type {string} => can be GET and POST
     * @param apiName {string} => get name of api so the get the url accordingly
     * @param data {object} => data to be post (only in case of post request)
     * @param showSuccessLoader {boolean} => loader to be shown on not
     * @param showErrorInToast {boolean} => error toast to be shown on not
     * 
     */

    httpRequest(
        type: string,
        apiName: string,
        data: any,
        showSuccessLoader: boolean = true,
        showErrorInToast: boolean = true,
        previousData: any = ''
    ) {
        if (showSuccessLoader) {
            this.presentLoading();
            console.log(this.AuthToken);
        }
        return new Promise((resolve, reject) => {
            // console.log("request : ", JSON.stringify(data));
            let request;
            let headers = this.getHeader();
            let apiurl = this.getApiUrl(apiName);
            if (type === 'GET') {
                if (data) {
                    let getArguments = ''
                    for (var key in data) {
                        if (key === 'length' || !data.hasOwnProperty(key)) continue;
                        // var value = data[key];

                        if (getArguments) {
                            getArguments = '&' + key + '=' + data[key];
                        } else {
                            getArguments = '?' + key + '=' + data[key];
                        }

                        apiurl += getArguments;
                    }
                }
                request = this.http.get(apiurl, { headers: headers });
            } else {
                if ((apiName == 'signUp') || (apiName == 'fbSignUp') || (apiName == 'signIn')) {
                    let device = { "id": this.localDataArray.deviceId, "type": this.localDataArray.deviceType, "token": this.localDataArray.deviceToken };
                    data = Object.assign(data, { "device": device });
                }
                // if(this.AuthToken && (this.AuthToken != undefined) && (this.AuthToken != 'undefined')){
                //     userDevice['token'] = this.AuthToken;
                // }
                request = this.http.post(apiurl, data, { headers: headers });
            }

            request
                .subscribe(data => {
                    // console.log("success : ", JSON.stringify(data));
                    if (showSuccessLoader && this.loader) {
                        this.loader.dismiss();
                    }
                    this.successHandler(resolve, reject, data, showErrorInToast, previousData, apiName);
                }, data => {
                    // console.log("Error : ", JSON.stringify(data));
                    if (showSuccessLoader && this.loader) {
                        this.loader.dismiss();
                    }
                    this.errorHandler(resolve, reject, data, showErrorInToast);
                });
        })
    }

    makeResolveData(isError: boolean, data: any) {
        if (!data) {
            data = {};
        }
        data.isError = isError;
        return data;
    }

    successHandler(resolve, reject, data, showErrorInToast, previousData, apiName) {
        // console.log('error handler response',data);
        let response;
        try {
            response = data.json()
        } catch (e) {
            this.presentToast(ERROR_MESSAGES.serverNotReturnJSONObject)
            reject(this.makeResolveData(true, response))
        }

        if (response.success && (response.statusCode === 200)) {
            //Update userdetails in localstorage
            console.log('0 : ', response)
            if (response.result && response.result.user) {
                console.log('if 1 : ', response.result.user)
                if (response.result.user.userDetails) {
                    let details = response.result.user.userDetails;
                    console.log('if 2 : ', details)

                    if (details[0] && details[0].id) {
                        console.log('if 3 : ', details[0].id)

                        if (response.result.user.userDevices) {
                            console.log('if 4 : ', response.result.user.userDevices)

                            let devices = response.result.user.userDevices;
                            if (devices[0] && devices[0].accessToken) {
                                console.log('if 5 : ', devices[0] && devices[0].accessToken)

                                this.storeUserCredentials(devices[0].accessToken, details[0].id, JSON.stringify(response.result.user));
                            }
                        }
                    }
                }
            }

            /*
            if(response.result && response.result.user && response.result.user.userDetails && response.result.user.userDetails.id && response.result.userDevices && response.result.userDevices[0] && response.result.userDevices[0].accessToken){
                this.storeUserCredentials(response.result.userDevices[0].accessToken , response.result.user.userDetails.id, JSON.stringify(response.result.user));
            }

            
            if((apiName == 'getNotificationList') && response && response.result && response.result.data && response.result.data.length){
                response.result.data.forEach(newData => {
                    newData.relativeTime = convertRelativeTime(newData.updatedAt, true);
                });
            }

            if(USE_UTC_DATES){
                
                if(((apiName == 'rentedProducts') || (apiName == 'get-my-rentals')) && response && response.result && response.result.data && response.result.data.length){
                    response.result.data.forEach(newData => {
                        newData.startDate = convertDate(newData.startDate, 'UTC', 'local').dateFull;
                        newData.endDate = convertDate(newData.endDate, 'UTC', 'local').dateFull;
                        newData.offerSentDate = convertDate(newData.offerSentDate, 'UTC', 'local').dateFull;
                    });
                }
                if((apiName == 'getRateReasons') && response && response.result && response.result.bookingDetails){
                    response.result.bookingDetails.startDate = convertDate(response.result.bookingDetails.startDate, 'UTC', 'local').dateFull;
                    response.result.bookingDetails.endDate = convertDate(response.result.bookingDetails.endDate, 'UTC', 'local').dateFull;
                }
                if((apiName == 'getMyBookingDetails') && response && response.result){
                    response.result.startDate = convertDate(response.result.startDate, 'UTC', 'local').dateFull;
                    response.result.endDate = convertDate(response.result.endDate, 'UTC', 'local').dateFull;
                }
            }*/

            // console.log('previousData Out: ', previousData);
            if (previousData) {
                if (previousData.data && previousData.data.data && previousData.data.data.length) {
                    // console.log('previousData : ', previousData)
                    let previousApiData: any = previousData.data;
                    // console.log('previousApiData : ', previousApiData)

                    if (previousData.arrayType == 'default') {
                        previousApiData.pagination = response.result.pagination
                        if (response.result.data.length) {
                            response.result.data.forEach(newData => {
                                previousApiData.data.push(newData);
                            });
                        }
                        response.result = previousApiData;
                    } else {
                        if ((typeof previousData.arrayType == 'object') && typeof previousData.arrayType.length) {
                            let newDataArr: any;
                            // let responseData : any = {};
                            for (let i = 0; i < previousData.arrayType.length; i++) {
                                newDataArr = newDataArr ? newDataArr[previousData.arrayType[i]] : response[previousData.arrayType[i]];
                                // responseData[previousData.arrayType[i]] = {};
                            }

                            // console.log('responseData : ', responseData);

                            previousApiData.pagination = newDataArr.pagination
                            if (newDataArr.data.length) {
                                newDataArr.data.forEach(newData => {
                                    previousApiData.data.push(newData);
                                });
                            }
                            let responseData: any = {};
                            for (let i = 0; i < previousData.arrayType.length; i++) {
                                responseData[previousData.arrayType[i]] = {};
                                if (i == previousData.arrayType.length - 1) {
                                    responseData[previousData.arrayType[i]] = previousApiData;
                                }
                            }
                            // console.log('responseData : ', responseData);
                            // debugger;
                            // responseData = previousApiData;
                            // response.result = responseData;
                            // debugger;
                            // resolve(responseData);
                            response = responseData
                        }
                    }
                    // console.log('response.result : ', response.result)
                    resolve(response);
                } else {
                    resolve(response);
                }
            } else {
                resolve(response)
            }

        } else {
            if (response.message && response.statusCode) {
                this.handleErrorByErrorCode(response, showErrorInToast);
            }
            reject(this.makeResolveData(true, response));
        }
    }
    errorHandler(resolve, reject, data, showErrorInToast) {
        // console.log('error handler showErrorInToast',showErrorInToast);
        let response;
        try {
            response = data.json()
        } catch (e) {
            // if(showErrorInToast){
            if (!response) {
                this.presentToast(ERROR_MESSAGES.noConnection, 'icon-error');
            } else {
                if (response.status) {
                    this.presentToast(ERROR_MESSAGES.serverNotReturnJSONObject, 'icon-error');
                } else {
                    this.presentToast(ERROR_MESSAGES.noConnection, 'icon-error');
                }
            }
            // }
        }

        response = this.makeResolveData(true, response);

        if (response.status_code) {
            response.statusCode = response.status_code;
        }

        if (response.message && response.statusCode) {
            this.handleErrorByErrorCode(response, showErrorInToast);
        }
        else {
            // if(showErrorInToast){
            if (!response) {
                this.presentToast(ERROR_MESSAGES.noConnection, 'icon-error');
            } else {
                if (response.status) {
                    this.presentToast(ERROR_MESSAGES.serverNotReturnJSONObject, 'icon-error');
                } else {
                    this.presentToast(ERROR_MESSAGES.noConnection, 'icon-error');
                }
            }
            // }
        }
        reject(response);
    }
    handleErrorByErrorCode(response: any, showToast) {
        console.log('handleErrorByErrorCode : ', !!(showToast || (response.statusCode === 401)));
        if (showToast || (response.statusCode === 401)) {
            this.presentToast(response.message, 'icon-warning');
        }
        switch (response.statusCode) {// session expire
            case 401: {
                this.logout();
                this.isLoggedin = false;
                this.app.getRootNav().setRoot(SignUpOptionsPage);
            }
        }
    }

    logout() {
        this.destroyUserCredentials();
    }

}