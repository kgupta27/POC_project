import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { IntroScreensCustomerPage } from './intro-screens-customer';

@NgModule({
  declarations: [
    IntroScreensCustomerPage,
  ],
  imports: [
    IonicPageModule.forChild(IntroScreensCustomerPage),
  ],
  entryComponents : [
    IntroScreensCustomerPage,
  ]
})
export class IntroScreensCustomerPageModule {}
