import { Component, Output, EventEmitter } from '@angular/core';
import { NavController, NavParams, ViewController } from 'ionic-angular';
// import { NavController, NavParams, Platform, ViewController } from 'ionic-angular';
import * as $ from 'jquery';
import {Http} from '@angular/http';


@Component({
  selector: 'country-code',
  templateUrl: 'country-code.html',
})
export class CountryCodePage {
    pos:any = -9999;
    posMin:any = -9999;
    selectedCountry : any = {};
    //hourAccess:boolean = false;
    //minAccess:boolean = false;
    @Output() timeChanged : EventEmitter<any> = new  EventEmitter<any>();
    mainDiv = 'main-scroll-list';
  constructor(
      public navCtrl: NavController, 
      public navParams: NavParams, 
    //   private platform: Platform,
      private http : Http,
      private viewCtrl : ViewController
      ) {
          setTimeout(()=>{
              try{
                  this.getCountries();
              }catch(e){console.log(e)}
          }, 50);

          this.selectedCountry = this.navParams.get('selectedCountry');
          //console.log("this.selectedCountry : ", this.selectedCountry)
          let selectCtry;
          if(this.selectedCountry && this.selectedCountry.countryCode && this.selectedCountry.countryFullName){
            selectCtry = JSON.parse(JSON.stringify(this.selectedCountry));
          }

          setTimeout(()=>{
            if(selectCtry && selectCtry.countryCode){
                let main : any = document.getElementById(this.mainDiv);
                if(main){
                    main.scrollTop = selectCtry.position.min;
                }
            }
        }, 100)
  }

  scrollData : any = {};
  countries : any = [];

  onScroll(event){
        // this.changeScroll();
        // //console.log('Angular  event : ', event);
        if (this.scrollData.scroll_static) {
            //console.log('start scrolling');
            this.scrollData.scroll_static = false;
        }
        if (this.scrollData.TO !== false) { clearTimeout(this.scrollData.TO); }
        this.scrollData.TO = setTimeout(() => {
            this.scrollData.scroll_static = true;
            this.fixposition();
        }, 10);
    }

    scrollPrev(){
        var elementMain = document.getElementById(this.mainDiv);
        elementMain.scrollTop = this.countries[this.selectedCountry.index-1].position.min;
    }
    scrollNext(){
        var elementMain = document.getElementById(this.mainDiv);
        elementMain.scrollTop = this.countries[this.selectedCountry.index+1].position.min;
    }

    getCountries(){
        // let mainHeight : any = document.getElementById('main-scroll-list').clientHeight;
        let heightBox = 65;
        this.http.get("assets/json/country.json")
        .subscribe(data => {
        //console.log('S data', data.json());
        let jsonData = data.json();

        jsonData.forEach((element, i) => {
            element.position = {};
            element.position.min = (i == 1) ? 0  :(((i) * heightBox));
            element.position.max = (((i+1) * heightBox));
        });
        //console.log('jsonData : ', jsonData);
        this.countries = jsonData;
        this.setUpEvents();
        }, data => {
        //console.log('E data', data.json());
        // this.countries = data.json();
        })
    }
    setUpEvents() {
        //console.log('ngAfterViewInit: ');
        this.scrollData.element = document.getElementById(this.mainDiv);
        this.scrollData.TO = false;
        this.scrollData.scroll_static = true;
        this.scrollData.element.addEventListener('touchstart', (event: any) => {
            this.fixposition(true);
        }, false);
        setTimeout(() =>{
            this.fixposition();
        }, 100)
    }

   ngAfterViewInit(){
    this.getCountries();
   }
    
    fixposition(needToTriggerClick : boolean = false){
        let idVal;
        this.pos = $("#ele-1").position().top;
        //console.log("pos:", this.pos);
        let val = this.pos* -1;
        for (var i = 0; i < this.countries.length; i++) {
            if ((this.countries[i].position.min <= val) && (this.countries[i].position.max >= val)) {
                idVal = i;
                //console.log('this.countries[i] :', this.countries[i+1]);
                this.selectedCountry = this.countries[i+1];
                this.selectedCountry.index = i+1;
                if(!this.selectedCountry){
                    this.selectedCountry = this.countries[i];
                    this.selectedCountry.index = i;
                }
                break;
            }
        }
        //console.log("id val", idVal);
        
        if(!idVal && idVal != 0){
            return;
        }
        let id = 'ele'+idVal;
        var element = document.getElementById(id);
        var elementMain = document.getElementById(this.mainDiv);
        //console.log("element.offsetTop", element.offsetTop);
        elementMain.scrollTop = (element.offsetTop);
        // let post = idVal +2;
        // $('#'+this.mainDiv+' *').removeAttr('style');
        // $('#ele'+idVal).css('opacity','.1');
        // $('#ele'+post).css('opacity','.1');

        

        /*
        if(this.platform.is('ios')){
            if(needToTriggerClick){
                if(this.active == 'AM'){
                    //this.active = 'PM';
                    $('#PMTime').trigger('click');
                    setTimeout(()=>{
                        //this.active = 'AM'
                        $('#AMTime').trigger('click');
                    }, 10)
                }else{
                    //this.active = 'AM';
                    $('#AMTime').trigger('click');
                    setTimeout(()=>{
                        //this.active = 'PM';
                        $('#PMTime').trigger('click');
                    }, 10)
                }
                $('#calendar-block').trigger('click');
            }
        }*/

        // this.timeChanged.emit({hourVal:this.hour, minuteVal:this.minute, circle: this.active});
             
    }

    closePage(selectValue : boolean = false){
        this.viewCtrl.dismiss(selectValue ? this.selectedCountry : null)
    }
  

}
