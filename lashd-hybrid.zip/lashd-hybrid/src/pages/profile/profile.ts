import { Component, Inject, forwardRef } from '@angular/core';
import { IonicPage, NavController, NavParams, AlertController, App } from 'ionic-angular';
import { MyApp } from '../../app/app.component';
import { SignUpOptionsPage } from '../user/sign-up-options/sign-up-options';
import { ViewProfilePage } from './view-profile/view-profile';
import { TermsAndConditionsPage } from '../user/terms-and-conditions/terms-and-conditions';
import { IntroScreensPage } from '../intro-screens/intro-screens';
import { IntroScreensCustomerPage } from '../intro-screens-customer/intro-screens-customer';
import { PrivacyPolicyPage } from '../user/privacy-policy/privacy-policy';
import { AddBankPage } from '../user/add-bank/add-bank';
import { ChangePasswordPage } from './change-password/change-password';

// import { AddCardPage } from '../card/add-card/add-card';
import { CardPage } from '../card/card';
import { MapLocationPage } from '../user/map-location/map-location';

import { HttpService } from '../../app/common/providers/http-service';

import { getUserData } from '../../app/common/config/global-functions';


@Component({
  selector: 'page-profile',
  templateUrl: 'profile.html',
})
export class ProfilePage {
  name;
  profilePhoto;
  introScreensPage = IntroScreensPage;
  cardPage = CardPage;
  // userType = this.parent.userType;

  isSocial = getUserData('isSocial');

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams,
    private httpService:HttpService,
    @Inject(forwardRef(() => MyApp)) private parent: MyApp,
    private alertCtrl : AlertController, 
    private app : App   
  ) {
    this.name = this.httpService.getUserProperty('name');
    let userDetails = this.httpService.getUserProperty('userDetails');
    if(userDetails)  
      this.profilePhoto = userDetails[0].profileImage;
  }

  goToIntro(){
    if(this.parent.userType == 2){
      this.navCtrl.push(IntroScreensPage)
    }else{
      this.navCtrl.push(IntroScreensCustomerPage);
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ProfilePage');
  }
  logout(){
    //this.parent.blurryBG(true);
    let alert = this.alertCtrl.create({
      title: 'Logout',
      subTitle: 'Are you sure you want to Logout from the app.',
      cssClass:'two-button',
      enableBackdropDismiss : false,
      buttons: [
        {
          text : 'No',
          handler:()=>{this.parent.blurryBG();}
        },
        {
          text: 'Confirm',
          handler: data => {
            this.parent.blurryBG();
            this.parent.userLogout();
            // this.navCtrl.setRoot(SignUpOptionsPage);
            this.app.getRootNav().setRoot(SignUpOptionsPage);
          }
        }
      ]
    });
    alert.present();
  }
  changePassword(){
    this.navCtrl.push(ChangePasswordPage);
  }

  editAccountDetails(){
    this.navCtrl.push(AddBankPage, {isEdit : true})
  }

  goToViewProfile(){
    this.navCtrl.push(ViewProfilePage);

  }

  goToTermsAndConditionsPage(){
    this.navCtrl.push(TermsAndConditionsPage);
    
  }
  goToPrivacyPolicyPage(){
    this.navCtrl.push(PrivacyPolicyPage);
  }

  switchRole(){
    /*
    this.parent.blurryBG(true);
    let alert = this.alertCtrl.create({
      title: 'Switch Role',
      subTitle: 'Are you sure you want to switch you role.',
      cssClass:'two-button',
      enableBackdropDismiss : false,
      buttons: [
        {
          text : 'No',
          // handler:()=>{this.parent.blurryBG();}
        },
        {
          text: 'Confirm',
          handler: data => {
            this.parent.blurryBG();
            this.httpService.httpRequest('GET', 'changeRole', {})
            .then((response: any) => {
              this.httpService.storeAllUserDetails(response.result)
              this.parent.userType = response.result.userType;
              let page = this.parent.getPage();
              // this.navCtrl[page.type](page.page);
              this.app.getRootNav().setRoot(page.page);
            }).catch((response: any) => {
              console.log('Error response : ', response)
            })
          }
        }
      ]
    });
    alert.present();
    */
  }

  updateLocation(){
    this.navCtrl.push(MapLocationPage, {updateLocation : true})
  }

}
