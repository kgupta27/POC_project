import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import 'rxjs/add/operator/map';
// import {Observable} from 'rxjs/Rx'

// import { LocalDataArray } from './local-data-array'
@Injectable()
export class GooglePlacesProvider {
  googleApiKey = 'AIzaSyAelzSWVXt6beRM6lMCzu6TRQ3x3rWrxNU';
  constructor(public http: Http) {
    
  }

  
  getUser(query, lat : any = '', lng : any = '', ){
    if(query){
      let requestURl = "https://maps.googleapis.com/maps/api/place/queryautocomplete/json?types=address&key="+this.googleApiKey+"&input="+query;
      if(lat && lng){
        requestURl += "&location="+lat+","+lng;
      }
      console.log("getUser : ", query, lat, lng, requestURl)
      return this.http.get(requestURl)
      .map((res:Response) => res.json());
    }
  }

  /*
  getUser(query){
    console.log('this.googleApiKey : ', this.googleApiKey);
    return this.http.get(`https://maps.googleapis.com/maps/api/place/autocomplete/json?input=`+query+`&types=address&key=`+this.googleApiKey)
    .map((res:Response) => res.json());
     
  }*/
  getCoords(placeId) {
    console.log(placeId);
    return this.http.get(`https://maps.googleapis.com/maps/api/place/details/json?placeid=`+placeId+`&key=`+this.googleApiKey)
    .map((res:Response) => res.json()); 
  }
  getAddress(query) {
    return this.http.get(`https://maps.googleapis.com/maps/api/geocode/json?latlng=`+query+`&key=`+this.googleApiKey)
    .map((res:Response) => res.json()); 
  }
  getLatLng(query) {
    return this.http.get(`https://maps.googleapis.com/maps/api/geocode/json?address=`+query+`&key=`+this.googleApiKey)
    .map((res:Response) => res.json()); 
  }
}
