// import * as moment from 'moment';
// import { ERROR_MESSAGES } from './error';
// import 'moment/locale/pt-br';
import * as moment from 'moment';

export function convertDateTime(date : any = ''){
  if(date){
    date = date.toString();
    date = date.split(' ');
    let time = date[1];
    if(time){
      time = time.split(':');
    }else{
      time = [0,0,0];
    }
    
    date = date[0];
    date = date.split('-');
    let returnDate = new Date(parseInt(date[0]), parseInt(date[1])-1, parseInt(date[2]), parseInt(time[0]), parseInt(time[1]), parseInt(time[2]));
    return returnDate;
  }
}
export function convertDateSmall(dateOrg){
  if(dateOrg){
    dateOrg = dateOrg.split(' ');
    let date = dateOrg[0];
    date = date.split('-');
    // let time = dateOrg[1];
    // time = time.split(':')
    // let returnDate = new Date(parseInt(date[0]), parseInt(date[1])-1, parseInt(date[2]),parseInt(time[0]), parseInt(time[1]), parseInt(time[2]));
    let returnDate = new Date(parseInt(date[0]), parseInt(date[1])-1, parseInt(date[2]));
    return returnDate;
  }
}

export function  convertAMPM(timeString, notampm : boolean = false){
  if(timeString){
    var hourEnd = timeString.indexOf(":");
    var H = +timeString.substr(0, hourEnd);
    var h = (H == 0) ? '00' : (H % 12) || 12;
    //var h = (H % 12) || 12;
    
    var ampm = (H == 12) ? " am" : ((H < 12 ) ? " am" : " pm");
    let time;
    if(notampm){
      time = h + timeString.substr(hourEnd, 3);
    }else{
      time = h + timeString.substr(hourEnd, 3) + ampm;
    }
    return time;
  }
}

export function setUserData(key, value, isAll : boolean = false){
  if(isAll){
    window.localStorage.setItem(key, JSON.stringify(value));
    return true;
  }
  let allUserData : any = getUserData('data', true);
  if(allUserData){
    allUserData[key] = value;
    window.localStorage.setItem('userData', JSON.stringify(allUserData));
  }else{
    return false;
  }
}

export function getUserData(data, isAllData : boolean = false){
  let allUserData = window.localStorage.getItem('userData')
  if(allUserData){
    try{
      allUserData = JSON.parse(allUserData);
      if(isAllData){
        return allUserData;
      }else if(allUserData[data]){
        return allUserData[data]
      }else{
        return false;
      }
    }catch(e){
      return false;
    }
  }else{
    return false;
  }
}

function mantainToDigit(val){
  return (val.length === 2)? val : ('0'+val);
}

/** Convert Date
 * 
 * LOCAL to UTC
 * and
 * UTC to LOCAL
 * 
 * @param date {date} input date
 * @param currentTimeZone {string} input timezone
 * @param returnTimeZone {string} output timezone
 * @param returnFormat {string} output date/time
 * 
 * 
 */
export function convertDate(date : any, currentTimeZone : any = 'local', returnTimeZone : any = 'UTC', returnFormat : any = ''){

  //moment.tz.guess(); get current timezone
  let format = returnFormat ? returnFormat : 'YYYY-MM-DD HH:mm:ss';
  let returnDate : any= '' ;

  if(date.indexOf('.000000')){
    date = date.split('.000000')[0];
  }

  // console.log('date.length :'+date.length)
  if(date && (date.length !== 19)){
    let d = date.split(' ');
    let dateMain = d[0].split('-');
    let timeMain = d[1].split(':');

    let day = dateMain[2];
    let month = dateMain[1];
    let year = dateMain[0];
    let hh = timeMain[0];
    let mm = timeMain[1];
    let ss = timeMain[2];

    date = year+'-'+mantainToDigit(month)+'-'+mantainToDigit(day)+' '+mantainToDigit(hh)+':'+mantainToDigit(mm)+':'+mantainToDigit(ss)
    // console.log('dateTOReturn :'+date);
  }
  
  //console.log('moment(date).format(format) :'+moment(date).format(format));

  // Set current date if date if not present
  if(!date){
    date = Date.now();
    date = moment(date).format(format);
    currentTimeZone = 'local';
  }
  
  // console.log('currentTimeZone : '+currentTimeZone);
  if(currentTimeZone === 'local'){
    // console.log('local date : ', date);
    // console.log("moment(date).utc() :", moment(date).utc());

    let localDateUTC;
    // console.log('moment(date).isValid()'+moment(date).isValid())
    // console.log('moment(new Date(date)).isValid()'+moment(new Date(date)).isValid())
    // console.log('moment(Date.now()).isValid()'+moment(Date.now()).isValid())
    //if(moment(date).isValid()){
      localDateUTC = moment(date).utc().format(format);
    //}
    
    // else if(moment(new Date(date)).isValid()){
    //   localDateUTC = moment(new Date(date)).utc().format(format);
    // }else if(moment(Date.now()).isValid()){
    //   localDateUTC = moment(Date.now()).utc().format(format);
    // }
    
    //console.log('localDateUTC : '+localDateUTC);
    returnDate = localDateUTC;
  }else if(currentTimeZone === 'UTC'){
    var UTCToLocal = moment.utc(date).local().format(format);
    returnDate = UTCToLocal;
  }

  return {
    dateFull : returnDate,
    dateOrg : returnDate.split(' ')[0],
    timeOrg : returnDate.split(' ')[1],
    date : moment(returnDate).format('DD/MM/YY'),
    time : moment(returnDate).format('hh:mma')
  };
}

export function cropText(txt, cropLength : number = 117){
  let newText = txt.substr(0, cropLength);
  if(txt.length > cropLength){
    newText += ' ...';
  }
  return newText;
}

export function copyObject(obj){
  let data : any = {};
  try{
    data = JSON.parse(JSON.stringify(obj))
  }catch(e){
   return data; 
  }
  return data;
}

export function convertRelativeTime(datetime, needToConvertInLocal){
  if(needToConvertInLocal){
    datetime = convertDate(datetime, 'UTC', 'local').dateFull;
  }
  moment.updateLocale('en', {
        relativeTime : {
            future: "in %s",
            past:   "%s ago",
            s  : 'a few seconds',
            ss : '%d secs',
            m:  "a minute",
            mm: "%d mins",
            h:  "an hour",
            hh: "%d hours",
            d:  "a day",
            dd: "%d days",
            M:  "a month",
            MM: "%d months",
            y:  "a year",
            yy: "%d years"
        }
    });
    let date : any = convertDateTime(datetime);
    date = moment(date).fromNow();
    // console.log('date : ', date);
    return date;
}

export function convertBookingDataToRentedData(data){
  return {
    "bookingId":data.booking.id,
    "bookingPrice":data.booking.price,
    "deliveryAmount":data.booking.deliveryAmount,
    "startDate":data.booking.startDate,
    "endDate":data.booking.endDate,
    "securityDeposit":data.booking.securityDeposit,
    "status":data.booking.status,
    "unitRental":data.booking.unitRental,
    "totalUnit":data.booking.totalUnit,
    "deliveryAddress":data.booking.deliveryAddress,
    "isDeliverable":data.booking.isDeliverable,
    "bookingLat":data.booking.latitude,
    "bookingLong":data.booking.longitude,
    "bookingAddress":data.booking.address,
    "bookingZipcode":data.booking.zipcode,
    "bookingSuburb":data.booking.suburb,
    "bookingState":data.booking.state,
    "bookingCountry":data.booking.country,
    "userImage":data.fromUser.profileImage,
    "userName":data.fromUser.name,
    "ratingCount":0,
    "avgRating":4,
    "address":"",
    "zipcode":"",
    "suburb":"",
    "state":"",
    "country":"",
    "userId":111,
    "productId":data.booking.product.id,
    "name":data.booking.product.name,
    "brandName":data.booking.product.brandName,
    "price":data.booking.product.price,
    "description":data.booking.product.description,
    "productImage":data.booking.product.imageName,
    "productType":data.booking.product.type,
    "minServiceHours":data.booking.product.minServiceHours,
    "offerSentDate":""
  }
}

export function getServiceDateTime(startDateTime, endDateTime, inDateFormat : boolean = false){
  // startDateTime = new Date(startDateTime);
  // endDateTime = new Date(endDateTime);
  if(!inDateFormat){
    startDateTime = convertDateTime(startDateTime);
    endDateTime = convertDateTime(endDateTime);
  }else{
    startDateTime = new Date(startDateTime);
    endDateTime = new Date(endDateTime);
  }
  
  let startDate = new Date(startDateTime.getFullYear(), startDateTime.getMonth(), startDateTime.getDate()).getTime();
  let endDate = new Date(endDateTime.getFullYear(), endDateTime.getMonth(), endDateTime.getDate()).getTime();
  
  let date = '';
  if(startDate == endDate){
    date = moment(startDateTime).format('DD MMM hh:mm a') +" to "+moment(endDateTime).format('hh:mm a');
  }else{
    date = moment(startDateTime).format('DD MMM hh:mm a') +" to "+moment(endDateTime).format('DD MMM hh:mm a');
  }

  return date;
}
export function getServiceDate(startDateTime, endDateTime, inDateFormat : boolean = false){

  if(!inDateFormat){
    startDateTime = convertDateTime(startDateTime);
    endDateTime = convertDateTime(endDateTime);
  }else{
    startDateTime = new Date(startDateTime);
    endDateTime = new Date(endDateTime);
  }
  let startDate = new Date(startDateTime.getFullYear(), startDateTime.getMonth(), startDateTime.getDate()).getTime();
  let endDate = new Date(endDateTime.getFullYear(), endDateTime.getMonth(), endDateTime.getDate()).getTime();
  
  let date = '';
  if(startDate == endDate){
    date = moment(startDateTime).format('DD MMM');
  }else{
    date = moment(startDateTime).format('DD MMM') +" to "+moment(endDateTime).format('DD MMM');
  }

  return date;
}

/** Add style at run time
 * 
 * @param url {string} url of the style
 * @param charset {string} charset of the style
 * 
 */
export function addStyle(url, charset : any  = false) {
	if (url) {
		var link = document.querySelector("link[href*='" + url + "']");
		if (!link) {
			var heads = document.getElementsByTagName("head");
			if (heads && heads.length) {
				var head = heads[0];
				if (head) {
					link = document.createElement('link');
					link.setAttribute('href', url);
					link.setAttribute('rel', 'stylesheet');
					link.setAttribute('type', 'text/css');
					if (charset)
						link.setAttribute('charset', charset);
					head.appendChild(link);
				}
			}
		}
		return link;
	}
}