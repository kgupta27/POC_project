// Ionic Default Modules
import { Component, Inject, forwardRef } from '@angular/core';
import { NavController, NavParams, AlertController } from 'ionic-angular';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

// Import main component
import { MyApp } from '../../../app/app.component';

// Import error messages
import { ERROR_MESSAGES } from '../../../app/common/config/error';

// Import constants
import { EMAIL_REGES } from '../../../app/common/config/constants';

// Import providers
import { HttpService } from '../../../app/common/providers/http-service';


@Component({
  selector: 'page-forgot-password',
  templateUrl: 'forgot-password.html',
})
export class ForgotPasswordPage {

  emailForm: FormGroup;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public fb: FormBuilder,
    private httpService: HttpService,
    private alertCtrl: AlertController,

    @Inject(forwardRef(() => MyApp)) private parent: MyApp
  ) {
    this.emailForm = fb.group({
      email: ['', [Validators.required, Validators.pattern(EMAIL_REGES), Validators.maxLength(50)]]
    })
  }

  ionViewWillEnter(){
    this.emailForm.reset();
  }

  createAccount(form) {

    if(!form.valid){
      /** Email Validation */
      if(!form.value.email){
        this.httpService.presentToast(ERROR_MESSAGES.blankField('Email'));
        return false;
      }

      if(!EMAIL_REGES.test(form.value.email)){
        this.httpService.presentToast(ERROR_MESSAGES.invalidEmail);
        return false;
      }
    }

    this.httpService.httpRequest('POST', 'forgotPassword', {email : form.value.email, userType : this.parent.userType})
    .then((response: any) => {
      this.httpService.presentToast(response.message);
      this.navCtrl.pop();
    }).catch((response: any) => {
      console.log('Error response : ', response)
    })
  }

}
