import { Component, forwardRef, Inject } from '@angular/core';

import { AlertController, NavController } from 'ionic-angular';

// import { SignUpOptionsPage } from '../../../../pages/user/sign-up-options/sign-up-options';


import { MyApp } from '../../../app.component';


@Component({
selector: 'custom-back',
  templateUrl: 'custom-back.html'
})
export class CustomBackComponent {
  constructor(
    private navCtrl : NavController, 
    private alertCtrl:AlertController,
    @Inject(forwardRef(() => MyApp)) private parent: MyApp
    ){}

  logout(){
    this.parent.blurryBG(true);
    let alert = this.alertCtrl.create({
      title: 'Logout',
      subTitle: 'Are you sure you want to Logout from the app.',
      cssClass:'two-button',
      enableBackdropDismiss : false,
      buttons: [
        {
          text : 'No',
          handler: data => {
            this.parent.blurryBG();
          }
        },
        {
          text: 'Confirm',
          handler: data => {
            this.parent.userLogout('signUpOptions', 'true');
          }
        }
      ]
    });
    alert.present();
  }
}
