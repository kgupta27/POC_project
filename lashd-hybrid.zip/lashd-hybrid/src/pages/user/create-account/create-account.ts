// Ionic Default Modules
import { Component, Inject, forwardRef } from '@angular/core';
import { NavController, NavParams, ModalController } from 'ionic-angular';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';

// Import main component
import { MyApp } from '../../../app/app.component';

// Import error messages
import { ERROR_MESSAGES } from '../../../app/common/config/error';

// Import constants
import { TEXT, NUMBER_REGES, SPACE_REGES } from '../../../app/common/config/constants';

// Import providers
import { HttpService } from '../../../app/common/providers/http-service';

// Import global functions
import { getUserData } from '../../../app/common/config/global-functions';

// Import plugin modules
// import { Camera, CameraOptions } from '@ionic-native/camera';

// Import Pages
import { MapLocationPage } from '../map-location/map-location';
import { CountryCodePage } from '../country-code/country-code';


@Component({
  selector: 'page-create-account',
  templateUrl: 'create-account.html',
})
export class CreateAccountPage {
  createAccountForm: FormGroup;
  selectedCountry: any;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private modalCtrl: ModalController,
    public fb: FormBuilder,
    private httpService: HttpService,

    @Inject(forwardRef(() => MyApp)) private parent: MyApp
  ) {
    this.createAccountForm = fb.group({
      phoneNumber: ['', [Validators.required, Validators.pattern(NUMBER_REGES), Validators.minLength(10), Validators.maxLength(10)]],
      // address: ['', [Validators.required, Validators.pattern(TEXT), Validators.maxLength(100)]],
      // city: ['', [Validators.required, Validators.pattern(TEXT), Validators.maxLength(50)]],
      // country: ['', [Validators.required, Validators.pattern(TEXT), Validators.maxLength(50)]],
      address: ['', [Validators.required, Validators.maxLength(100)]],
      city: ['', [Validators.required, Validators.maxLength(50)]],
      country: ['', [Validators.required, Validators.maxLength(50)]],
      state: [''],
      zipcode: [''],
      latitude: [''],
      longitude: [''],
      countryCode: [''],
    })

    this.createAccountForm.controls['phoneNumber'].valueChanges.subscribe(value => {
      // if(value){
      //   let intVal = parseInt(value);
      //   console.log("intVal : ", intVal, (intVal != NaN))
      //   if(!intVal || (intVal == NaN)){
      //     this.createAccountForm.controls['phoneNumber'].setValue(null);
      //   }else{
      //     this.createAccountForm.controls['phoneNumber'].setValue(intVal);
      //   }
        
      // }
      if(value && value.toString().length > 12){
        // this.createAccountForm.controls['phoneNumber'].setValue(parseInt(value.toString().substr(0,12)));
        this.createAccountForm.controls['phoneNumber'].setValue(value.toString().substr(0,12));
      }
    });

  }

  getAddressFromMap() {
    let modal = this.modalCtrl.create(MapLocationPage);
    modal.onDidDismiss(data => {
      if (data) {
        console.log("getAddressFromMap data : ", data)
        this.createAccountForm.controls.address.setValue(data.address);
        this.createAccountForm.controls.city.setValue(data.city);
        this.createAccountForm.controls.country.setValue(data.country);

       this.createAccountForm.controls.state.setValue(data.state);
       this.createAccountForm.controls.zipcode.setValue(data.zipcode);
       this.createAccountForm.controls.latitude.setValue(data.latitude);
       this.createAccountForm.controls.longitude.setValue(data.longitude);

        
        

        console.log('getAddressFromMap  :', data);
      }
    });
    modal.present();
  }

  createAccount(form) {
    form.value.address = this.parent.trimSpace(form.value.address);
    form.value.city = this.parent.trimSpace(form.value.city);
    form.value.country = this.parent.trimSpace(form.value.country);

    this.createAccountForm.controls['address'].setValue(this.parent.trimSpace(form.value.address)) 
    this.createAccountForm.controls['city'].setValue(this.parent.trimSpace(form.value.city)) 
    this.createAccountForm.controls['country'].setValue(this.parent.trimSpace(form.value.country)) 

    // if(!form.valid){

      /** Phone Number */
      if(!form.value.phoneNumber){
        this.httpService.presentToast(ERROR_MESSAGES.blankField('mobile number'));
        return false;
      }
      if(!NUMBER_REGES.test(form.value.phoneNumber)){
        this.httpService.presentToast(ERROR_MESSAGES.phoneNumberLength);
        return false;
      }
      if(!((form.value.phoneNumber.toString().length >= 6) && (form.value.phoneNumber.toString().length <= 12))){
        this.httpService.presentToast(ERROR_MESSAGES.phoneNumberLengthCheck);
        return false;
      }

      /** Address */
      if(!form.value.address){
        this.httpService.presentToast(ERROR_MESSAGES.blankField('your address'));
        return false;
      }
      if(SPACE_REGES.test(form.value.address[0])){
        this.httpService.presentToast(ERROR_MESSAGES.firstCharacterSpace('address'));
        return false;
      }
      if(form.value.address.length > 100){
        this.httpService.presentToast(ERROR_MESSAGES.maxLength('address' , 100));
        return false;
      }
      // if(!TEXT.test(form.value.address)){
      //   this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('address' , TEXT));
      //   return false;
      // }

      /** City */
      if(!form.value.city){
        this.httpService.presentToast(ERROR_MESSAGES.blankField('your city'));
        return false;
      }
      if(SPACE_REGES.test(form.value.city[0])){
        this.httpService.presentToast(ERROR_MESSAGES.firstCharacterSpace('city'));
        return false;
      }
      if(form.value.city.length > 50){
        this.httpService.presentToast(ERROR_MESSAGES.maxLength('city' , 50));
        return false;
      }
      // if(!TEXT.test(form.value.city)){
      //   this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('city' , TEXT));
      //   return false;
      // }

      /** Country */
      if(!form.value.country){
        this.httpService.presentToast(ERROR_MESSAGES.blankField('your  country'));
        return false;
      }
      if(SPACE_REGES.test(form.value.country[0])){
        this.httpService.presentToast(ERROR_MESSAGES.firstCharacterSpace('country'));
        return false;
      }
      if(form.value.country.length > 50){
        this.httpService.presentToast(ERROR_MESSAGES.maxLength('country' , 50));
        return false;
      }
      // if(!TEXT.test(form.value.country)){
      //   this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('country' , TEXT));
      //   return false;
      // }
      

    // }

    form.value.userType = this.parent.userType;
    form.value.userId = getUserData('id');

    this.httpService.httpRequest('POST', 'updateUserProfile', form.value)
      .then((response: any) => {
        this.httpService.presentToast(response.message);
        let page : any = this.parent.getPage();
        this.navCtrl[page.type](page.page, page.param);
      }).catch((response: any) => {
        console.log('Error response : ', response)
      })
  }

  goToSelectCountryCodePage() {
    this.parent.blurryBG(true);
    let modal = this.modalCtrl.create(CountryCodePage, {selectedCountry : this.selectedCountry});
    modal.onDidDismiss(data => {
      if (data) {
        this.httpService.presentLoading();
        setTimeout(() => {
          this.parent.blurryBG();
          this.httpService.loader.dismiss();
        }, 500)
        console.log('data : ', data);
        this.selectedCountry = data;

        this.createAccountForm.controls.countryCode.setValue('+'+this.selectedCountry.countryCode);

        setTimeout(() => {
          this.setupCountryCode();
        }, 500)
      }else{
        this.parent.blurryBG();
      }
    });
    modal.present();
  }

  setupCountryCode() {
    let countryCodeBox: any = document.getElementsByClassName('country-code')[0];
    if(!countryCodeBox){
      setTimeout(()=>{
        this.setupCountryCode();
      }, 50)
      return;
    }
    let countryCodeBoxOffsetWidth = countryCodeBox.offsetWidth;

    let forceFocus: any = document.getElementsByClassName('mobile-input')[0];
    forceFocus.classList.add('force-focus');
    forceFocus.children[0].children[0].children[1].children[0].style.paddingLeft = countryCodeBoxOffsetWidth + 7 + 'px';
    forceFocus.children[0].children[0].children[1].children[0].placeholder = 'Mobile Number'
  }

}
