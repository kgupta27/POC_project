import { Component, Inject, forwardRef, ViewChild } from '@angular/core';
import { NavController, NavParams, ModalController, Navbar } from 'ionic-angular';
import { MyApp } from '../../../app/app.component';
import { FormBuilder, Validators } from '@angular/forms';
import { HttpService } from '../../../app/common/providers/http-service';
import { MapLocationPage } from '../../user/map-location/map-location';
import { ProfilePage } from '../../profile/profile';
import { ViewProfilePage } from '../../profile/view-profile/view-profile';

import { ERROR_MESSAGES } from '../../../app/common/config/error';
import { NUMBER_REGES, TEXT, SPACE_REGES, EMAIL_REGES } from '../../../app/common/config/constants';
import { getUserData } from '../../../app/common/config/global-functions';
import { CountryCodePage } from '../../user/country-code/country-code';
import { CameraOptions, Camera } from '@ionic-native/camera';
import { ActionSheetController } from 'ionic-angular/components/action-sheet/action-sheet-controller';
import { AlertController } from 'ionic-angular/components/alert/alert-controller';
import { AddLinkPage } from '../../user/add-link/add-link';

@Component({
  selector: 'page-edit-personal-details',
  templateUrl: 'edit-personal-details.html',
})
export class EditPersonalDetailsPage {
  @ViewChild('navbar') navBar: Navbar;
  userType=this.parent.userType;
  createAccountForm: any;
  selectedCountry: any;
  profilePhoto: any;
  profilePhotoChanged = false;
  userProfile = {};
  userDetails = {};

  /*
  options: CameraOptions = {
    quality: 100,
    destinationType: this.camera.DestinationType.DATA_URL,
    sourceType: this.camera.PictureSourceType.CAMERA,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
    targetWidth: 255,
    targetHeight: 255,
    allowEdit: true,
    saveToPhotoAlbum: false
  }
  optionsGallery: CameraOptions = {
    quality: 80,
    destinationType: this.camera.DestinationType.DATA_URL,
    sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
    targetWidth: 200,
    targetHeight: 200,
    allowEdit: true,
    saveToPhotoAlbum: false
  }*/


  constructor(
    public navCtrl: NavController,
    private alertCtrl: AlertController,
    public navParams: NavParams,
    private modalCtrl: ModalController,
    public fb: FormBuilder,
    private httpService: HttpService,
    private camera: Camera,
    private actionSheetCtrl: ActionSheetController,

    @Inject(forwardRef(() => MyApp)) private parent: MyApp) {
    this.setupUserData();


  }
  setupUserData() {
    this.userProfile['name'] = this.httpService.getUserProperty('name');
    this.userProfile['email'] = this.httpService.getUserProperty('email');
    this.userProfile['phoneNumber'] = this.httpService.getUserProperty('phoneNumber');
    this.userDetails = this.httpService.getUserProperty('userDetails');
    if (this.userDetails) {
      this.userDetails = this.userDetails[0];
    }
    this.createAccountForm = this.fb.group({
      name: [this.userProfile['name'] || '', [Validators.required, Validators.pattern(TEXT), Validators.maxLength(50)]],
      email: [this.userProfile['email'] || '', [Validators.required, Validators.pattern(EMAIL_REGES), Validators.maxLength(50)]],
      phoneNumber: [this.userProfile['phoneNumber'] || '', [Validators.required, Validators.pattern(NUMBER_REGES), Validators.minLength(10), Validators.maxLength(10)]],
      // address: [this.userDetails['address'] || '', [Validators.required, Validators.pattern(TEXT), Validators.maxLength(100)]],
      // city: [this.userDetails['city'] || '', [Validators.required, Validators.pattern(TEXT), Validators.maxLength(50)]],
      // country: [this.userDetails['country'] || '', [Validators.required, Validators.pattern(TEXT), Validators.maxLength(50)]],
      address: [this.userDetails['address'] || '', [Validators.required, Validators.maxLength(100)]],
      city: [this.userDetails['city'] || '', [Validators.required, Validators.maxLength(50)]],
      country: [this.userDetails['country'] || '', [Validators.required, Validators.maxLength(50)]],
    });
    if (this.userDetails) {
      if (this.userDetails['countryCode'] && this.userDetails['countryCode'].indexOf('+') >= 0) {
        this.selectedCountry = { countryCode: this.userDetails['countryCode'].split('+')[1] };
      } else {
        this.selectedCountry = { countryCode: this.userDetails['countryCode'] };
      }
      this.profilePhoto = this.userDetails['profileImage'];
      if (this.selectedCountry.countryCode) {
        setTimeout(() => {
          this.setupCountryCode();
        }, 1)
      }
    }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EditPersonalDetailsPage');

    this.navBar.backButtonClick = () => {
      console.log('Back button clicked');
      this.navCtrl.pop();

    }
  }


  getAddressFromMap() {
    let modal = this.modalCtrl.create(MapLocationPage);
    modal.onDidDismiss(data => {
      if (data) {
        this.createAccountForm.controls.address.setValue(data.address);
        this.createAccountForm.controls.city.setValue(data.city);
        this.createAccountForm.controls.country.setValue(data.country);

        console.log('getAddressFromMap  :', data);
      }
    });
    modal.present();
  }

  createAccount(form) {
    form.value.address = this.parent.trimSpace(form.value.address);
    form.value.city = this.parent.trimSpace(form.value.city);
    form.value.country = this.parent.trimSpace(form.value.country);

    this.createAccountForm.controls['address'].setValue(this.parent.trimSpace(form.value.address))
    this.createAccountForm.controls['city'].setValue(this.parent.trimSpace(form.value.city))
    this.createAccountForm.controls['country'].setValue(this.parent.trimSpace(form.value.country))

    /** Email Validation */
    if(!form.value.email){
      this.httpService.presentToast(ERROR_MESSAGES.blankField('Email'));
      return false;
    }

    if(!EMAIL_REGES.test(form.value.email)){
      this.httpService.presentToast(ERROR_MESSAGES.invalidEmail);
      return false;
    }

    // if(!form.valid){

    /** Phone Number */
    if (!form.value.phoneNumber) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('mobile number'));
      return false;
    }
    if (!NUMBER_REGES.test(form.value.phoneNumber)) {
      this.httpService.presentToast(ERROR_MESSAGES.phoneNumberLength);
      return false;
    }
    if (!((form.value.phoneNumber.toString().length >= 6) && (form.value.phoneNumber.toString().length <= 12))) {
      this.httpService.presentToast(ERROR_MESSAGES.phoneNumberLengthCheck);
      return false;
    }

    /** Address */
    if (!form.value.address) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('your address'));
      return false;
    }
    if (SPACE_REGES.test(form.value.address[0])) {
      this.httpService.presentToast(ERROR_MESSAGES.firstCharacterSpace('address'));
      return false;
    }
    if (form.value.address.length > 100) {
      this.httpService.presentToast(ERROR_MESSAGES.maxLength('address', 100));
      return false;
    }
    // if (!TEXT.test(form.value.address)) {
    //   this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('address', TEXT));
    //   return false;
    // }

    /** City */
    if (!form.value.city) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('your city'));
      return false;
    }
    if (SPACE_REGES.test(form.value.city[0])) {
      this.httpService.presentToast(ERROR_MESSAGES.firstCharacterSpace('city'));
      return false;
    }
    if (form.value.city.length > 50) {
      this.httpService.presentToast(ERROR_MESSAGES.maxLength('city', 50));
      return false;
    }
    // if (!TEXT.test(form.value.city)) {
    //   this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('city', TEXT));
    //   return false;
    // }

    /** Country */
    if (!form.value.country) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('your  country'));
      return false;
    }
    if (SPACE_REGES.test(form.value.country[0])) {
      this.httpService.presentToast(ERROR_MESSAGES.firstCharacterSpace('country'));
      return false;
    }
    if (form.value.country.length > 50) {
      this.httpService.presentToast(ERROR_MESSAGES.maxLength('country', 50));
      return false;
    }
    // if (!TEXT.test(form.value.country)) {
    //   this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('country', TEXT));
    //   return false;
    // }


    // }

    form.value.userType = 2;
    form.value.userId = getUserData('id');
    form.value.countryCode = "+" + this.selectedCountry.countryCode;
    if (this.profilePhoto && this.profilePhotoChanged) {
      form.value.profileImage = this.profilePhoto;
    }
    this.httpService.httpRequest('POST', 'updateUserProfile', form.value)
      .then((response: any) => {
        this.httpService.presentToast(response.message);
        // this.navCtrl.pop();
        this.navCtrl.setPages([{page : ProfilePage}, {page : ViewProfilePage}])
      }).catch((response: any) => {
        console.log('Error response : ', response)
      })
  }

  goToSelectCountryCodePage() {
    this.parent.blurryBG(true);
    let modal = this.modalCtrl.create(CountryCodePage, { selectedCountry: this.selectedCountry });
    modal.onDidDismiss(data => {

      if (data) {
        this.httpService.presentLoading();
        setTimeout(() => {
          this.parent.blurryBG();
          this.httpService.loader.dismiss();
        }, 500)
        console.log('data : ', data);
        this.selectedCountry = data;
        setTimeout(() => {
          this.setupCountryCode();
        }, 500)
      } else {
        this.parent.blurryBG();
      }
    });
    modal.present();
  }

  setupCountryCode() {
    let countryCodeBox: any = document.getElementsByClassName('country-code')[0];
    if (!countryCodeBox) {
      setTimeout(() => {
        this.setupCountryCode();
      }, 50)
      return;
    }
    let countryCodeBoxOffsetWidth = countryCodeBox.offsetWidth;

    let forceFocus: any = document.getElementsByClassName('mobile-input')[0];
    forceFocus.classList.add('force-focus');
    forceFocus.children[0].children[0].children[1].children[0].style.paddingLeft = countryCodeBoxOffsetWidth + 7 + 'px';
    forceFocus.children[0].children[0].children[1].children[0].placeholder = 'Mobile Number'
  }

  takePicture() {
    this.parent.image.get().then((img) => {
      // this.data.certificateImage = img;
      this.profilePhotoChanged = true;
      this.profilePhoto = img;
    })
  }
  /*
  takePicture() {
    let actionSheet = this.actionSheetCtrl.create({
      title: '',
      buttons: [
        {
          text: 'Take a Photo',
          handler: () => {
            this.camera.getPicture(this.options).then((ImageData) => {
              this.profilePhotoChanged = true;
              this.profilePhoto = "data:image/jpeg;base64," + ImageData;
            })
              .catch(data => {

              });
          }
        },
        {
          text: 'Choose From Gallery',
          handler: () => {
            this.camera.getPicture(this.optionsGallery).then((ImageData) => {
              this.profilePhotoChanged = true;
              this.profilePhoto = "data:image/jpeg;base64," + ImageData;
            })
              .catch(data => {

              });
          }
        },
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });

    actionSheet.present();
  }*/
  unlinkFb() {
    //this.parent.blurryBG(true);
    let alert = this.alertCtrl.create({
      title: 'Unlink Facebook',
      subTitle: 'Are you sure you want to unlink facebook from your profile ?',
      cssClass: 'two-button',
      enableBackdropDismiss: false,
      buttons: [
        {
          text: 'No',
          handler: () => {

          }
        },
        {
          text: 'Confirm',
          handler: data => {
            //this.parent.blurryBG();
            this.httpService.httpRequest('POST', 'updateUserProfile', { facebookLink: null })
              .then((response: any) => {
                this.httpService.presentToast(response.message);
                this.setupUserData();
              }).catch((response: any) => {
                console.log('Error response : ', response)
              });

          }
        }
      ]
    });
    alert.present();
  }
  linkFb() {
    this.parent.blurryBG(true);
    let modal = this.modalCtrl.create(AddLinkPage, { type: 'facebook' });
    modal.onDidDismiss(data => {
      this.parent.blurryBG();
      if (data) {
        if (data.link) {
          this.httpService.httpRequest('POST', 'updateUserProfile', { facebookLink: data.link })
            .then((response: any) => {
              this.httpService.presentToast(response.message);
              this.setupUserData();
            }).catch((response: any) => {
              console.log('Error response : ', response)
            });
        }
      }
    });
    modal.present();
  }

}
