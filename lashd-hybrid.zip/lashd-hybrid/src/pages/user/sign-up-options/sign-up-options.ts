import { Component, Inject, forwardRef } from '@angular/core';
import { NavController, NavParams, App } from 'ionic-angular';

import { Facebook, FacebookLoginResponse } from '@ionic-native/facebook';
import { HttpService } from '../../../app/common/providers/http-service';

import { PrivacyPolicyPage } from '../privacy-policy/privacy-policy';
import { TermsAndConditionsPage } from '../terms-and-conditions/terms-and-conditions';
import { LoginPage } from '../login/login';
import { SignUpPage } from '../sign-up/sign-up';
import { EnterEmailPage } from '../enter-email/enter-email';

import { MyApp } from '../../../app/app.component';

import { ERROR_MESSAGES } from '../../../app/common/config/error';

import {IntroScreensCustomerPage} from '../../intro-screens-customer/intro-screens-customer';
import {IntroScreensPage} from '../../intro-screens/intro-screens';


@Component({
  selector: 'page-sign-up-options',
  templateUrl: 'sign-up-options.html',
})
export class SignUpOptionsPage {

  termsAndConditionsPage = TermsAndConditionsPage;
  privacyPolicyPage = PrivacyPolicyPage;
  loginPage = LoginPage;
  signUpPage = SignUpPage;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams, 
    private fb: Facebook,
    private httpService : HttpService,
    private app : App,
    @Inject(forwardRef(() => MyApp)) private parent: MyApp
    ) {
      if(this.navParams.get("needToClearStack")){
        this.navCtrl.remove(0)
      }
  }

  ionViewDidEnter(){
   this.parent.userLogout();
  }

  goToLogin(){
    this.navCtrl.setRoot(LoginPage);
  }

  data: any = {};

  fbLogin() {
    this.httpService.presentLoading("");
    this.fb.login(['public_profile', 'user_friends', 'email'])
      .then((res: FacebookLoginResponse) => {
        console.log('Logged into Facebook!', res)
        this.data.token = res.authResponse.accessToken;
        this.fb.api('me?fields=id,name,email,first_name,picture.width(720).height(720).as(picture_large)', []).then(profile => {
          this.httpService.loader.dismiss();
          console.log('profile  : ', profile);
          this.data.userData = profile;
          this.submitData();
        }).catch((profileError) => {
          this.httpService.loader.dismiss();
          if(profileError && profileError.errorMessage){
            this.httpService.presentToast(profileError.errorMessage);
          }
          console.log('Error logging into Facebook profileError', profileError)
        });
      })
      .catch(e => {
        this.httpService.loader.dismiss();
        if(e && e.errorMessage){
          if(e.errorMessage.indexOf('User cancelled') == -1){
            if(e.errorMessage.indexOf("CONNECTION_FAILURE") >= 0){
              this.httpService.presentToast(ERROR_MESSAGES.noConnection);
            }else{
              this.httpService.presentToast(e.errorMessage);
            }
            
          }
        }
        console.log('Error logging into Facebook Other', e)
      });
  }

  submitData(){
    let postData : any = {
      "email": this.data.userData.email,
      "fbAccessToken": this.data.token,
      "userType": this.parent.userType,
      "fbId" : this.data.userData.id,
    }
    if(this.data.userData && this.data.userData.email){
      //GO to add profile
      postData.email = this.data.userData.email;
      this.httpService.httpRequest('POST', 'fbSignUp', postData)
      .then((response : any) => {
        if(response.result){
          this.httpService.storeAllUserDetails(response.result);
        }
        this.httpService.presentToast(response.message);
        let page = this.parent.getPage();
        this.navCtrl[page.type](page.page, {"fbUserData" : this.data.userData});
      }).catch((response : any) => {
        console.log('Error response : ', response)
      })
    }else{
      this.httpService.httpRequest('POST', 'fbSignUp', postData)
      .then((response : any) => {
        this.httpService.storeAllUserDetails(response.result);
        console.log('Success response : ', response);
        this.httpService.presentToast(response.message);
        if(response.result.emailMissing){
          //GO to enter email
          this.navCtrl.push(EnterEmailPage, {"fbUserData" : this.data.userData, "postData": postData});
        }else{
          let page = this.parent.getPage();
          this.navCtrl[page.type](page.page, {"fbUserData" : this.data.userData});
        }
        
      }).catch((response : any) => {
        console.log('Error response : ', response)
      })
      
    }
  }

  gotoCustomerIntro(){
    // this.app.getRootNav().setRoot(IntroScreensCustomerPage);
    this.navCtrl.setRoot(IntroScreensCustomerPage);
  }

  gotoCreativeIntro(){
    this.navCtrl.setRoot(IntroScreensPage);
    // this.app.getRootNav().setRoot(IntroScreensPage);
  }


}
