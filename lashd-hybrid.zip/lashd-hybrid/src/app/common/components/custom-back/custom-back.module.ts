import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { CustomBackComponent } from './custom-back';

@NgModule({
  declarations: [
    CustomBackComponent
  ],
  imports: [
    IonicPageModule.forChild(CustomBackComponent),
  ],
  exports : [CustomBackComponent]
})
export class CustomBackModule {}
