import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { Diagnostic } from '@ionic-native/diagnostic';
import { Geolocation } from '@ionic-native/geolocation';
import { GooglePlacesProvider } from '../../../app/common/providers/google-maps';

import { MapLocationPage } from '../../user/map-location/map-location';
import { AppNotAvailablePage } from '../../user/app-not-available/app-not-available';
import { HttpService } from '../../../app/common/providers/http-service';

@Component({
  selector: 'page-enable-location',
  templateUrl: 'enable-location.html',
  providers: [GooglePlacesProvider, Geolocation]
})
export class EnableLocationPage {

  currentCity: any;
  locationEnableObj: any;
  locationEnable: any = false;
  allowedCities = [];

  introPage : any;

  canClick : boolean = true;

  constructor(public navCtrl: NavController,
    public navParams: NavParams,
    private diagnostic: Diagnostic,
    private geolocation: Geolocation,
    private httpService: HttpService,
    private googlePlacesProvider: GooglePlacesProvider
  ) {
      this.introPage = this.navParams.get('introPage'); 
    }

     

  ionViewDidLoad() {
    if(window['cordova']){
      this.locationEnableObj = setInterval(() => {
        this.diagnostic.isLocationEnabled()
          .then((isEnabled) => {
            if (isEnabled) {
              clearInterval(this.locationEnableObj);
              this.locationEnable = true;
              // this.httpService.presentLoading();
              navigator.geolocation.getCurrentPosition(
                (position) => {
                  console.log("success : "+JSON.stringify(position));
                  var latlong = position.coords.latitude + ',' + position.coords.longitude;
                  // if(this.locationEnableObj){
                    
                  // }

                  this.introPage.getCity(latlong);
                  
                  // this.httpService.loader.dismiss();
                },
                (error) => {
                  console.log("error : "+JSON.stringify(error));
                  // this.httpService.loader.dismiss();
                },
                { enableHighAccuracy: true, timeout: 20000, maximumAge: 10000 }
              );
            }
          });
      }, 4000);
    }
  }

  enableLocation() {
    this.canClick = false;
    setTimeout(()=>{
      this.canClick = true;
    }, 1000)

    this.introPage.getStarted(true);

    /*
    if(window['cordova']){// for mobile
      this.diagnostic.switchToLocationSettings();
    }else{//for testing on web
      this.navCtrl.push(MapLocationPage, {pickCustomerLocation : true});
    }*/
  }

}
