import { Component } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';


// Import constants
// import { TEXT, NUMBER_REGES, SPACE_REGES } from '../../../app/common/config/constants';
import { TEXT, NUMBER_REGES } from '../../../app/common/config/constants';
import { FormGroup } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Validators } from '@angular/forms';
import { ViewController } from 'ionic-angular/navigation/view-controller';

//Import Providers
import { HttpService } from '../../../app/common/providers/http-service';
import { ERROR_MESSAGES } from '../../../app/common/config/error';


@Component({
  selector: 'page-edit-service',
  templateUrl: 'edit-service.html',
})
export class EditServicePage {
  subCategoryName;
  subCategoryform:FormGroup;
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private httpService:HttpService,
    private viewctrl:ViewController,
    private formBuilder:FormBuilder) {
    this.subCategoryName = this.navParams.get('subCategory').name;
    this.subCategoryform = this.formBuilder.group({
      "description" : ["",[Validators.required,Validators.pattern(TEXT), Validators.maxLength(250)]],
      "duration" : ["",[Validators.required,Validators.pattern(NUMBER_REGES)]],
      "price" : ["",[Validators.required,Validators.pattern(NUMBER_REGES)]],
      "subCategoryId" : [this.navParams.get('subCategory').id]
    
    })
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad EditServicePage');
  }
  submitForm(form){

    //Duration
    if(!form.value.duration){
      this.httpService.presentToast(ERROR_MESSAGES.blankField('duration'));
      return false;
    }
    else if(!NUMBER_REGES.test(form.value.duration)){
      this.httpService.presentToast(ERROR_MESSAGES.allowedNumbers('duration',NUMBER_REGES));
      return false;
    }

     //Price
    if(!form.value.price){
      this.httpService.presentToast(ERROR_MESSAGES.blankField('price'));
      return false;
    }
    else if(!NUMBER_REGES.test(form.value.price)){
      this.httpService.presentToast(ERROR_MESSAGES.allowedNumbers('price',NUMBER_REGES));
      return false;
    }

     //Description
     if(!form.value.description){
      this.httpService.presentToast(ERROR_MESSAGES.blankField('description'));
      return false;
    }
    else if(!TEXT.test(form.value.description)){
      this.httpService.presentToast(ERROR_MESSAGES.allowedCharacters('description',TEXT));
      return false;
    }



    console.log("submit subcategory API",form.value);
    this.httpService.httpRequest("POST","addService",form.value,true)
      .then((response)=>{
        console.log(response);
        this.viewctrl.dismiss(response);
      })
      .catch((error)=>{
        console.log("Error in catching response",error);
      })
  }

}
