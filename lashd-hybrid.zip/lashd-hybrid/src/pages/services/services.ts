import { Component, forwardRef, Inject } from '@angular/core';
import { NavController, NavParams, ModalController, AlertController, App } from 'ionic-angular';
// Import providers
import { HttpService } from '../../app/common/providers/http-service';

import { AddServicePage } from './add-service/add-service';
import { ViewServicePage } from './view-service/view-service';

import { MyApp } from '../../app/app.component';
// import { EditServicePage } from './edit-service/edit-service';

@Component({
  selector: 'page-services',
  templateUrl: 'services.html',
})
export class ServicesPage {
  categories;
  selectedCategory = [];
  selectedData: any = [];
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private httpService: HttpService,
    private modalCtrl: ModalController,
    private alertCtrl: AlertController,
    private app : App,
    @Inject(forwardRef(() => MyApp)) private parent: MyApp
  ) {

    this.getCategoies();
  }

  getCategoies() {
    this.httpService.httpRequest("GET", "categories", {}, true, true).then((response) => {
      console.log("API categories", response['result']);
      if (response['result']) {
        this.categories = response['result']['data']['data'];
        /*let categories = response['result']['data']['data'];
        for(let i = 0;i < categories.length;i++){
          for(let j = 0;j < categories[i].subCategories.length;j++){
            if(categories[i].subCategories[j].services.length){
              let service : any = categories[i].subCategories[j].services[0];
              service.serviceName = categories[i].name;
              service.subCategoryName = categories[i].subCategories[j].name;
              this.selectedData.push(service);
            }
          }  
        }*/
      }
      console.log("this.selectedData : ", this.selectedData)
    })
      .catch((error) => {
        this.categories = [];
        console.log("error in fetching categories", error);
      })
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad ServicesPage');
  }
  selectCategory(id) {
    if (this.selectedCategory.length && (this.selectedCategory.indexOf(id) >= 0)) {
      this.selectedCategory.splice(this.selectedCategory.indexOf(id), 1);
      return;
    }
    this.selectedCategory.push(id);
  }

  // isCategorySelected(categoryId, subCategoryId){
  //   let isSelected : any = -1;
  //   for(let i = 0;i < this.selectedData.length;i++){
  //     // if((this.selectedData[i].subCategoryId == subCategoryId) && !(this.selectedData[i].isOther)){
  //     if((this.selectedData[i].subCategoryId == subCategoryId)){
  //       isSelected = i;
  //       break;
  //     }
  //   }
  //   return isSelected;
  // }


  viewService(category, subCategory) {
    category = JSON.parse(JSON.stringify(category));
    delete category.subCategories;
    this.parent.blurryBG(true);
    let modal = this.modalCtrl.create(ViewServicePage, {
      category: category,
      subCategory: subCategory,
      parent : this.parent
    });
    modal.onDidDismiss(data => {
      this.parent.blurryBG();
      if (data) {
        if (data.action == 'delete') {
          this.getCategoies();
        }else{
          this.addService(data.category, data.subCategory)
        }
      }
    })
    modal.present();
  }

  addService(category, subCategory) {
    category = JSON.parse(JSON.stringify(category));
    delete category.subCategories;
    this.parent.blurryBG(true);
    console.log({category: category,
      subCategory: subCategory})
    let modal = this.modalCtrl.create(AddServicePage, {
      category: category,
      subCategory: subCategory
    });
    modal.onDidDismiss(data => {
      this.parent.blurryBG();
      if (data) {
        console.log("data added");
        this.getCategoies();
      }
    })
    modal.present();
  }

  saveSelectedServices() {
    this.httpService.httpRequest("POST", "updateUserProfile", { isServiceSave: 1})
      .then((response: any) => {
        this.httpService.storeAllUserDetails(response.result)
        if (response.result && response.result.user && response.result.user.myService && response.result.user.myService.id) {
          let page = this.parent.getPage();
          // this.navCtrl[page.type](page.page);
          this.app.getRootNav().setRoot(page.page);

        } else {
          this.httpService.presentToast('Please add a service to save the changes');
        }

        console.log(response);
        // this.viewCtrl.dismiss(response);
      })
      .catch((error) => {
        console.log("Error in catching response", error);
      })


    /*
    console.log("saveSelectedServices : ", this.selectedData)
    if(this.selectedData && this.selectedData.length){
      this.httpService.httpRequest("GET","userProfile",{})
      .then((response)=>{
        console.log(response);
        // this.viewCtrl.dismiss(response);
      })
      .catch((error)=>{
        console.log("Error in catching response",error);
      })
    }else{
      this.httpService.presentToast("Please select a service")
    }*/

  }

  logout() {
    this.parent.blurryBG(true);
    let alert = this.alertCtrl.create({
      title: 'Logout',
      subTitle: 'Are you sure you want to Logout from the app.',
      cssClass: 'two-button',
      enableBackdropDismiss: false,
      buttons: [
        {
          text: 'No',
          handler: data => {
            this.parent.blurryBG();
          }
        },
        {
          text: 'Confirm',
          handler: data => {
            this.parent.userLogout('signUpOptions', 'true');
          }
        }
      ]
    });
    alert.present();
  }

}
