/*
API DOCs : 


1-> Android,
2-> iOS

2->Creative
3->Customer


********** BeeHive Job Status **********
****************************************

'BOOKING_PENDING'               =>  1,
'BOOKING_CONFIRM'               =>  2,
'BOOKING_REJECT'                =>  3,
'BOOKING_STARTED'               =>  4,
'BOOKING_ENDED '                =>  5, 
'BOOKING_CANCELLED'             =>  6,
'BOOKING_EXPIRED'               =>  7



****** BeeHive Notifications Types *****
****************************************

'BOOKING_REQUEST' => 1, O
'BOOKING_CONFIRM' => 2, R
'BOOKING_REJECT' => 3,  R
'BOOKING_CANCEL_O' => 4, 
'BOOKING_CANCEL_R' => 5, 
'BOOKING_STARTED' => 6, R
'BOOKING_REMINDER' => 7, O
'BOOKING_ENDED' => 8 R
'BOOKING_REMINDER' => 9, R
*/
// export let SERVER_NAME_MAIN = "http://52.65.85.242";//DEV
// export let SERVER_NAME_MAIN = "http://13.210.108.57";//QA
export let SERVER_NAME_MAIN = "http://52.63.242.121";//Staring
//export let SERVER_NAME_MAIN = "https://prod.thebeehiveapp.com";

export let SERVER_NAME = SERVER_NAME_MAIN+"/api/v1/";

/** API Array */
export let APIS = {
    "signUp" : "users/user-sign-up",
    "fbSignUp" : "users/facebook-sign-up",
    "signIn" : "users/user-sign-in",
    "signOut" : "users/user-sign-out",
    "updateUserProfile" : "users/update-profile",
    "terms": "terms-conditions",
    "privacy": "privacy-policy",
    "uploadImage": "users/upload-image",
    "updateCreative":"users/update-creative",
    "getUserBank" : "stripe/user-bank-account",
    "updateBankAccount" : "stripe/update-bank-account",
    "categories":"services/categories",
    "addService":"services/add-service",
    "myService":"services/my-services",
    "deleteService" : "services/delete-service",
    "subscribe":"users/subscribed-list",
    "userProfile" : "users/user-profile",
    "editService" : "services/edit-service",
    "changePassword":"users/change-password",
    "deleteImage" : "users/delete-image",
    "forgotPassword" : "users/forgot-password",
    "addCard":"stripe/add-card",
    "cards":"stripe/my-cards",
    "allowedCities":'users/allowed-cities',
    "changeRole":"users/change-role",
    "unauthCategories":"services/unauth-categories",
    "removeCard":"stripe/remove-card"
}