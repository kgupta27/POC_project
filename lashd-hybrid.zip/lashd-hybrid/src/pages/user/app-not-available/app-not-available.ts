import { Component, Inject, forwardRef } from '@angular/core';
import { NavController, NavParams ,AlertController} from 'ionic-angular';
import { Diagnostic } from '@ionic-native/diagnostic';
import { Geolocation } from '@ionic-native/geolocation';
import { GooglePlacesProvider } from '../../../app/common/providers/google-maps';

import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { EMAIL_REGES } from '../../../app/common/config/constants';
import { HttpService } from '../../../app/common/providers/http-service';
// import { MyApp } from '../../../app/app.component';
import { IntroScreensCustomerPage } from '../../intro-screens-customer/intro-screens-customer';


// Import main component
import { MyApp } from '../../../app/app.component';

// Import error messages
import { ERROR_MESSAGES } from '../../../app/common/config/error';
@Component({
  selector: 'page-app-not-available',
  templateUrl: 'app-not-available.html',
  providers: [GooglePlacesProvider, Geolocation]
})
export class AppNotAvailablePage {
  subscribeForm : FormGroup; 
  location : any;
  currentCity : any;
  constructor(public navCtrl: NavController, 
  public navParams: NavParams,
  public fb: FormBuilder,
  private httpService : HttpService,
  private alertCtrl : AlertController,
  private diagnostic : Diagnostic,
  private geolocation : Geolocation,
  private googlePlacesProvider : GooglePlacesProvider,
  @Inject(forwardRef(() => MyApp)) private parent: MyApp) {

    this.subscribeForm = fb.group({
        email: ['',[Validators.required, Validators.pattern(EMAIL_REGES), Validators.maxLength(50)]]
      })

      this.currentCity = this.navParams.get('city');

  }

  // ionViewDidLoad() {
  //     this.geolocation.getCurrentPosition().then((resp) => {
  //       var latlong = resp.coords.latitude+','+resp.coords.longitude;
  //       this.getCity(latlong);
  //     });
  // }


  subscribeUser(form) {

    if(!form.valid){
      /** Email Validation */
      if(!form.value.email){
        this.httpService.presentToast(ERROR_MESSAGES.blankField('Email'));
        return false;
      }

      if(!EMAIL_REGES.test(form.value.email)){
        this.httpService.presentToast(ERROR_MESSAGES.invalidEmail);
        return false;
      }
    }
  // subscribeUser(formData){
    // console.log(formData.email);
    this.httpService.httpRequest('POST', 'subscribe', {"cityName":this.currentCity,"email":form.value.email,"location":this.currentCity})
    .then((response : any) => {
      this.showPopup();
    }).catch((response : any) => {
      console.log('Error response : ', response)
    })
  }

  /*
  getCity(latlong){
    let city = '';
    this.googlePlacesProvider.getAddress(latlong).subscribe(data => {
      for(var i=0;i<data.results[0].address_components.length;i++){
          if(data.results[0].address_components[i].types[0] == 'administrative_area_level_2'){
            city = data.results[0].address_components[i].long_name;
          }
          if(data.results[0].address_components[i].types[0] == 'locality'){
            city = data.results[0].address_components[i].long_name;
          }
        }
        if(city != ''){
          this.currentCity = city;
        }
    });
  }*/


  showPopup() {
    this.parent.blurryBG(true);
    let alert = this.alertCtrl.create({
      title: 'Subscribed successfully',
      subTitle: 'You have successfully subscribed your email. We will contact you when we launch at your location.',
      cssClass: 'one-button',
      enableBackdropDismiss: false,
      buttons: [
        {
          text: 'Ok',
          handler: data => {
            this.parent.blurryBG();
            this.navCtrl.setRoot(IntroScreensCustomerPage);
          }
        }
      ]
    });
    alert.present();
  }

}
