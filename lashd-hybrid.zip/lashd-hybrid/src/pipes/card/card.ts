import { Pipe, PipeTransform } from '@angular/core';

/**
 * Generated class for the CardPipe pipe.
 *
 * See https://angular.io/api/core/Pipe for more info on Angular Pipes.
 */
@Pipe({
  name: 'cardPipe',
})
export class CardPipe implements PipeTransform {
  /**
   * Takes a value and makes it lowercase.
   */
  transform(value: string, ...args) {
    return value.match(/.{1,4}/g).join("   ");
    
  }
}
