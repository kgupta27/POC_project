import { Component, forwardRef, Inject } from '@angular/core';
import { NavController, NavParams } from 'ionic-angular';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NUMBER_REGES, CARD_TYPE } from '../../../app/common/config/constants';
import { ERROR_MESSAGES } from '../../../app/common/config/error';
import { HttpService } from '../../../app/common/providers/http-service';

// Import main component
import { MyApp } from '../../../app/app.component';

@Component({
  selector: 'page-add-card',
  templateUrl: 'add-card.html',
})
export class AddCardPage {
  addCardForm: FormGroup;
  minExp = new Date().toISOString()
  maxExp = new Date().getFullYear() + 20;
  addCardFromSettings = false;
  cardType;
  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    private httpService: HttpService,
    private fb: FormBuilder,
    @Inject(forwardRef(() => MyApp)) private parent: MyApp
    ) {
    // this.isSkipable = this.navParams.get('isSkipable');
    this.addCardFromSettings = this.navParams.get('addCardFromSettings')
    // console.log("this.isSkipable : ", this.isSkipable);
    this.addCardForm = this.fb.group({
      cardNumber: ['', [
        Validators.required,
        Validators.minLength(15),
        Validators.maxLength(16),
        Validators.pattern(NUMBER_REGES)]],
      name: ['', [Validators.required]],
      expiry: [''],
      cvv: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(4)]],
    });
    this.addCardForm.controls['cardNumber'].valueChanges.subscribe(value => {
      this.cardType = '';
      if (value) {

        if (value.toString().length > 16) {
          this.addCardForm.controls['cardNumber'].setValue(value.toString().substr(0, 16));
        }
        if (value.toString().length > 12) {
          if (CARD_TYPE.visaRegexp.test(value)) {
            this.cardType = 'visa';
          }
          if (CARD_TYPE.ptMasterCard.test(value)) {
            this.cardType = 'masterCard';
          }
          if (CARD_TYPE.ptAmeExp.test(value)) {
            this.cardType = 'amex';
          }

        }
      }
    });
    this.addCardForm.controls['cvv'].valueChanges.subscribe(value => {
      if (value && value.toString().length > 4) {
        this.addCardForm.controls['cvv'].setValue(value.toString().substr(0, 4));
      }
    })
  }
  ionViewDidLoad() {
    console.log('ionViewDidLoad AddCardPage');
  }


  addCard(form: FormGroup) {
    /** cardNumber */
    if (!form.value.cardNumber) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('card number.'));
      return false;
    }
    if (form.controls['cardNumber'].errors !== null && !this.cardType) {
      this.httpService.presentToast("Please enter valid card number.");
      return false;
    }

    // name
    if (!form.value.name) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('name on card.'));
      return false;
    }

    // expiry
    if (!form.value.expiry) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('expiry Date.'));
      return false;
    }

    // cvc
    if (!form.value.cvv) {
      this.httpService.presentToast(ERROR_MESSAGES.blankField('card verification code (CVC).'));
      return false;
    }
    if (form.controls['cvv'].errors != null) {
      this.httpService.presentToast("Please enter valid CVC.")
      return false;
    }
    

    console.log(form.value);

    if(form.value.expiry){
      let expiry = form.value.expiry.toString();
      if(expiry && expiry.indexOf('-') > 0){
        if(expiry.split('-').length > 0){
          expiry = expiry.split('-');
          form.value.expiry = expiry[1]+"/"+expiry[0];
        }
      }
    }
    //undefined/12/2017
    //"expiry": "12/2017"

    console.log(form.value);
    form.value.brand = this.cardType;
    this.httpService.httpRequest("POST","addCard",form.value)
    .then((response)=>{
      console.log(response);
      if(this.navParams.get('addCardFromSettings')){
        // this.httpService.presentToast(response['message']);
        this.navCtrl.pop();
      }else{
        this.httpService.httpRequest("GET","userProfile",{})
        .then((response : any)=>{
          this.httpService.storeAllUserDetails(response.result);
          // this.httpService.presentToast(response.message);
          let page = this.parent.getPage();
          this.navCtrl[page.type](page.page);
        })
        .catch((error)=>{
          console.log(error);
        })
      }
      
    })
    .catch((error)=>{
      console.log(error);
    })
  }

  skipCC(){
    this.httpService.httpRequest('POST', 'updateUserProfile', { isCardSkip: true })
    .then((response: any) => {
      this.httpService.storeAllUserDetails(response.result)
      let page = this.parent.getPage();
      this.navCtrl[page.type](page.page);
    }).catch((response: any) => {
      console.log('Error response : ', response)
    })
  }

}
