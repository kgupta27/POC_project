import { Injectable } from '@angular/core';

/**
 * 
 * Provider for Store Local Data Temporary
 * Used on all pages which has text inputs
 * 
 */

@Injectable()
export class LocalDataArray {
  deviceId = "refwefwef";
  deviceToken = "fb23897fb239ubf23fo23";
  deviceType = 2;
  // googleApiKey = 'AIzaSyDvDIDiYzoyvL78ubzn3iRH1oWDuj8lLas';
  
  private localData : any = {};

  resetLocalArray(){
    this.localData = {} 
  }

  checkRoot(rootName){
    if(!this.localData[rootName]){
      this.localData[rootName] = {}
    }
  }

  setLocalData(rootName,key, value){
    this.checkRoot(rootName);
    this.localData[rootName][key] = value;
  }
  getLocalData(rootName,key){
    this.checkRoot(rootName);
    return this.localData[rootName][key];
  }
  
  getLocalObject(rootName){
    this.checkRoot(rootName);
    return this.localData[rootName];
  }
  setLocalObject(rootName, value){
    this.checkRoot(rootName);
    this.localData[rootName] = value;
  }

}

//this.localDataArray.setLocalData('signUp', 'phone', 1234567890);
//this.localDataArray.getLocalData('signUp', 'phone');
//this.localDataArray.getLocalObject('signUp')
