import { Component } from '@angular/core';
import { NavController, NavParams, ViewController, ActionSheetController } from 'ionic-angular';

import { FormBuilder, Validators, FormGroup } from '@angular/forms';

// import { SPACE_REGES } from '../../../app/common/config/constants';
import { HttpService } from '../../../app/common/providers/http-service';

import { Clipboard } from '@ionic-native/clipboard';

import { URL_REGES } from '../../../app/common/config/constants';

@Component({
  selector: 'page-add-link',
  templateUrl: 'add-link.html',
})
export class AddLinkPage {
  type: any = '';
  // link : any = '';

  linkForm: FormGroup;

  constructor(
    public navCtrl: NavController,
    public navParams: NavParams,
    public fb: FormBuilder,
    private httpService: HttpService,
    private viewCtrl: ViewController,
    private actionSheetCtrl: ActionSheetController,
    private clipboard: Clipboard
  ) {
    this.type = this.navParams.get('type');


    this.linkForm = fb.group({
      link: [this.navParams.get('link') ? this.navParams.get('link') : '', [Validators.required, Validators.maxLength(50)]],
    })
  }

  saveLink(form) {
    form.value.link = form.value.link.replace(/ /g, '');
    this.linkForm.controls['link'].setValue(form.value.link.replace(/ /g, ''))

    // if(!form.value.link) {
    //   this.httpService.presentToast('Please add a link');
    //   return;
    // }

    if(form.value.link && !URL_REGES.test(form.value.link)) {
      this.httpService.presentToast('Please add a valid url');
      return;
    }

    this.viewCtrl.dismiss({ type: this.type, link: form.value.link });

  }

  pasteUrl() {
    let actionSheet = this.actionSheetCtrl.create({
      title: '',
      buttons: [
        {
          text: 'Paste',
          handler: () => {
            this.clipboard.paste().then(
              (resolve: string) => {
                this.linkForm.controls['link'].setValue(resolve);
              },
              (reject: string) => {
                console.log('Error: ' + reject);
              })
          }
        },
        {
          text: 'Clear',
          handler: () => {
            this.linkForm.controls['link'].setValue('');
          }
        },
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {}
        }
      ]
    });
    actionSheet.present();

    /*
    let alert = this.alertCtrl.create({
      title: 'Location Services',
      subTitle: 'Turn on location services to allow “Lashd” to determine your location',
      cssClass:'two-button',
      enableBackdropDismiss : false,
      buttons: [
        {
          text : 'Close',
          handler: data => {
            // this.parent.blurryBG();
          }
        },
        {
          text: 'Paste',
          handler: data => {

            this.clipboard.paste().then(
            (resolve: string) => {
                // alert(resolve);
                this.linkForm.controls['link'].setValue(resolve);
              },
              (reject: string) => {
                // alert('Error: ' + reject);
              }
            );
          }
        }
      ]
    });
    alert.present();*/
  }

}
