import { Content, Platform } from 'ionic-angular';
import { Injectable } from '@angular/core';
import { Keyboard } from '@ionic-native/keyboard';

/**
 * 
 * Provider for Open/Close Keyboard
 * Used on all pages which has text inputs
 * 
 */

@Injectable()
export class KeyboardService {
    parentElMain : any;
    constructor(platform : Platform, private keyboard : Keyboard){
         platform.ready().then(() => {
            platform.pause.subscribe(() => {
                console.log('platform.pause');
                this.keyboard.close()
            });
            platform.resume.subscribe(() => {
                console.log('platform.resume');
                this.keyboard.close();
            });
        })
    }
    autoKeyboardScrollCall(content:Content, addValue : number = 60){
        if(content && (content._mode === 'ios')){
            setTimeout(() => {
                this.autoKeyboardScroll(content, addValue);
            })
        }
    }
    closeKeyboard(){
        this.keyboard.close();
    }
    showKeyboard(){
        this.keyboard.show();
    }
    autoKeyboardScroll(content:Content, addValue : number = 60) {
        console.log('autoKeyboardScroll')
        if (!content) {
            return;
        }
        let self = this;
        function onKeyboardShow(e) {
            // find the input that's currently in focus
            let focusedElement : any = document.activeElement;
            if (focusedElement && ['INPUT', 'TEXTAREA'].indexOf(focusedElement.tagName)!==-1) {
                // determine the total offset between the top of the "ion-content" and this element.
                // we will do this by climbing up the dom until we reach the "ion-content"
                var parentEl = focusedElement.offsetParent;
                while (parentEl) {
                    parentEl = parentEl.offsetParent;
                    if(parentEl && (parentEl.tagName || parentEl.className) &&  ( (parentEl.className.indexOf('scroll-content') !== -1) || (parentEl.tagName === 'ION-CONTENT'))){
                        
                        self.parentElMain = parentEl;// add this parent element in scope variable for remove styling/class when keyboard will hide

                        //console.log('this.parentElMain onKeyboardAhow : ',self.parentElMain)
                        // let scrollParentEl = parentEl.offsetParent;
                        // if((scrollParentEl.className.indexOf('add-keyboard-open-class') !== -1)){
                        //    parentEl.classList.add("keyboard-opened")
                        //    break; 
                        // }


                        // we want to move the input so that the bottom of the focused input is just above the keyboard
                        if((parentEl.tagName === 'ION-CONTENT')){
                            // parentEl.style.height = 'calc(100% - '+(e.keyboardHeight+addValue-60)+'px)'; 
                            parentEl.classList.add("keyboard-opened")
                        }else{
                            // parentEl.style.height = 'calc(100% - '+(e.keyboardHeight+addValue)+'px)';
                            parentEl.classList.add("keyboard-opened")
                        }
                        break;
                    }
                }
            }
        }
        function onKeyboardHide(e) {
            //console.log('self.parentElMain onKeyboardHide : ',self.parentElMain)
            // remove styling/class when keyboard will hide
            if(self.parentElMain){
                self.parentElMain.style.height = '';
                self.parentElMain.classList.remove("keyboard-opened")
            }
        }
        // setup listeners
        window.addEventListener('native.keyboardshow', onKeyboardShow);
        window.addEventListener('native.keyboardhide', onKeyboardHide);
    }
}