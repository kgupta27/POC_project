import { Component, Inject, forwardRef } from '@angular/core';
import { NavController, NavParams, ModalController, ActionSheetController, AlertController } from 'ionic-angular';

import { AddLinkPage } from '../add-link/add-link';

// Import main component
import { MyApp } from '../../../app/app.component';

import { Camera, CameraOptions } from '@ionic-native/camera';

import { HttpService } from '../../../app/common/providers/http-service';

import { ERROR_MESSAGES } from '../../../app/common/config/error';

import { ProfilePage } from '../../profile/profile';
import { ViewProfilePage } from '../../profile/view-profile/view-profile';

@Component({
  selector: 'page-add-images',
  templateUrl: 'add-images.html',
  providers : [Camera]
})
export class AddImagesPage {

  images : any = [];

  facebookLink : string = '';
  instagramLink : string = '';

  isEdit : boolean = false;

  constructor(
    public navCtrl: NavController, 
    public navParams: NavParams, 
    private modalCtrl : ModalController,
    public camera:Camera,
    private actionSheetCtrl : ActionSheetController,
    private alertCtrl : AlertController,
    @Inject(forwardRef(() => MyApp)) private parent: MyApp,
    private httpService : HttpService
    ) {
      console.log("isEdit : ", this.isEdit);
      if(this.navParams.get('isEdit')){
        this.isEdit = this.navParams.get('isEdit')
        this.images = this.httpService.getUserProperty('userImages');
        // this.images.push({base64 : "data:image/jpeg;base64," + ImageData});

        let userData : any = this.httpService.getUserProperty('userDetails');

        this.facebookLink = userData[0].facebookLink;
        this.instagramLink = userData[0].instagramLink;
      }
  }

  ionViewDidLoad() {
    console.log('ionViewDidLoad AddImagesPage');
  }

  addLink(type) {
    this.parent.blurryBG(true);
    let modal = this.modalCtrl.create(AddLinkPage, {type : type, link : ((type == 'facebook') ? this.facebookLink : this.instagramLink) });
    modal.onDidDismiss(data => {
      this.parent.blurryBG();
      if(data) {
        if(data.type == 'facebook'){
          this.facebookLink = data.link;
        }else{
          this.instagramLink = data.link;
        }
        console.log('add link  :', data);
      }
    });
    modal.present();
  }

  /*
  options: CameraOptions = {
    quality:100,
    destinationType:this.camera.DestinationType.DATA_URL,
    sourceType: this.camera.PictureSourceType.CAMERA,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
    targetWidth:255,
    targetHeight:255,
    allowEdit:true,
    saveToPhotoAlbum:false
  }
  optionsGallery: CameraOptions ={
    quality:80,
    destinationType:this.camera.DestinationType.DATA_URL,
    sourceType: this.camera.PictureSourceType.PHOTOLIBRARY,
    encodingType: this.camera.EncodingType.JPEG,
    mediaType: this.camera.MediaType.PICTURE,
    targetWidth:200,
    targetHeight:200,
    allowEdit:true,
    saveToPhotoAlbum:false
  }*/

  uploadImage(){
    this.parent.image.get().then((img) => {
      // this.profilePhoto = img;
      this.images.push({base64 : img});
      this.uploadImageOnServer(this.images.length-1);
    });
  }

  /*
  uploadImage(){
      if(this.images.length >= 20){
        this.httpService.presentToast(ERROR_MESSAGES.maxImage);
        return;
      }
      let actionSheet = this.actionSheetCtrl.create({
      title: '',
      buttons: [
        {
          text: 'Take a Photo',
          handler: () => {
            this.camera.getPicture(this.options).then((ImageData) => {
                this.images.push({base64 : "data:image/jpeg;base64," + ImageData});
                this.uploadImageOnServer(this.images.length-1);
            })
            .catch(data => {
                
            });
          }
        },
        {
          text: 'Choose From Gallery',
          handler: () => {
            this.camera.getPicture(this.optionsGallery).then((ImageData) => {
                this.images.push({base64 : "data:image/jpeg;base64," + ImageData});
                this.uploadImageOnServer(this.images.length-1);
            })
            .catch(data => {
                
            });
          }
        },
        {
          text: 'Cancel',
          role: 'cancel',
          handler: () => {
            console.log('Cancel clicked');
          }
        }
      ]
    });

    actionSheet.present();
  }*/

  uploadImageOnServer(index){
    this.images[index].uploading = true;
    this.httpService.httpRequest('POST', 'uploadImage', {userImage : this.images[index].base64}, false)
    .then((response : any) => {
      this.images[index].serverUrl = response.result[response.result.length-1].imageName;
      this.images[index].uploading = false;
      this.images[index].uploadingSuccess = true;
      this.images[index].id = response.result[response.result.length-1].id;
    }).catch((response : any) => {
      this.images[index].uploading = false;
      this.images[index].uploadingSuccess = false;
      console.log('Error response : ', response)
    })
  }

  saveImages(){
    if(!this.isEdit && (!this.images.length && !this.facebookLink && !this.instagramLink)){
      this.httpService.presentToast('You have not provided any information to save');
      return;
    }

    if(this.images.length > 20){
      this.httpService.presentToast(ERROR_MESSAGES.maxImage);
      return;
    }

    for(let i = 0;i < this.images.length;i++){
      if(this.images[i].uploading){
        this.httpService.presentToast(ERROR_MESSAGES.stillUploading);
        return false;
      }
    }

    if(this.facebookLink || this.instagramLink || this.isEdit){
      this.updateProfile();
    }else{
      this.skipImages();
    }
  }

  updateProfile(){
    let postData : any = {};
      if(this.facebookLink){
        postData.facebookLink = this.facebookLink
      }else{
        postData.facebookLink = '';  
      }
      if(this.instagramLink){
        postData.instagramLink = this.instagramLink
      }else{
        postData.instagramLink = '';
      }

      console.log("updateUserProfile this.isEdit 0 : ", this.isEdit)
      this.httpService.httpRequest('POST', 'updateUserProfile', postData)
      .then((response : any) => {
        console.log("updateUserProfile this.isEdit : ", this.isEdit)
        if(this.isEdit){
          console.log("updateUserProfile In Edit : ", this.isEdit)
          // this.navCtrl.pop();
          this.navCtrl.setPages([{page : ProfilePage}, {page : ViewProfilePage, params : {selectedView : 'portfolio'}}])
        }else{
          let page = this.parent.getPage();
          this.navCtrl[page.type](page.page);
        }
      }).catch((response : any) => {
        console.log('Error response : ', response)
      })
  }

  removeImage(img, i){
    this.parent.blurryBG(true);
    let alert = this.alertCtrl.create({
      title: 'Delete Image',
      subTitle: 'Are you sure you want to delete this image.',
      cssClass:'two-button',
      enableBackdropDismiss : false,
      buttons: [
        {
          text : 'No',
          handler: data => {
            this.parent.blurryBG();
          }
        },
        {
          text: 'Confirm',
          handler: data => {
            this.httpService.httpRequest('POST', 'deleteImage', {deleteIds : [img.id]})
            .then((response : any) => {
              this.parent.blurryBG();
              this.images.splice(i ,1);
            }).catch((response : any) => {
              console.log('Error response : ', response)
              this.parent.blurryBG();
            })
          }
        }
      ]
    });
    alert.present();
  }

  skipImages(){
    this.httpService.httpRequest('POST', 'updateUserProfile', {isImageSkipped : true})
    .then((response : any) => {
      this.httpService.storeAllUserDetails(response.result)
      let page = this.parent.getPage();
      this.navCtrl[page.type](page.page);
    }).catch((response : any) => {
      console.log('Error response : ', response)
    })
  }
}
